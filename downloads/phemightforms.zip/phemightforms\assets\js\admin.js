/**
 * PhemightForms form builder.
 *
 * A WordPress-native, from-scratch builder: drag fields from the sidebar onto
 * the canvas (or click to add), see a live preview, select a field to edit its
 * options and conditional logic, duplicate or delete it, and reorder by drag.
 *
 * Fields carry a stable numeric `id` so conditional-logic references survive
 * reordering. The input name used on the front end is `field_{id}`.
 */
( function ( $ ) {
	'use strict';

	var config = { fields: [], settings: {}, _next_id: 1 };
	var $config;
	var $canvas;
	var $options;
	var fieldTypes = {};
	var i18n = {};
	var selectedId = null;

	/* --------------------------------------------------------------------- */
	/* Config helpers                                                        */
	/* --------------------------------------------------------------------- */

	function readConfig() {
		try {
			var parsed = JSON.parse( $config.val() || '{}' );
			config.fields = Array.isArray( parsed.fields ) ? parsed.fields : [];
			config.settings = parsed.settings && typeof parsed.settings === 'object' ? parsed.settings : {};
			config._next_id = parseInt( parsed._next_id, 10 ) || 1;
		} catch ( e ) {
			config = { fields: [], settings: {}, _next_id: 1 };
		}

		// Guarantee every field has a stable id.
		config.fields.forEach( function ( f ) {
			if ( ! f.id ) {
				f.id = config._next_id++;
			}
		} );
	}

	function writeConfig( skipHistory ) {
		if ( ! skipHistory ) {
			pushHistory();
		}
		$config.val( JSON.stringify( config ) );
	}

	var history = [];
	var historyIndex = -1;

	function pushHistory() {
		var snap = JSON.stringify( config );
		if ( historyIndex >= 0 && history[ historyIndex ] === snap ) {
			return;
		}
		history = history.slice( 0, historyIndex + 1 );
		history.push( snap );
		if ( history.length > 50 ) {
			history.shift();
		}
		historyIndex = history.length - 1;
	}

	function undo() {
		if ( historyIndex <= 0 ) {
			return;
		}
		historyIndex--;
		config = JSON.parse( history[ historyIndex ] );
		renderCanvas();
		renderOptions();
		writeConfig( true );
	}

	function redo() {
		if ( historyIndex >= history.length - 1 ) {
			return;
		}
		historyIndex++;
		config = JSON.parse( history[ historyIndex ] );
		renderCanvas();
		renderOptions();
		writeConfig( true );
	}

	function nextId() {
		return config._next_id++;
	}

	function fieldById( id ) {
		id = parseInt( id, 10 );
		for ( var i = 0; i < config.fields.length; i++ ) {
			if ( parseInt( config.fields[ i ].id, 10 ) === id ) {
				return config.fields[ i ];
			}
		}
		return null;
	}

	function fieldIndexById( id ) {
		id = parseInt( id, 10 );
		for ( var i = 0; i < config.fields.length; i++ ) {
			if ( parseInt( config.fields[ i ].id, 10 ) === id ) {
				return i;
			}
		}
		return -1;
	}

	function typeDef( type ) {
		return fieldTypes[ type ] || { label: type, choices: false, composite: [], display: false, logic: true };
	}

	/* --------------------------------------------------------------------- */
	/* Field creation                                                        */
	/* --------------------------------------------------------------------- */

	function makeField( type ) {
		var def = typeDef( type );
		var field = {
			id: nextId(),
			type: type,
			label: def.noLabel ? '' : def.label,
			placeholder: '',
			description: '',
			required: 0,
		};

		if ( def.choices ) {
			field.choices = [ 'Option 1', 'Option 2', 'Option 3' ];
		}
		if ( type === 'payment_multiple' || type === 'payment_select' ) {
			field.choices = [ 'First Item|10', 'Second Item|25', 'Third Item|50' ];
		}
		if ( type === 'payment_single' ) {
			field.price = '10';
			field.user_price = 0;
		}
		if ( type === 'payment_quantity' ) {
			field.label = field.label || 'Quantity';
		}
		if ( type === 'hidden' ) {
			field.default_value = '';
		}

		return field;
	}

	function addField( type, atIndex ) {
		var field = makeField( type );
		if ( typeof atIndex === 'number' && atIndex >= 0 && atIndex <= config.fields.length ) {
			config.fields.splice( atIndex, 0, field );
		} else {
			config.fields.push( field );
		}
		renderCanvas();
		writeConfig();
		selectField( field.id );
		return field;
	}

	/* --------------------------------------------------------------------- */
	/* Escaping                                                              */
	/* --------------------------------------------------------------------- */

	function esc( str ) {
		return String( str == null ? '' : str )
			.replace( /&/g, '&amp;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#39;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' );
	}

	/* --------------------------------------------------------------------- */
	/* Live preview markup                                                   */
	/* --------------------------------------------------------------------- */

	function money( amount ) {
		var symbol = ( window.PhemightFormsAdmin && window.PhemightFormsAdmin.currency ) || '$';
		var num = parseFloat( String( amount == null ? '' : amount ).replace( /[^0-9.\-]/g, '' ) );
		return symbol + ( isNaN( num ) ? '0.00' : num.toFixed( 2 ) );
	}

	function priceChoice( choice ) {
		var parts = String( choice ).split( '|' );
		return { label: ( parts[ 0 ] || '' ).trim(), price: ( parts[ 1 ] || '0' ).trim() };
	}

	function previewInput( field ) {
		var type = field.type;
		var def = typeDef( type );
		var ph = esc( field.placeholder );

		if ( def.composite && def.composite.length ) {
			return '<div class="phf-preview-composite">' + def.composite.map( function ( part ) {
				return '<span class="phf-preview-sub"><input type="text" disabled placeholder="' + esc( part ) + '"></span>';
			} ).join( '' ) + '</div>';
		}

		switch ( type ) {
			case 'textarea':
				return '<textarea disabled rows="3" placeholder="' + ph + '"></textarea>';
			case 'select':
				return '<select disabled><option>' + ( field.placeholder ? ph : esc( i18n.selectField || 'Select' ) ) + '</option></select>';
			case 'radio':
			case 'checkbox':
				return '<div class="phf-preview-choices">' + ( field.choices || [] ).map( function ( c ) {
					return '<label><input type="' + ( type === 'radio' ? 'radio' : 'checkbox' ) + '" disabled> ' + esc( c ) + '</label>';
				} ).join( '' ) + '</div>';
			case 'file':
				return '<input type="file" disabled>';
			case 'consent':
				return '<label class="phf-preview-consent"><input type="checkbox" disabled> ' + esc( field.consent_text || 'I consent to having this website store my submitted information.' ) + '</label>';
			case 'signature':
				return '<div class="phf-preview-signature">✎ ' + esc( 'Signature area' ) + '</div>';
			case 'repeater':
				return '<div class="phf-preview-repeater"><input type="text" disabled placeholder="' + esc( field.sub_label || field.placeholder || '' ) + '"><span class="phf-preview-repeater-add">+ Add another</span></div>';
			case 'hidden':
				return '<em class="phf-preview-hidden">Hidden field (value: ' + esc( field.default_value || '' ) + ')</em>';
			case 'payment_single':
				if ( field.user_price ) {
					return '<input type="number" disabled placeholder="' + esc( 'Enter amount' ) + '">';
				}
				return '<div class="phf-preview-price">' + money( field.price ) + '</div>';
			case 'payment_multiple':
				return '<div class="phf-preview-choices">' + ( field.choices || [] ).map( function ( c ) {
					var pc = priceChoice( c );
					return '<label><input type="radio" disabled> ' + esc( pc.label ) + ' <span class="phf-preview-amount">' + money( pc.price ) + '</span></label>';
				} ).join( '' ) + '</div>';
			case 'payment_select':
				var first = priceChoice( ( field.choices || [] )[ 0 ] || '' );
				return '<select disabled><option>' + esc( first.label ) + ' · ' + money( first.price ) + '</option></select>';
			case 'payment_quantity':
				return '<input type="number" disabled value="1" min="1">';
			case 'payment_coupon':
				return '<div class="phf-preview-coupon"><input type="text" disabled placeholder="' + esc( 'Enter coupon code' ) + '"><span class="phf-preview-coupon-btn">Apply</span></div>';
			case 'payment_total':
				return '<div class="phf-preview-total"><span>' + esc( 'Total' ) + '</span><strong>' + money( 0 ) + '</strong></div>';
			case 'date':
				return '<input type="date" disabled>';
			case 'number':
				return '<input type="number" disabled placeholder="' + ph + '">';
			default:
				return '<input type="text" disabled placeholder="' + ph + '">';
		}
	}

	function fieldCard( field ) {
		var def = typeDef( field.type );
		var isSelected = parseInt( field.id, 10 ) === parseInt( selectedId, 10 );
		var hasLogic = field.conditional && field.conditional.enabled;

		if ( field.type === 'pagebreak' ) {
			return (
				'<div class="phf-card phf-card-pagebreak' + ( isSelected ? ' is-selected' : '' ) + '" data-id="' + field.id + '">' +
				'<div class="phf-card-tools"><span class="phf-move dashicons dashicons-move"></span>' + toolButtons() + '</div>' +
				'<div class="phf-pagebreak-line"><span class="dashicons dashicons-flag"></span> ' + esc( i18n.pageBreakNote || 'Page Break' ) + '</div>' +
				'</div>'
			);
		}

		if ( field.type === 'section' ) {
			return (
				'<div class="phf-card phf-card-section' + ( isSelected ? ' is-selected' : '' ) + '" data-id="' + field.id + '">' +
				'<div class="phf-card-tools"><span class="phf-move dashicons dashicons-move"></span>' + toolButtons() + '</div>' +
				'<div class="phf-section-preview"><h3>' + esc( field.label || 'Section' ) + '</h3>' +
				( field.description ? '<p>' + esc( field.description ) + '</p>' : '' ) + '</div>' +
				'</div>'
			);
		}

		var labelHtml = def.noLabel ? '<span class="phf-preview-label">' + esc( def.label ) + '</span>' :
			'<label class="phf-preview-label">' + esc( field.label || def.label ) + ( field.required ? ' <span class="phf-req">*</span>' : '' ) + '</label>';

		return (
			'<div class="phf-card' + ( isSelected ? ' is-selected' : '' ) + '" data-id="' + field.id + '">' +
			'<div class="phf-card-tools"><span class="phf-move dashicons dashicons-move"></span>' +
			( hasLogic ? '<span class="phf-logic-badge dashicons dashicons-randomize" title="Conditional logic active"></span>' : '' ) +
			toolButtons() + '</div>' +
			'<div class="phf-preview">' + labelHtml + previewInput( field ) +
			( field.description ? '<span class="phf-preview-desc">' + esc( field.description ) + '</span>' : '' ) +
			'</div>' +
			'</div>'
		);
	}

	function toolButtons() {
		return (
			'<button type="button" class="phf-tool phf-duplicate dashicons dashicons-admin-page" title="' + esc( i18n.duplicate || 'Duplicate' ) + '"></button>' +
			'<button type="button" class="phf-tool phf-delete dashicons dashicons-trash" title="' + esc( i18n.delete || 'Delete' ) + '"></button>'
		);
	}

	function renderCanvas() {
		$canvas.find( '.phf-card, .phf-empty' ).remove();

		if ( ! config.fields.length ) {
			$canvas.append( '<div class="phf-empty">' + esc( i18n.dropHere || 'Drop fields here' ) + '</div>' );
			return;
		}

		config.fields.forEach( function ( field ) {
			$canvas.append( fieldCard( field ) );
		} );
	}

	/* --------------------------------------------------------------------- */
	/* Options panel                                                         */
	/* --------------------------------------------------------------------- */

	function showPanel( tab ) {
		$( '.phf-tab' ).removeClass( 'is-active' );
		$( '.phf-tab[data-tab="' + tab + '"]' ).addClass( 'is-active' );
		$( '.phf-tab-panel' ).attr( 'hidden', true );
		$( '.phf-tab-panel[data-panel="' + tab + '"]' ).removeAttr( 'hidden' );
	}

	function selectField( id ) {
		selectedId = parseInt( id, 10 );
		$canvas.find( '.phf-card' ).removeClass( 'is-selected' );
		$canvas.find( '.phf-card[data-id="' + selectedId + '"]' ).addClass( 'is-selected' );
		renderOptions();

		// Jump to the Field Options panel, WPForms-style.
		if ( $( '.phf-tab[data-tab="options"]' ).length ) {
			showPanel( 'options' );
		}
	}

	function renderOptions() {
		var field = fieldById( selectedId );

		if ( ! field ) {
			$options.attr( 'hidden', true );
			$( '.phf-options-empty' ).show();
			return;
		}

		$( '.phf-options-empty' ).hide();
		$options.removeAttr( 'hidden' );

		var def = typeDef( field.type );
		var html = '<div class="phf-opt-header">' + esc( def.label ) + '</div>';

		// Tabs: general / logic.
		var showLogic = def.logic;
		html += '<div class="phf-opt-tabs">';
		html += '<button type="button" class="phf-opt-tab is-active" data-opt="general">' + esc( i18n.general || 'General' ) + '</button>';
		if ( showLogic ) {
			html += '<button type="button" class="phf-opt-tab" data-opt="logic">' + esc( i18n.logic || 'Logic' ) + '</button>';
		}
		html += '</div>';

		// General panel.
		html += '<div class="phf-opt-body" data-optpanel="general">';
		html += generalFields( field, def );
		html += '</div>';

		// Logic panel.
		if ( showLogic ) {
			html += '<div class="phf-opt-body" data-optpanel="logic" hidden>' + logicFields( field ) + '</div>';
		}

		$options.html( html );
	}

	function generalFields( field, def ) {
		var html = '';

		if ( field.type === 'pagebreak' ) {
			return '<p class="description">' + esc( i18n.pageBreakNote || 'Page break' ) + '</p>';
		}

		if ( ! def.noLabel || field.type === 'section' ) {
			html += row( i18n.label || 'Label', '<input type="text" class="widefat" data-prop="label" value="' + esc( field.label ) + '">' );
		}

		if ( field.type === 'section' ) {
			html += row( i18n.description || 'Description', '<textarea class="widefat" rows="2" data-prop="description">' + esc( field.description ) + '</textarea>' );
			return html;
		}

		if ( field.type === 'hidden' ) {
			html += row( i18n.defaultValue || 'Default value', '<input type="text" class="widefat" data-prop="default_value" value="' + esc( field.default_value || '' ) + '">' );
			return html;
		}

		if ( field.type === 'consent' ) {
			html += row( 'Consent text', '<textarea class="widefat" rows="2" data-prop="consent_text">' + esc( field.consent_text || '' ) + '</textarea>' );
			html += '<div class="phf-opt-row"><label class="phf-inline"><input type="checkbox" data-prop="required"' + ( field.required ? ' checked' : '' ) + '> ' + esc( i18n.required || 'Required' ) + '</label></div>';
			return html;
		}

		if ( field.type === 'payment_single' ) {
			html += row( i18n.price || 'Price', '<input type="number" step="0.01" min="0" class="widefat" data-prop="price" value="' + esc( field.price || '' ) + '">' );
			html += '<div class="phf-opt-row"><label class="phf-inline"><input type="checkbox" data-prop="user_price"' + ( field.user_price ? ' checked' : '' ) + '> ' + esc( i18n.userPrice || 'Let the visitor enter the amount (donations)' ) + '</label></div>';
		}

		if ( field.type === 'payment_total' ) {
			html += '<p class="description">' + esc( i18n.totalNote || 'Shows the live order total, calculated from the payment fields on this form.' ) + '</p>';
			return html;
		}

		if ( ! def.composite || ! def.composite.length ) {
			html += row( i18n.placeholder || 'Placeholder', '<input type="text" class="widefat" data-prop="placeholder" value="' + esc( field.placeholder ) + '">' );
		}

		if ( field.type === 'repeater' ) {
			html += row( 'Input label', '<input type="text" class="widefat" data-prop="sub_label" value="' + esc( field.sub_label || '' ) + '">' );
		}

		html += row( i18n.description || 'Description', '<input type="text" class="widefat" data-prop="description" value="' + esc( field.description ) + '">' );

		if ( def.choices ) {
			var isPriced = field.type === 'payment_multiple' || field.type === 'payment_select';
			html += '<div class="phf-opt-row"><label>' + esc( isPriced ? ( i18n.items || 'Items' ) : ( i18n.choices || 'Choices' ) ) + '</label>';
			if ( isPriced ) {
				html += '<p class="description">' + esc( i18n.itemsHint || 'Format each item as: Item name|Price. Example: Large|20' ) + '</p>';
			}
			html += '<div class="phf-choices">';
			( field.choices || [] ).forEach( function ( choice, c ) {
				html += choiceRow( choice, c );
			} );
			html += '</div><button type="button" class="button-link phf-add-choice">+ ' + esc( isPriced ? ( i18n.addItem || 'Add item' ) : ( i18n.addChoice || 'Add choice' ) ) + '</button></div>';

			// Quiz: choose the correct answer.
			if ( config.settings && config.settings.is_quiz ) {
				var opts = '<option value="">' + esc( 'None' ) + '</option>';
				( field.choices || [] ).forEach( function ( choice ) {
					opts += '<option value="' + esc( choice ) + '"' + ( field.correct === choice ? ' selected' : '' ) + '>' + esc( choice ) + '</option>';
				} );
				html += row( 'Correct answer (quiz)', '<select class="widefat" data-prop="correct">' + opts + '</select>' );
			}
		}

		html += '<div class="phf-opt-row"><label class="phf-inline"><input type="checkbox" data-prop="required"' + ( field.required ? ' checked' : '' ) + '> ' + esc( i18n.required || 'Required' ) + '</label></div>';

		return html;
	}

	function choiceRow( choice, index ) {
		return (
			'<div class="phf-choice-row">' +
			'<input type="text" class="phf-choice" data-choice="' + index + '" value="' + esc( choice ) + '">' +
			'<button type="button" class="button-link phf-remove-choice" data-choice="' + index + '">&times;</button>' +
			'</div>'
		);
	}

	function row( label, control ) {
		return '<div class="phf-opt-row"><label>' + esc( label ) + '</label>' + control + '</div>';
	}

	/* --------------------------------------------------------------------- */
	/* Conditional logic panel                                               */
	/* --------------------------------------------------------------------- */

	function logicFields( field ) {
		var cond = field.conditional || { enabled: 0, action: 'show', logic: 'and', rules: [] };
		var html = '';

		html += '<div class="phf-opt-row"><label class="phf-inline"><input type="checkbox" data-logic="enabled"' + ( cond.enabled ? ' checked' : '' ) + '> ' + esc( i18n.enableLogic || 'Enable conditional logic' ) + '</label></div>';

		if ( ! cond.enabled ) {
			return html;
		}

		html += '<div class="phf-logic-builder">';
		html += '<div class="phf-logic-summary">';
		html += '<select data-logic="action"><option value="show"' + ( cond.action === 'show' ? ' selected' : '' ) + '>' + esc( i18n.show || 'Show' ) + '</option><option value="hide"' + ( cond.action === 'hide' ? ' selected' : '' ) + '>' + esc( i18n.hide || 'Hide' ) + '</option></select> ';
		html += esc( i18n.thisField || 'this field if' ) + ' ';
		html += '<select data-logic="logic"><option value="and"' + ( cond.logic === 'and' ? ' selected' : '' ) + '>' + esc( i18n.allRules || 'all' ) + '</option><option value="or"' + ( cond.logic === 'or' ? ' selected' : '' ) + '>' + esc( i18n.anyRules || 'any' ) + '</option></select> ';
		html += esc( i18n.ofFollowing || 'of the following match:' );
		html += '</div>';

		html += '<div class="phf-logic-rules">';
		( cond.rules || [] ).forEach( function ( rule, r ) {
			html += ruleRow( rule, r, field.id );
		} );
		html += '</div>';
		html += '<button type="button" class="button-link phf-add-rule">+ ' + esc( i18n.addRule || 'Add rule' ) + '</button>';
		html += '</div>';

		return html;
	}

	function ruleRow( rule, index, selfId ) {
		var fieldOpts = '<option value="">' + esc( i18n.selectField || 'Select a field' ) + '</option>';
		config.fields.forEach( function ( f ) {
			if ( parseInt( f.id, 10 ) === parseInt( selfId, 10 ) ) {
				return; // A field cannot depend on itself.
			}
			if ( ! typeDef( f.type ).logic ) {
				return;
			}
			var lbl = f.label || typeDef( f.type ).label;
			fieldOpts += '<option value="' + f.id + '"' + ( parseInt( rule.field, 10 ) === parseInt( f.id, 10 ) ? ' selected' : '' ) + '>' + esc( lbl ) + '</option>';
		} );

		var ops = [
			[ 'is', i18n.is || 'is' ],
			[ 'is_not', i18n.isNot || 'is not' ],
			[ 'contains', i18n.contains || 'contains' ],
			[ 'empty', i18n.empty || 'is empty' ],
			[ 'not_empty', i18n.notEmpty || 'is not empty' ],
		];
		var opOpts = ops.map( function ( o ) {
			return '<option value="' + o[ 0 ] + '"' + ( rule.operator === o[ 0 ] ? ' selected' : '' ) + '>' + esc( o[ 1 ] ) + '</option>';
		} ).join( '' );

		var needsValue = rule.operator !== 'empty' && rule.operator !== 'not_empty';

		return (
			'<div class="phf-rule-row" data-rule="' + index + '">' +
			'<select data-rule-prop="field">' + fieldOpts + '</select>' +
			'<select data-rule-prop="operator">' + opOpts + '</select>' +
			'<input type="text" data-rule-prop="value" value="' + esc( rule.value || '' ) + '"' + ( needsValue ? '' : ' style="display:none"' ) + '>' +
			'<button type="button" class="button-link phf-remove-rule">&times;</button>' +
			'</div>'
		);
	}

	function ensureConditional( field ) {
		if ( ! field.conditional ) {
			field.conditional = { enabled: 0, action: 'show', logic: 'and', rules: [] };
		}
		return field.conditional;
	}

	/* --------------------------------------------------------------------- */
	/* Sidebar (add fields)                                                  */
	/* --------------------------------------------------------------------- */

	function bindSidebar() {
		// Click to add.
		$( '.phemightforms-add-field' ).on( 'click', function () {
			addField( $( this ).data( 'type' ) );
		} );

		// Drag from sidebar.
		$( '.phemightforms-add-field' ).on( 'dragstart', function ( e ) {
			e.originalEvent.dataTransfer.setData( 'text/phf-type', $( this ).data( 'type' ) );
			e.originalEvent.dataTransfer.effectAllowed = 'copy';
		} );

		// Sidebar tab switch.
		$( '.phf-tab' ).on( 'click', function () {
			showPanel( $( this ).data( 'tab' ) );
		} );
	}

	function bindCanvasDrop() {
		var canvasEl = $canvas.get( 0 );

		canvasEl.addEventListener( 'dragover', function ( e ) {
			if ( e.dataTransfer.types.indexOf( 'text/phf-type' ) === -1 ) {
				return;
			}
			e.preventDefault();
			$canvas.addClass( 'phf-dragover' );
		} );

		canvasEl.addEventListener( 'dragleave', function () {
			$canvas.removeClass( 'phf-dragover' );
		} );

		canvasEl.addEventListener( 'drop', function ( e ) {
			var type = e.dataTransfer.getData( 'text/phf-type' );
			$canvas.removeClass( 'phf-dragover' );
			if ( ! type ) {
				return;
			}
			e.preventDefault();

			// Work out drop position relative to existing cards.
			var atIndex = config.fields.length;
			$canvas.find( '.phf-card' ).each( function ( i ) {
				var box = this.getBoundingClientRect();
				if ( e.clientY < box.top + box.height / 2 ) {
					atIndex = i;
					return false;
				}
			} );

			addField( type, atIndex );
		} );
	}

	/* --------------------------------------------------------------------- */
	/* Canvas interactions                                                   */
	/* --------------------------------------------------------------------- */

	function bindCanvas() {
		$canvas.on( 'click', '.phf-card', function ( e ) {
			if ( $( e.target ).closest( '.phf-tool, .phf-move' ).length ) {
				return;
			}
			selectField( $( this ).data( 'id' ) );
		} );

		$canvas.on( 'click', '.phf-delete', function ( e ) {
			e.stopPropagation();
			if ( ! window.confirm( i18n.confirmDelete || 'Delete this field?' ) ) {
				return;
			}
			var id = $( this ).closest( '.phf-card' ).data( 'id' );
			var idx = fieldIndexById( id );
			if ( idx > -1 ) {
				config.fields.splice( idx, 1 );
			}
			if ( parseInt( id, 10 ) === parseInt( selectedId, 10 ) ) {
				selectedId = null;
			}
			renderCanvas();
			renderOptions();
			writeConfig();
		} );

		$canvas.on( 'click', '.phf-duplicate', function ( e ) {
			e.stopPropagation();
			var id = $( this ).closest( '.phf-card' ).data( 'id' );
			var idx = fieldIndexById( id );
			if ( idx > -1 ) {
				var copy = JSON.parse( JSON.stringify( config.fields[ idx ] ) );
				copy.id = nextId();
				delete copy.conditional; // Avoid duplicate logic referencing stale context.
				config.fields.splice( idx + 1, 0, copy );
				renderCanvas();
				writeConfig();
				selectField( copy.id );
			}
		} );

		$canvas.sortable( {
			handle: '.phf-move',
			items: '.phf-card',
			axis: 'y',
			placeholder: 'phf-sort-placeholder',
			forcePlaceholderSize: true,
			update: function () {
				var order = [];
				$canvas.find( '.phf-card' ).each( function () {
					var f = fieldById( $( this ).data( 'id' ) );
					if ( f ) {
						order.push( f );
					}
				} );
				config.fields = order;
				writeConfig();
			},
		} );
	}

	/* --------------------------------------------------------------------- */
	/* Options panel interactions                                            */
	/* --------------------------------------------------------------------- */

	function bindOptions() {
		// Opt tab switch.
		$options.on( 'click', '.phf-opt-tab', function () {
			var opt = $( this ).data( 'opt' );
			$options.find( '.phf-opt-tab' ).removeClass( 'is-active' );
			$( this ).addClass( 'is-active' );
			$options.find( '.phf-opt-body' ).attr( 'hidden', true );
			$options.find( '.phf-opt-body[data-optpanel="' + opt + '"]' ).removeAttr( 'hidden' );
		} );

		// Simple prop bindings.
		$options.on( 'input change', '[data-prop]', function () {
			var field = fieldById( selectedId );
			if ( ! field ) {
				return;
			}
			var prop = $( this ).data( 'prop' );
			field[ prop ] = this.type === 'checkbox' ? ( this.checked ? 1 : 0 ) : this.value;
			updateCard( field );
			writeConfig();
		} );

		// Choices.
		$options.on( 'input', '.phf-choice', function () {
			var field = fieldById( selectedId );
			field.choices[ $( this ).data( 'choice' ) ] = this.value;
			updateCard( field );
			writeConfig();
		} );

		$options.on( 'click', '.phf-add-choice', function () {
			var field = fieldById( selectedId );
			field.choices = field.choices || [];
			field.choices.push( '' );
			renderOptions();
			updateCard( field );
			writeConfig();
		} );

		$options.on( 'click', '.phf-remove-choice', function () {
			var field = fieldById( selectedId );
			field.choices.splice( $( this ).data( 'choice' ), 1 );
			renderOptions();
			updateCard( field );
			writeConfig();
		} );

		// Conditional logic.
		$options.on( 'change', '[data-logic]', function () {
			var field = fieldById( selectedId );
			var cond = ensureConditional( field );
			var prop = $( this ).data( 'logic' );
			cond[ prop ] = this.type === 'checkbox' ? ( this.checked ? 1 : 0 ) : this.value;
			renderOptions();
			updateCard( field );
			writeConfig();
		} );

		$options.on( 'click', '.phf-add-rule', function () {
			var field = fieldById( selectedId );
			var cond = ensureConditional( field );
			cond.rules = cond.rules || [];
			cond.rules.push( { field: '', operator: 'is', value: '' } );
			renderOptions();
			writeConfig();
		} );

		$options.on( 'click', '.phf-remove-rule', function () {
			var field = fieldById( selectedId );
			var r = $( this ).closest( '.phf-rule-row' ).data( 'rule' );
			field.conditional.rules.splice( r, 1 );
			renderOptions();
			updateCard( field );
			writeConfig();
		} );

		$options.on( 'change', '[data-rule-prop]', function () {
			var field = fieldById( selectedId );
			var r = $( this ).closest( '.phf-rule-row' ).data( 'rule' );
			var prop = $( this ).data( 'rule-prop' );
			field.conditional.rules[ r ][ prop ] = this.value;
			renderOptions();
			writeConfig();
		} );
	}

	function updateCard( field ) {
		var $card = $canvas.find( '.phf-card[data-id="' + field.id + '"]' );
		if ( $card.length ) {
			$card.replaceWith( fieldCard( field ) );
		}
	}

	/* --------------------------------------------------------------------- */
	/* Settings panel                                                        */
	/* --------------------------------------------------------------------- */

	function renderSettings() {
		$( '[data-setting]' ).each( function () {
			var key = $( this ).data( 'setting' );
			var val = config.settings[ key ];
			if ( this.type === 'checkbox' ) {
				this.checked = !! val;
			} else if ( typeof val !== 'undefined' ) {
				$( this ).val( val );
			}
		} );

		$( '[data-setting]' ).on( 'input change', function () {
			var key = $( this ).data( 'setting' );
			config.settings[ key ] = this.type === 'checkbox' ? ( this.checked ? 1 : 0 ) : this.value;
			writeConfig();
		} );
	}

	/* --------------------------------------------------------------------- */
	/* Init                                                                  */
	/* --------------------------------------------------------------------- */

	$( function () {
		$config = $( '#phemightforms-config' );
		if ( ! $config.length ) {
			return;
		}

		$canvas = $( '#phemightforms-canvas' );
		$options = $( '#phemightforms-options' );
		fieldTypes = ( window.PhemightFormsAdmin && window.PhemightFormsAdmin.fieldTypes ) || {};
		i18n = ( window.PhemightFormsAdmin && window.PhemightFormsAdmin.i18n ) || {};

		readConfig();
		pushHistory();
		renderCanvas();
		renderSettings();
		renderOptions();

		bindSidebar();
		bindCanvasDrop();
		bindCanvas();
		bindOptions();

		$( document ).on( 'keydown', function ( e ) {
			if ( ( e.ctrlKey || e.metaKey ) && e.key === 'z' && ! e.shiftKey ) {
				e.preventDefault();
				undo();
			}
			if ( ( e.ctrlKey || e.metaKey ) && ( e.key === 'y' || ( e.key === 'z' && e.shiftKey ) ) ) {
				e.preventDefault();
				redo();
			}
		} );

		$( '#phemightforms-builder-form' ).on( 'submit', function () {
			writeConfig( true );
		} );
		writeConfig( true );
	} );

	$( '#phf-select-all' ).on( 'change', function () {
		$( 'input[name="entry_ids[]"]' ).prop( 'checked', this.checked );
	} );

	/**
	 * Branded horizontal scroll indicator for the mobile topbar nav.
	 */
	function updateNavScrollUI( $wrap ) {
		var $nav = $wrap.find( '.phf-topbar-nav' );
		var $track = $wrap.find( '.phf-nav-scroll-indicator' );
		var $thumb = $wrap.find( '.phf-nav-scroll-thumb' );
		var el = $nav.get( 0 );

		if ( ! el || ! $track.length || ! $thumb.length ) {
			return;
		}

		var scrollWidth = el.scrollWidth;
		var clientWidth = el.clientWidth;
		var maxScroll = scrollWidth - clientWidth;

		if ( maxScroll <= 1 ) {
			$track.removeClass( 'is-visible' );
			$wrap.removeClass( 'is-scrolled-left is-at-end' );
			return;
		}

		$track.addClass( 'is-visible' );

		var thumbWidth = Math.max( ( clientWidth / scrollWidth ) * 100, 14 );
		var left = maxScroll ? ( el.scrollLeft / maxScroll ) * ( 100 - thumbWidth ) : 0;

		$thumb.css( {
			width: thumbWidth + '%',
			left: left + '%',
		} );

		$wrap.toggleClass( 'is-scrolled-left', el.scrollLeft > 4 );
		$wrap.toggleClass( 'is-at-end', el.scrollLeft >= maxScroll - 4 );
	}

	$( '.phf-topbar-nav-wrap' ).each( function () {
		var $wrap = $( this );
		var $nav = $wrap.find( '.phf-topbar-nav' );

		$nav.on( 'scroll', function () {
			updateNavScrollUI( $wrap );
		} );

		updateNavScrollUI( $wrap );
	} );

	$( window ).on( 'resize orientationchange', function () {
		$( '.phf-topbar-nav-wrap' ).each( function () {
			updateNavScrollUI( $( this ) );
		} );
	} );
} )( jQuery );
