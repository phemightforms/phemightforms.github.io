<?php
/**
 * Entries listing and detail view.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Form;
use PhemightForms\Install;
use PhemightForms\Export;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Displays stored submissions and allows deletion.
 */
class Entries {

	/**
	 * Handle redirecting actions before any admin output is sent.
	 */
	public function __construct() {
		add_action( 'admin_init', [ self::class, 'handle_actions' ] );
	}

	/**
	 * Process actions that end in a redirect. These must run on admin_init,
	 * before the admin header is output, or the redirect fails.
	 */
	public static function handle_actions() {
		$page = isset( $_REQUEST['page'] ) ? sanitize_key( wp_unslash( $_REQUEST['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( Admin::SLUG . '-entries' !== $page ) {
			return;
		}

		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! in_array( $action, [ 'delete', 'bulk', 'save_meta' ], true ) ) {
			return;
		}

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		if ( 'delete' === $action ) {
			self::handle_delete();
		}

		if ( 'bulk' === $action ) {
			self::handle_bulk();
		}

		if ( 'save_meta' === $action ) {
			self::handle_save_meta();
		}
	}

	/**
	 * Route to list or single view.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$entry_id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( $entry_id ) {
			self::render_single( $entry_id );
			return;
		}

		self::render_list();
	}

	/**
	 * Render the table of entries, optionally filtered by form.
	 */
	private static function render_list() {
		global $wpdb;

		$table   = Install::entries_table();
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$where = '1=1';
		$args  = [];

		if ( $form_id ) {
			$where .= ' AND form_id = %d';
			$args[] = $form_id;
		}

		if ( $search ) {
			$where .= ' AND fields LIKE %s';
			$args[] = '%' . $wpdb->esc_like( $search ) . '%';
		}

		if ( ! empty( $args ) ) {
			$sql  = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC";
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, ...$args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		} else {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE 1=1 ORDER BY created_at DESC" ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		$forms = Form::all();
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'entries' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Entries', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'View and manage form submissions.', 'phemightforms' ); ?></p>
					</div>
					<a href="<?php echo esc_url( Export::export_url( $form_id ) ); ?>" class="phf-btn phf-btn-primary">
						<span class="dashicons dashicons-download"></span>
						<?php esc_html_e( 'Export CSV', 'phemightforms' ); ?>
					</a>
				</div>

				<form method="get" class="phf-filter-bar">
					<input type="hidden" name="page" value="<?php echo esc_attr( Admin::SLUG . '-entries' ); ?>">
					<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search entries…', 'phemightforms' ); ?>">
					<select name="form" onchange="this.form.submit()">
						<option value="0"><?php esc_html_e( 'All forms', 'phemightforms' ); ?></option>
						<?php foreach ( $forms as $post ) : ?>
							<option value="<?php echo esc_attr( $post->ID ); ?>" <?php selected( $form_id, $post->ID ); ?>><?php echo esc_html( $post->post_title ); ?></option>
						<?php endforeach; ?>
					</select>
				</form>

				<div class="phf-card-panel phf-table-panel">
					<form method="post" id="phf-bulk-form" action="<?php echo esc_url( admin_url( 'admin.php?page=' . Admin::SLUG . '-entries&action=bulk' ) ); ?>">
						<?php wp_nonce_field( 'phemightforms_bulk_entries' ); ?>
						<div class="phf-bulk-bar">
							<select name="bulk_action">
								<option value=""><?php esc_html_e( 'Bulk actions', 'phemightforms' ); ?></option>
								<option value="read"><?php esc_html_e( 'Mark as read', 'phemightforms' ); ?></option>
								<option value="unread"><?php esc_html_e( 'Mark as unread', 'phemightforms' ); ?></option>
								<option value="delete"><?php esc_html_e( 'Delete', 'phemightforms' ); ?></option>
							</select>
							<button type="submit" class="phf-btn phf-btn-ghost phf-btn-sm"><?php esc_html_e( 'Apply', 'phemightforms' ); ?></button>
						</div>
					<table class="phf-table">
							<thead>
								<tr>
									<th class="phf-col-check"><input type="checkbox" id="phf-select-all"></th>
									<th><?php esc_html_e( 'ID', 'phemightforms' ); ?></th>
								<th><?php esc_html_e( 'Form', 'phemightforms' ); ?></th>
								<th><?php esc_html_e( 'Preview', 'phemightforms' ); ?></th>
								<th><?php esc_html_e( 'Date', 'phemightforms' ); ?></th>
								<th class="phf-col-actions"><?php esc_html_e( 'Actions', 'phemightforms' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( ! $rows ) : ?>
								<tr><td colspan="5" class="phf-pad"><?php esc_html_e( 'No entries yet.', 'phemightforms' ); ?></td></tr>
							<?php endif; ?>
							<?php foreach ( $rows as $row ) : ?>
								<?php
								$data     = json_decode( $row->fields, true );
								$preview  = is_array( $data ) && $data ? ( $data[0]['label'] . ': ' . $data[0]['value'] ) : '';
								$form     = new Form( $row->form_id );
								$view_url = add_query_arg(
									[
										'page'  => Admin::SLUG . '-entries',
										'entry' => $row->id,
									],
									admin_url( 'admin.php' )
								);
								$del_url  = wp_nonce_url(
									add_query_arg(
										[
											'page'   => Admin::SLUG . '-entries',
											'action' => 'delete',
											'entry'  => $row->id,
										],
										admin_url( 'admin.php' )
									),
									'phemightforms_delete_entry_' . $row->id
								);
								?>
								<tr>
									<td data-label=""><input type="checkbox" name="entry_ids[]" value="<?php echo esc_attr( $row->id ); ?>"></td>
									<td data-label="<?php esc_attr_e( 'ID', 'phemightforms' ); ?>">#<?php echo esc_html( $row->id ); ?></td>
									<td data-label="<?php esc_attr_e( 'Form', 'phemightforms' ); ?>">
										<?php echo esc_html( $form->exists() ? $form->title : __( '(deleted form)', 'phemightforms' ) ); ?>
										<?php if ( 'read' !== $row->status ) : ?>
											<span class="phf-badge phf-badge-new"><?php esc_html_e( 'New', 'phemightforms' ); ?></span>
										<?php endif; ?>
									</td>
									<td data-label="<?php esc_attr_e( 'Preview', 'phemightforms' ); ?>"><?php echo esc_html( wp_trim_words( $preview, 12 ) ); ?></td>
									<td data-label="<?php esc_attr_e( 'Date', 'phemightforms' ); ?>"><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $row->created_at ) ); ?></td>
									<td class="phf-row-actions">
										<a href="<?php echo esc_url( $view_url ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-visibility"></span><?php esc_html_e( 'View', 'phemightforms' ); ?></a>
										<a href="<?php echo esc_url( $del_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this entry?', 'phemightforms' ) ); ?>');" class="phf-btn phf-btn-ghost phf-btn-sm phf-btn-danger"><span class="dashicons dashicons-trash"></span><?php esc_html_e( 'Delete', 'phemightforms' ); ?></a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render a single entry's full details.
	 *
	 * @param int $entry_id Entry row ID.
	 */
	private static function render_single( $entry_id ) {
		global $wpdb;

		$table = Install::entries_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $entry_id ) ); // phpcs:ignore WordPress.DB

		if ( ! $row ) {
			echo '<div class="wrap phemightforms-wrap phf-page">';
			Admin::header( 'entries' );
			echo '<div class="phf-page-body"><div class="phf-card-panel"><div class="phf-empty-state"><p>' . esc_html__( 'Entry not found.', 'phemightforms' ) . '</p></div></div></div></div>';
			return;
		}

		// Mark as read.
		if ( 'read' !== $row->status ) {
			$wpdb->update( $table, [ 'status' => 'read' ], [ 'id' => $entry_id ], [ '%s' ], [ '%d' ] ); // phpcs:ignore WordPress.DB
		}

		$data      = json_decode( $row->fields, true );
		$back_url  = add_query_arg( [ 'page' => Admin::SLUG . '-entries' ], admin_url( 'admin.php' ) );
		$form      = new Form( $row->form_id );
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'entries' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php
						/* translators: %d: entry ID number. */
						printf( esc_html__( 'Entry #%d', 'phemightforms' ), (int) $entry_id );
						?></h2>
						<p class="phf-muted"><?php echo esc_html( $form->exists() ? $form->title : __( '(deleted form)', 'phemightforms' ) ); ?></p>
					</div>
				</div>

				<a href="<?php echo esc_url( $back_url ); ?>" class="phf-back-link"><span class="dashicons dashicons-arrow-left-alt2"></span><?php esc_html_e( 'Back to entries', 'phemightforms' ); ?></a>

				<div class="phf-entry-detail">
					<table>
						<tbody>
							<tr><th><?php esc_html_e( 'Form', 'phemightforms' ); ?></th><td><?php echo esc_html( $form->exists() ? $form->title : __( '(deleted form)', 'phemightforms' ) ); ?></td></tr>
							<?php if ( is_array( $data ) ) : ?>
								<?php foreach ( $data as $field ) : ?>
									<tr>
										<th><?php echo esc_html( $field['label'] ); ?></th>
										<td>
											<?php if ( isset( $field['type'] ) && 'signature' === $field['type'] && 0 === strpos( (string) $field['value'], 'data:image' ) ) : ?>
												<img src="<?php echo esc_attr( $field['value'] ); ?>" alt="<?php esc_attr_e( 'Signature', 'phemightforms' ); ?>" style="max-width:300px;border:1px solid #e2e8f0;border-radius:8px;">
											<?php elseif ( filter_var( $field['value'], FILTER_VALIDATE_URL ) ) : ?>
												<a href="<?php echo esc_url( $field['value'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $field['value'] ); ?></a>
											<?php else : ?>
												<?php echo nl2br( esc_html( $field['value'] ) ); ?>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							<?php endif; ?>
							<tr><th><?php esc_html_e( 'Submitted', 'phemightforms' ); ?></th><td><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $row->created_at ) ); ?></td></tr>
							<tr><th><?php esc_html_e( 'IP address', 'phemightforms' ); ?></th><td><?php echo esc_html( $row->ip_address ); ?></td></tr>
						</tbody>
					</table>
				</div>

				<div class="phf-card-panel phf-pad" style="margin-top:1rem;">
					<h3><?php esc_html_e( 'Notes & tags', 'phemightforms' ); ?></h3>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=' . Admin::SLUG . '-entries&action=save_meta&entry=' . $entry_id ) ); ?>">
						<?php wp_nonce_field( 'phemightforms_entry_meta_' . $entry_id ); ?>
						<div class="phf-field-row">
							<label for="phf-entry-tags"><?php esc_html_e( 'Tags (comma separated)', 'phemightforms' ); ?></label>
							<input type="text" id="phf-entry-tags" name="tags" value="<?php echo esc_attr( isset( $row->tags ) ? $row->tags : '' ); ?>">
						</div>
						<div class="phf-field-row">
							<label for="phf-entry-notes"><?php esc_html_e( 'Internal notes', 'phemightforms' ); ?></label>
							<textarea id="phf-entry-notes" name="notes" rows="4"><?php echo esc_textarea( isset( $row->notes ) ? $row->notes : '' ); ?></textarea>
						</div>
						<button type="submit" class="phf-btn phf-btn-primary"><?php esc_html_e( 'Save notes', 'phemightforms' ); ?></button>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Delete an entry after verifying the nonce.
	 */
	private static function handle_delete() {
		global $wpdb;

		$entry_id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0;

		check_admin_referer( 'phemightforms_delete_entry_' . $entry_id );

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$wpdb->delete( Install::entries_table(), [ 'id' => $entry_id ], [ '%d' ] ); // phpcs:ignore WordPress.DB

		wp_safe_redirect( add_query_arg( [ 'page' => Admin::SLUG . '-entries' ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Bulk update or delete entries.
	 */
	private static function handle_bulk() {
		check_admin_referer( 'phemightforms_bulk_entries' );

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		global $wpdb;
		$table  = Install::entries_table();
		$action = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
		$ids    = isset( $_POST['entry_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['entry_ids'] ) ) : [];

		foreach ( $ids as $id ) {
			if ( 'delete' === $action ) {
				$wpdb->delete( $table, [ 'id' => $id ], [ '%d' ] ); // phpcs:ignore WordPress.DB
			} elseif ( 'read' === $action ) {
				$wpdb->update( $table, [ 'status' => 'read' ], [ 'id' => $id ], [ '%s' ], [ '%d' ] ); // phpcs:ignore WordPress.DB
			} elseif ( 'unread' === $action ) {
				$wpdb->update( $table, [ 'status' => 'unread' ], [ 'id' => $id ], [ '%s' ], [ '%d' ] ); // phpcs:ignore WordPress.DB
			}
		}

		wp_safe_redirect( add_query_arg( [ 'page' => Admin::SLUG . '-entries' ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Save entry notes and tags.
	 */
	private static function handle_save_meta() {
		$entry_id = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0;
		check_admin_referer( 'phemightforms_entry_meta_' . $entry_id );

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB
			Install::entries_table(),
			[
				'notes' => isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '',
				'tags'  => isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '',
			],
			[ 'id' => $entry_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);

		wp_safe_redirect(
			add_query_arg(
				[
					'page'  => Admin::SLUG . '-entries',
					'entry' => $entry_id,
					'saved' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
