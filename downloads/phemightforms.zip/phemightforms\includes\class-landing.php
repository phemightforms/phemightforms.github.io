<?php
/**
 * Distraction-free form landing pages.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers a clean landing-page URL for each form.
 */
class Landing {

	/**
	 * Query var for landing page requests.
	 */
	const QUERY_VAR = 'phemightforms_landing';

	/**
	 * Hook rewrite rules and template.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_rewrite' ] );
		add_filter( 'query_vars', [ $this, 'query_vars' ] );
		add_action( 'template_redirect', [ $this, 'render' ] );
	}

	/**
	 * Add rewrite tag and rule.
	 */
	public function register_rewrite() {
		add_rewrite_tag( '%' . self::QUERY_VAR . '%', '([0-9]+)' );
		add_rewrite_rule( '^phemight-form/([0-9]+)/?$', 'index.php?' . self::QUERY_VAR . '=$matches[1]', 'top' );
	}

	/**
	 * Register the query var.
	 *
	 * @param array $vars Query vars.
	 * @return array
	 */
	public function query_vars( $vars ) {
		$vars[] = self::QUERY_VAR;
		return $vars;
	}

	/**
	 * Render a minimal landing page when the query var is set.
	 */
	public function render() {
		$form_id = absint( get_query_var( self::QUERY_VAR ) );
		if ( ! $form_id ) {
			return;
		}

		$form = new Form( $form_id );
		if ( ! $form->exists() ) {
			status_header( 404 );
			exit;
		}

		$frontend = new Frontend();
		$html     = $frontend->render( $form );

		wp_enqueue_style( 'phemightforms' );
		wp_enqueue_script( 'phemightforms' );
		Captcha::enqueue();

		wp_add_inline_style(
			'phemightforms',
			'body.phf-landing{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(160deg,#faf7f1 0%,#fdf4dd 100%);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;padding:2rem 1rem;}'
			. '.phf-landing-wrap{width:100%;max-width:720px;}'
		);

		status_header( 200 );
		nocache_headers();

		?><!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php echo esc_html( $form->title ); ?> · <?php bloginfo( 'name' ); ?></title>
			<?php wp_head(); ?>
		</head>
		<body class="phf-landing">
			<div class="phf-landing-wrap">
				<?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in Frontend. ?>
			</div>
			<?php wp_footer(); ?>
		</body>
		</html>
		<?php
		exit;
	}

	/**
	 * Public URL for a form landing page.
	 *
	 * @param int $form_id Form ID.
	 * @return string
	 */
	public static function url( $form_id ) {
		return home_url( 'phemight-form/' . absint( $form_id ) . '/' );
	}
}
