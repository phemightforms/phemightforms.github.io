<?php
/**
 * Gutenberg block that inserts a form by ID.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers a dynamic block wrapping the shortcode renderer.
 */
class Block {

	/**
	 * Hook block registration.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register' ] );
	}

	/**
	 * Register the block type and its editor script.
	 */
	public function register() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		wp_register_script(
			'phemightforms-block',
			PHEMIGHTFORMS_URL . 'assets/block/block.js',
			[ 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n' ],
			PHEMIGHTFORMS_VERSION,
			true
		);

		$forms   = Form::all();
		$options = [];
		foreach ( $forms as $form ) {
			$options[] = [
				'value' => $form->ID,
				'label' => $form->post_title ? $form->post_title : sprintf(
					/* translators: %d: form ID number. */
					__( 'Form #%d', 'phemightforms' ),
					$form->ID
				),
			];
		}

		wp_localize_script( 'phemightforms-block', 'PhemightFormsBlock', [ 'forms' => $options ] );

		register_block_type(
			'phemightforms/form',
			[
				'editor_script'   => 'phemightforms-block',
				'render_callback' => [ $this, 'render' ],
				'attributes'      => [
					'formId' => [
						'type'    => 'number',
						'default' => 0,
					],
				],
			]
		);
	}

	/**
	 * Server-side render for the block.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render( $attributes ) {
		$form_id = isset( $attributes['formId'] ) ? absint( $attributes['formId'] ) : 0;

		if ( ! $form_id ) {
			return '';
		}

		return do_shortcode( sprintf( '[phemightform id="%d"]', $form_id ) );
	}
}
