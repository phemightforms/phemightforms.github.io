<?php
/**
 * About Us page: plugin info, features, and support links.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the About Us page.
 */
class AboutPage {

	/**
	 * Render the About Us page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$features = [
			__( 'Drag & drop form builder with 30+ field types', 'phemightforms' ),
			__( '63+ premade form templates across 12 categories', 'phemightforms' ),
			__( 'Payments: Stripe, PayPal, crypto, and 8 more gateways', 'phemightforms' ),
			__( 'Conditional logic, multi page forms, and progress bars', 'phemightforms' ),
			__( 'Surveys, polls, quizzes with graded scoring', 'phemightforms' ),
			__( 'CAPTCHA: hCaptcha, reCAPTCHA, and Cloudflare Turnstile', 'phemightforms' ),
			__( 'GDPR tools, privacy compliance, and data retention', 'phemightforms' ),
			__( 'Webhooks, Mailchimp, Google Sheets, and Akismet', 'phemightforms' ),
			__( 'SMTP email delivery', 'phemightforms' ),
			__( 'Form landing pages, save & resume, and abandonment tracking', 'phemightforms' ),
			__( 'Entry automation, reports, and analytics dashboard', 'phemightforms' ),
			__( 'Website & Form Backup and Login & Registration', 'phemightforms' ),
		];
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'about' ); ?>

			<div class="phf-page-body phf-about-page">
				<div class="phf-about-hero">
					<img class="phf-about-logo" src="<?php echo esc_url( PHEMIGHTFORMS_URL . 'assets/images/icon-topbar.png' ); ?>" alt="PhemightForms">
					<div>
						<h2><?php esc_html_e( 'About PhemightForms', 'phemightforms' ); ?></h2>
						<p><?php esc_html_e( 'The complete WordPress form builder: powerful, beautiful, and free. Build contact forms, payment forms, surveys, quizzes, and more without writing a single line of code.', 'phemightforms' ); ?></p>
						<div class="phf-about-meta">
							<span class="phf-badge phf-badge-gold"><?php
							/* translators: %s: plugin version number. */
							printf( esc_html__( 'Version %s', 'phemightforms' ), esc_html( PHEMIGHTFORMS_VERSION ) );
							?></span>
							<span class="phf-muted"><?php esc_html_e( 'Made with care for WordPress', 'phemightforms' ); ?></span>
						</div>
					</div>
				</div>

				<div class="phf-stat-grid phf-about-stats">
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-gold"><span class="dashicons dashicons-forms"></span></span>
						<div><span class="phf-stat-number">63+</span><span class="phf-stat-label"><?php esc_html_e( 'Form Templates', 'phemightforms' ); ?></span></div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-blue"><span class="dashicons dashicons-admin-plugins"></span></span>
						<div><span class="phf-stat-number">50+</span><span class="phf-stat-label"><?php esc_html_e( 'Addons Included', 'phemightforms' ); ?></span></div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-green"><span class="dashicons dashicons-money-alt"></span></span>
						<div><span class="phf-stat-number">11</span><span class="phf-stat-label"><?php esc_html_e( 'Payment Gateways', 'phemightforms' ); ?></span></div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-amber"><span class="dashicons dashicons-shield"></span></span>
						<div><span class="phf-stat-number">3</span><span class="phf-stat-label"><?php esc_html_e( 'CAPTCHA Providers', 'phemightforms' ); ?></span></div>
					</div>
				</div>

				<div class="phf-about-grid">
					<div class="phf-card-panel phf-settings-card">
						<div class="phf-panel-head">
							<h3><span class="dashicons dashicons-star-filled"></span> <?php esc_html_e( 'Everything Included', 'phemightforms' ); ?></h3>
							<span class="phf-muted"><?php esc_html_e( 'Every feature below is built in and free. No upgrade required.', 'phemightforms' ); ?></span>
						</div>
						<div class="phf-card-body">
							<ul class="phf-about-features">
								<?php foreach ( $features as $feature ) : ?>
									<li><span class="dashicons dashicons-yes-alt"></span><span><?php echo esc_html( $feature ); ?></span></li>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>

					<div class="phf-about-side">
						<div class="phf-card-panel phf-settings-card">
							<div class="phf-panel-head">
								<h3><span class="dashicons dashicons-admin-links"></span> <?php esc_html_e( 'Quick Links', 'phemightforms' ); ?></h3>
							</div>
							<div class="phf-card-body phf-card-body-compact">
								<ul class="phf-about-links">
								<li><a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG_FORMS, 'action' => 'new' ], admin_url( 'admin.php' ) ) ); ?>"><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'Create a Form', 'phemightforms' ); ?></a></li>
								<li><a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-templates' ], admin_url( 'admin.php' ) ) ); ?>"><span class="dashicons dashicons-layout"></span> <?php esc_html_e( 'Browse Templates', 'phemightforms' ); ?></a></li>
								<li><a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-addons' ], admin_url( 'admin.php' ) ) ); ?>"><span class="dashicons dashicons-admin-plugins"></span> <?php esc_html_e( 'View Addons', 'phemightforms' ); ?></a></li>
								<li><a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-privacy' ], admin_url( 'admin.php' ) ) ); ?>"><span class="dashicons dashicons-privacy"></span> <?php esc_html_e( 'Privacy Compliance', 'phemightforms' ); ?></a></li>
								<li><a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-captcha' ], admin_url( 'admin.php' ) ) ); ?>"><span class="dashicons dashicons-shield"></span> <?php esc_html_e( 'CAPTCHA Settings', 'phemightforms' ); ?></a></li>
								</ul>
							</div>
						</div>

						<div class="phf-card-panel phf-settings-card phf-about-community">
							<div class="phf-panel-head">
								<h3><span class="dashicons dashicons-groups"></span> <?php esc_html_e( 'Community', 'phemightforms' ); ?></h3>
							</div>
							<div class="phf-card-body">
								<p class="phf-muted"><?php esc_html_e( 'PhemightForms is built for creators, businesses, and developers who want professional forms without the premium price tag.', 'phemightforms' ); ?></p>
								<p class="phf-muted"><?php esc_html_e( 'Have a feature idea or found a bug? We would love to hear from you.', 'phemightforms' ); ?></p>
								<a href="https://phemightforms.com" target="_blank" rel="noopener" class="phf-btn phf-btn-primary"><?php esc_html_e( 'Visit phemightforms.com', 'phemightforms' ); ?></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
