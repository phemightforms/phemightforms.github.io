<?php
/**
 * Website & Form Backup admin screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Export;
use PhemightForms\Form;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Export/import forms and entry CSVs.
 */
class BackupPage {

	const LOG_OPTION = 'phemightforms_backup_log';

	/**
	 * Register download / import handlers.
	 */
	public function __construct() {
		add_action( 'admin_post_phemightforms_backup_export_forms', [ $this, 'export_forms' ] );
		add_action( 'admin_post_phemightforms_backup_export_entries', [ $this, 'export_entries' ] );
		add_action( 'admin_post_phemightforms_backup_import', [ $this, 'import_forms' ] );
	}

	/**
	 * Render the backup page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'backup' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Website & Form Backup', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'Export forms, download entry CSVs, and restore from JSON.', 'phemightforms' ); ?></p>
					</div>
				</div>

				<?php self::render_tools(); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Backup tools UI.
	 */
	private static function render_tools() {
		$forms = Form::all();
		$log   = get_option( self::LOG_OPTION, [] );
		if ( ! is_array( $log ) ) {
			$log = [];
		}

		$imported = isset( $_GET['imported'] ) ? absint( $_GET['imported'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$error    = isset( $_GET['backup_error'] ) ? sanitize_text_field( wp_unslash( $_GET['backup_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<?php if ( $imported > 0 ) : ?>
			<div class="phf-notice phf-notice-success">
				<span class="dashicons dashicons-yes-alt"></span>
				<?php
				/* translators: %d: number of forms imported */
				printf( esc_html( _n( '%d form imported.', '%d forms imported.', $imported, 'phemightforms' ) ), $imported );
				?>
			</div>
		<?php endif; ?>

		<?php if ( $error ) : ?>
			<div class="phf-notice phf-notice-error">
				<span class="dashicons dashicons-warning"></span>
				<?php echo esc_html( $error ); ?>
			</div>
		<?php endif; ?>

		<div class="phf-settings-grid">
			<div class="phf-card-panel phf-settings-card">
				<div class="phf-panel-head">
					<h3><span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Export all forms', 'phemightforms' ); ?></h3>
					<span class="phf-muted"><?php esc_html_e( 'Download every form as a JSON backup (ZIP when available).', 'phemightforms' ); ?></span>
				</div>
				<div class="phf-card-body">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="phemightforms_backup_export_forms">
						<?php wp_nonce_field( 'phemightforms_backup_export_forms' ); ?>
						<button type="submit" class="phf-btn phf-btn-primary" <?php disabled( empty( $forms ) ); ?>><?php esc_html_e( 'Export forms', 'phemightforms' ); ?></button>
					</form>
				</div>
			</div>

			<div class="phf-card-panel phf-settings-card">
				<div class="phf-panel-head">
					<h3><span class="dashicons dashicons-media-spreadsheet"></span> <?php esc_html_e( 'Export entries CSV', 'phemightforms' ); ?></h3>
					<span class="phf-muted"><?php esc_html_e( 'Download submissions for a selected form.', 'phemightforms' ); ?></span>
				</div>
				<div class="phf-card-body">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="phemightforms_backup_export_entries">
						<?php wp_nonce_field( 'phemightforms_backup_export_entries' ); ?>
						<div class="phf-field-row">
							<label for="phf-backup-form"><?php esc_html_e( 'Form', 'phemightforms' ); ?></label>
							<select id="phf-backup-form" name="form_id" required>
								<option value=""><?php esc_html_e( 'Select a form…', 'phemightforms' ); ?></option>
								<?php foreach ( $forms as $post ) : ?>
									<option value="<?php echo esc_attr( $post->ID ); ?>"><?php echo esc_html( $post->post_title ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<button type="submit" class="phf-btn phf-btn-primary" <?php disabled( empty( $forms ) ); ?>><?php esc_html_e( 'Download CSV', 'phemightforms' ); ?></button>
					</form>
				</div>
			</div>

			<div class="phf-card-panel phf-settings-card">
				<div class="phf-panel-head">
					<h3><span class="dashicons dashicons-upload"></span> <?php esc_html_e( 'Import forms', 'phemightforms' ); ?></h3>
					<span class="phf-muted"><?php esc_html_e( 'Upload a form JSON file (single form or array of forms).', 'phemightforms' ); ?></span>
				</div>
				<div class="phf-card-body">
					<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="phemightforms_backup_import">
						<?php wp_nonce_field( 'phemightforms_backup_import' ); ?>
						<div class="phf-field-row">
							<label for="phf-backup-import"><?php esc_html_e( 'JSON file', 'phemightforms' ); ?></label>
							<input type="file" id="phf-backup-import" name="backup_file" accept="application/json,.json" required>
						</div>
						<button type="submit" class="phf-btn phf-btn-primary"><?php esc_html_e( 'Import', 'phemightforms' ); ?></button>
					</form>
				</div>
			</div>
		</div>

		<div class="phf-card-panel phf-table-panel" style="margin-top:20px;">
			<div class="phf-panel-head">
				<h3><?php esc_html_e( 'Recent backup actions', 'phemightforms' ); ?></h3>
			</div>
			<?php if ( empty( $log ) ) : ?>
				<div class="phf-card-body">
					<p class="phf-muted"><?php esc_html_e( 'No backup actions yet.', 'phemightforms' ); ?></p>
				</div>
			<?php else : ?>
				<table class="phf-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'When', 'phemightforms' ); ?></th>
							<th><?php esc_html_e( 'Action', 'phemightforms' ); ?></th>
							<th><?php esc_html_e( 'Details', 'phemightforms' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( array_slice( $log, 0, 20 ) as $row ) : ?>
							<tr>
								<td><?php echo esc_html( isset( $row['time'] ) ? $row['time'] : '' ); ?></td>
								<td><?php echo esc_html( isset( $row['action'] ) ? $row['action'] : '' ); ?></td>
								<td><?php echo esc_html( isset( $row['detail'] ) ? $row['detail'] : '' ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Append a log entry.
	 *
	 * @param string $action Action label.
	 * @param string $detail Detail text.
	 */
	public static function log( $action, $detail = '' ) {
		$log = get_option( self::LOG_OPTION, [] );
		if ( ! is_array( $log ) ) {
			$log = [];
		}

		array_unshift(
			$log,
			[
				'time'   => gmdate( 'Y-m-d H:i:s' ),
				'action' => $action,
				'detail' => $detail,
			]
		);

		$log = array_slice( $log, 0, 50 );
		update_option( self::LOG_OPTION, $log, false );
	}

	/**
	 * Guard capability for admin-post handlers.
	 */
	private function assert_capability() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}
	}

	/**
	 * Export all forms as ZIP (or single JSON fallback).
	 */
	public function export_forms() {
		$this->assert_capability();
		check_admin_referer( 'phemightforms_backup_export_forms' );

		$posts = Form::all();
		$items = [];

		foreach ( $posts as $post ) {
			$form = new Form( $post->ID );
			if ( method_exists( $form, 'export_json' ) ) {
				$decoded = json_decode( $form->export_json(), true );
				if ( is_array( $decoded ) ) {
					$items[] = $decoded;
				}
			} else {
				$items[] = [
					'title'  => $form->title,
					'config' => $form->config,
				];
			}
		}

		self::log( 'export_forms', sprintf( '%d forms', count( $items ) ) );

		$payload = wp_json_encode( $items, JSON_PRETTY_PRINT );
		$stamp   = gmdate( 'Y-m-d' );

		nocache_headers();

		if ( class_exists( 'ZipArchive' ) ) {
			$tmp = wp_tempnam( 'phf-backup' );
			$zip = new \ZipArchive();

			if ( true === $zip->open( $tmp, \ZipArchive::OVERWRITE ) ) {
				$zip->addFromString( 'phemightforms-forms.json', $payload );
				$zip->close();

				header( 'Content-Type: application/zip' );
				header( 'Content-Disposition: attachment; filename="phemightforms-forms-' . $stamp . '.zip"' );
				header( 'Content-Length: ' . filesize( $tmp ) );
				readfile( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
				unlink( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				exit;
			}
		}

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="phemightforms-forms-' . $stamp . '.json"' );
		echo $payload; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Redirect to the shared CSV export for a form.
	 */
	public function export_entries() {
		$this->assert_capability();
		check_admin_referer( 'phemightforms_backup_export_entries' );

		$form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;

		if ( ! $form_id ) {
			wp_die( esc_html__( 'Select a form.', 'phemightforms' ) );
		}

		$form = new Form( $form_id );
		self::log( 'export_entries', $form->exists() ? $form->title : (string) $form_id );

		wp_safe_redirect( Export::export_url( $form_id ) );
		exit;
	}

	/**
	 * Import forms from uploaded JSON.
	 */
	public function import_forms() {
		$this->assert_capability();
		check_admin_referer( 'phemightforms_backup_import' );

		$redirect = add_query_arg( [ 'page' => Admin::SLUG . '-backup' ], admin_url( 'admin.php' ) );

		if ( empty( $_FILES['backup_file']['tmp_name'] ) ) {
			wp_safe_redirect( add_query_arg( 'backup_error', rawurlencode( __( 'No file uploaded.', 'phemightforms' ) ), $redirect ) );
			exit;
		}

		$raw  = file_get_contents( $_FILES['backup_file']['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$data = json_decode( $raw, true );

		if ( ! is_array( $data ) ) {
			wp_safe_redirect( add_query_arg( 'backup_error', rawurlencode( __( 'Invalid JSON file.', 'phemightforms' ) ), $redirect ) );
			exit;
		}

		// Single form object vs list.
		$forms = isset( $data['config'] ) ? [ $data ] : $data;
		$count = 0;

		foreach ( $forms as $item ) {
			if ( ! is_array( $item ) || empty( $item['config'] ) || ! is_array( $item['config'] ) ) {
				continue;
			}

			$title  = isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : __( 'Imported Form', 'phemightforms' );
			$config = $item['config'];

			if ( Form::save( $title, $config, 0 ) ) {
				++$count;
			}
		}

		self::log( 'import_forms', sprintf( '%d forms', $count ) );

		wp_safe_redirect( add_query_arg( 'imported', $count, $redirect ) );
		exit;
	}
}
