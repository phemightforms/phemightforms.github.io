<?php
/**
 * Uninstall routine. Removes plugin data when the user deletes the plugin.
 *
 * @package PhemightForms
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Remove stored forms.
$form_ids = get_posts(
	[
		'post_type'   => 'phemightforms_form',
		'post_status' => 'any',
		'numberposts' => -1,
		'fields'      => 'ids',
	]
);

foreach ( $form_ids as $form_id ) {
	wp_delete_post( $form_id, true );
}

$tables = [
	$wpdb->prefix . 'phemightforms_entries',
	$wpdb->prefix . 'phemightforms_partial',
	$wpdb->prefix . 'phemightforms_payments',
	$wpdb->prefix . 'phemightforms_invoices',
	$wpdb->prefix . 'phemightforms_transactions',
];

foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB
}

// Remove options and transients.
$options = [
	'phemightforms_settings',
	'phemightforms_db_version',
	'phemightforms_onboarding_done',
	'phemightforms_pay_rewrite',
	'phemightforms_custom_code',
];

foreach ( $options as $option ) {
	delete_option( $option );
}

$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_phf\_resume\_%' OR option_name LIKE '\_transient\_timeout\_phf\_resume\_%'" ); // phpcs:ignore WordPress.DB

// Clear scheduled events.
wp_clear_scheduled_hook( 'phemightforms_daily_cleanup' );
