<?php
/**
 * Feature availability helper.
 *
 * All features are included for free; these helpers remain for
 * backwards compatibility with earlier releases.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Every feature is available to all users.
 */
class License {

	/**
	 * Whether advanced features are available. Always true.
	 *
	 * @return bool
	 */
	public static function is_pro() {
		return true;
	}

	/**
	 * Whether a given feature is available. Always true.
	 *
	 * @param string $feature Feature slug.
	 * @return bool
	 */
	public static function allows( $feature ) {
		unset( $feature );

		return true;
	}
}
