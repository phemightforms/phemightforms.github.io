<?php
/**
 * Admin menu registration and shared admin assets.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds the admin menu tree and enqueues admin assets.
 */
class Admin {

	const CAPABILITY = 'manage_options';
	const SLUG       = 'phemightforms';
	const SLUG_FORMS = 'phemightforms-forms';

	/**
	 * Hook admin menu and assets.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'menu' ] );
		add_action( 'admin_menu', [ $this, 'menu_labels' ], 999 );
		add_action( 'admin_enqueue_scripts', [ $this, 'assets' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'menu_icon_css' ] );
		add_filter( 'admin_body_class', [ $this, 'body_class' ] );
	}

	/**
	 * Keep the sidebar menu icon crisp and correctly sized on every admin
	 * screen. The icon file is 40px (2x) so it stays sharp on retina, and
	 * full opacity preserves the gold brand color.
	 */
	public function menu_icon_css() {
		$slug = self::SLUG;
		$css  = '#adminmenu #toplevel_page_' . $slug . ' .wp-menu-image img{width:26px;height:26px;padding:5px 0 0;opacity:1;}'
			. '#adminmenu a[href*="page=' . $slug . '-addons"]{color:#E8AA3A !important;}'
			. '#adminmenu a[href*="page=' . $slug . '-addons"]:hover,'
			. '#adminmenu a[href*="page=' . $slug . '-addons"]:focus,'
			. '#adminmenu .wp-submenu li.current a[href*="page=' . $slug . '-addons"]{color:#E8AA3A !important;}';

		wp_add_inline_style( 'admin-menu', $css );
	}

	/**
	 * Add a body class on plugin admin screens.
	 *
	 * @param string $classes Existing classes.
	 * @return string
	 */
	public function body_class( $classes ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( $screen && false !== strpos( $screen->id, self::SLUG ) ) {
			$classes .= ' phemightforms-admin';
		}

		return $classes;
	}

	/**
	 * Register the top-level menu and sub-pages.
	 */
	public function menu() {
		add_menu_page(
			__( 'PhemightForms', 'phemightforms' ),
			__( 'PhemightForms', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG,
			[ Dashboard::class, 'render_page' ],
			PHEMIGHTFORMS_URL . 'assets/images/icon-menu.png',
			26
		);

		add_submenu_page(
			self::SLUG,
			__( 'Dashboard', 'phemightforms' ),
			__( 'Dashboard', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG,
			[ Dashboard::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'All Forms', 'phemightforms' ),
			__( 'All Forms', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG_FORMS,
			[ Builder::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Form Templates', 'phemightforms' ),
			__( 'Form Templates', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-templates',
			[ TemplatesPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Entries', 'phemightforms' ),
			__( 'Entries', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-entries',
			[ Entries::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Website & Form Backup', 'phemightforms' ),
			__( 'Website & Form Backup', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-backup',
			[ BackupPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Login & Registration', 'phemightforms' ),
			__( 'Login & Registration', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-auth-forms',
			[ AuthFormsPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Payments', 'phemightforms' ),
			__( 'Payments', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-payments',
			[ PaymentsPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Invoices & Payment Links', 'phemightforms' ),
			__( 'Invoices & Links', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-invoices',
			[ InvoicesPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Addons', 'phemightforms' ),
			__( 'Addons', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-addons',
			[ AddonsPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Reports', 'phemightforms' ),
			__( 'Reports', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-reports',
			[ Reports::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'SMTP', 'phemightforms' ),
			__( 'SMTP', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-smtp',
			[ SMTP::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Settings', 'phemightforms' ),
			__( 'Settings', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-settings',
			[ Settings::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'CAPTCHA', 'phemightforms' ),
			__( 'CAPTCHA', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-captcha',
			[ CaptchaPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Privacy Compliance', 'phemightforms' ),
			__( 'Privacy Compliance', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-privacy',
			[ PrivacyPage::class, 'render_page' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'About Us', 'phemightforms' ),
			__( 'About Us', 'phemightforms' ),
			self::CAPABILITY,
			self::SLUG . '-about',
			[ AboutPage::class, 'render_page' ]
		);
	}

	/**
	 * Append badges to sidebar submenu labels.
	 */
	public function menu_labels() {
		global $submenu;

		if ( empty( $submenu[ self::SLUG ] ) ) {
			return;
		}

		foreach ( $submenu[ self::SLUG ] as &$item ) {
			if ( self::SLUG . '-invoices' === $item[2] ) {
				$item[0] .= ' <span class="phf-menu-new">' . esc_html__( 'New', 'phemightforms' ) . '</span>';
			}
		}
		unset( $item );
	}

	/**
	 * Output the shared branded header with navigation.
	 *
	 * @param string $current Current nav item key.
	 */
	public static function header( $current = '' ) {
		$items = [
			'dashboard' => [
				'label' => __( 'Dashboard', 'phemightforms' ),
				'url'   => add_query_arg( [ 'page' => self::SLUG ], admin_url( 'admin.php' ) ),
			],
			'forms'     => [
				'label' => __( 'Forms', 'phemightforms' ),
				'url'   => add_query_arg( [ 'page' => self::SLUG_FORMS ], admin_url( 'admin.php' ) ),
			],
			'entries'   => [
				'label' => __( 'Entries', 'phemightforms' ),
				'url'   => add_query_arg( [ 'page' => self::SLUG . '-entries' ], admin_url( 'admin.php' ) ),
			],
			'reports'   => [
				'label' => __( 'Reports', 'phemightforms' ),
				'url'   => add_query_arg( [ 'page' => self::SLUG . '-reports' ], admin_url( 'admin.php' ) ),
			],
			'smtp'      => [
				'label' => __( 'SMTP', 'phemightforms' ),
				'url'   => add_query_arg( [ 'page' => self::SLUG . '-smtp' ], admin_url( 'admin.php' ) ),
			],
			'settings'  => [
				'label' => __( 'Settings', 'phemightforms' ),
				'url'   => add_query_arg( [ 'page' => self::SLUG . '-settings' ], admin_url( 'admin.php' ) ),
			],
		];
		?>
		<div class="phf-topbar">
			<div class="phf-topbar-brand">
				<img src="<?php echo esc_url( PHEMIGHTFORMS_URL . 'assets/images/icon-topbar.png' ); ?>" alt="">
				<span>Phemight<strong>Forms</strong></span>
			</div>
			<div class="phf-topbar-nav-wrap">
				<nav class="phf-topbar-nav">
					<?php foreach ( $items as $key => $item ) : ?>
						<a href="<?php echo esc_url( $item['url'] ); ?>" class="<?php echo $key === $current ? 'is-active' : ''; ?>"><?php echo esc_html( $item['label'] ); ?></a>
					<?php endforeach; ?>
				</nav>
				<div class="phf-nav-scroll-indicator" aria-hidden="true"><span class="phf-nav-scroll-thumb"></span></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue admin CSS/JS only on plugin screens.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function assets( $hook ) {
		if ( false === strpos( $hook, self::SLUG ) ) {
			return;
		}

		wp_enqueue_style(
			'phemightforms-admin',
			PHEMIGHTFORMS_URL . 'assets/css/admin.css',
			[],
			PHEMIGHTFORMS_VERSION
		);

		wp_enqueue_script(
			'phemightforms-admin',
			PHEMIGHTFORMS_URL . 'assets/js/admin.js',
			[ 'jquery', 'jquery-ui-sortable' ],
			PHEMIGHTFORMS_VERSION,
			true
		);

		$registry = \PhemightForms\phemightforms()->fields;
		$types    = [];

		foreach ( $registry->all() as $type => $def ) {
			$types[ $type ] = [
				'label'     => $def['label'],
				'icon'      => isset( $def['icon'] ) ? $def['icon'] : 'dashicons-plus',
				'group'     => isset( $def['group'] ) ? $def['group'] : 'standard',
				'choices'   => $registry->has_choices( $type ),
				'composite' => $registry->composite_parts( $type ),
				'display'   => $registry->is_display( $type ),
				'logic'     => $registry->supports_logic( $type ),
				'noLabel'   => ! empty( $def['no_label'] ),
			];
		}

		wp_localize_script(
			'phemightforms-admin',
			'PhemightFormsAdmin',
			[
				'fieldTypes' => $types,
				'currency'   => \PhemightForms\Payments::symbol(),
				'i18n'       => [
					'price'         => __( 'Price', 'phemightforms' ),
					'userPrice'     => __( 'Let the visitor enter the amount (donations)', 'phemightforms' ),
					'items'         => __( 'Items', 'phemightforms' ),
					'itemsHint'     => __( 'Format each item as: Item name|Price. Example: Large|20', 'phemightforms' ),
					'addItem'       => __( 'Add item', 'phemightforms' ),
					'totalNote'     => __( 'Shows the live order total, calculated from the payment fields on this form.', 'phemightforms' ),
					'confirmDelete' => __( 'Delete this field?', 'phemightforms' ),
					'newChoice'     => __( 'New choice', 'phemightforms' ),
					'untitled'      => __( 'Untitled field', 'phemightforms' ),
					'dropHere'      => __( 'Drop fields here to build your form', 'phemightforms' ),
					'label'         => __( 'Label', 'phemightforms' ),
					'placeholder'   => __( 'Placeholder', 'phemightforms' ),
					'description'   => __( 'Description', 'phemightforms' ),
					'required'      => __( 'Required', 'phemightforms' ),
					'choices'       => __( 'Choices', 'phemightforms' ),
					'defaultValue'  => __( 'Default value', 'phemightforms' ),
					'addChoice'     => __( 'Add choice', 'phemightforms' ),
					'duplicate'     => __( 'Duplicate', 'phemightforms' ),
					'delete'        => __( 'Delete', 'phemightforms' ),
					'general'       => __( 'General', 'phemightforms' ),
					'logic'         => __( 'Conditional Logic', 'phemightforms' ),
					'enableLogic'   => __( 'Enable conditional logic', 'phemightforms' ),
					'thisField'     => __( 'this field if', 'phemightforms' ),
					'allRules'      => __( 'all', 'phemightforms' ),
					'anyRules'      => __( 'any', 'phemightforms' ),
					'ofFollowing'   => __( 'of the following match:', 'phemightforms' ),
					'addRule'       => __( 'Add rule', 'phemightforms' ),
					'show'          => __( 'Show', 'phemightforms' ),
					'hide'          => __( 'Hide', 'phemightforms' ),
					'selectField'   => __( 'Select a field', 'phemightforms' ),
					'is'            => __( 'is', 'phemightforms' ),
					'isNot'         => __( 'is not', 'phemightforms' ),
					'empty'         => __( 'is empty', 'phemightforms' ),
					'notEmpty'      => __( 'is not empty', 'phemightforms' ),
					'contains'      => __( 'contains', 'phemightforms' ),
					'pageBreakNote' => __( 'Page Break: fields after this appear on a new page', 'phemightforms' ),
				],
			]
		);
	}
}
