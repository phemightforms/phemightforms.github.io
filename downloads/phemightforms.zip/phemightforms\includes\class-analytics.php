<?php
/**
 * Form view and conversion analytics.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tracks form impressions and submission counts.
 */
class Analytics {

	const VIEWS_META    = '_phf_views';
	const SUBMITS_META  = '_phf_submissions';

	/**
	 * Record a form impression when rendered on the front end.
	 *
	 * @param int $form_id Form ID.
	 */
	public static function track_view( $form_id ) {
		$form_id = (int) $form_id;
		if ( $form_id <= 0 ) {
			return;
		}

		$views = (int) get_post_meta( $form_id, self::VIEWS_META, true );
		update_post_meta( $form_id, self::VIEWS_META, $views + 1 );
	}

	/**
	 * Record a successful submission.
	 *
	 * @param int $form_id Form ID.
	 */
	public static function track_submission( $form_id ) {
		$form_id = (int) $form_id;
		if ( $form_id <= 0 ) {
			return;
		}

		$count = (int) get_post_meta( $form_id, self::SUBMITS_META, true );
		update_post_meta( $form_id, self::SUBMITS_META, $count + 1 );
	}

	/**
	 * Return view count for a form.
	 *
	 * @param int $form_id Form ID.
	 * @return int
	 */
	public static function views( $form_id ) {
		return (int) get_post_meta( (int) $form_id, self::VIEWS_META, true );
	}

	/**
	 * Return submission count for a form.
	 *
	 * @param int $form_id Form ID.
	 * @return int
	 */
	public static function submissions( $form_id ) {
		return (int) get_post_meta( (int) $form_id, self::SUBMITS_META, true );
	}

	/**
	 * Calculate conversion rate percentage.
	 *
	 * @param int $form_id Form ID.
	 * @return float
	 */
	public static function conversion_rate( $form_id ) {
		$views = self::views( $form_id );
		if ( $views <= 0 ) {
			return 0.0;
		}

		return round( ( self::submissions( $form_id ) / $views ) * 100, 1 );
	}

	/**
	 * Site-wide totals for the dashboard.
	 *
	 * @return array{views:int,submissions:int,rate:float}
	 */
	public static function site_totals() {
		$views = 0;
		$subs  = 0;

		foreach ( Form::all() as $post ) {
			$views += self::views( $post->ID );
			$subs  += self::submissions( $post->ID );
		}

		$rate = $views > 0 ? round( ( $subs / $views ) * 100, 1 ) : 0.0;

		return [
			'views'       => $views,
			'submissions' => $subs,
			'rate'        => $rate,
		];
	}
}
