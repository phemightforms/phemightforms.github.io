<?php
/**
 * Field type registry.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Defines the available field types, their grouping, and their capabilities.
 */
class Fields {

	/**
	 * Registered field definitions keyed by type.
	 *
	 * @var array<string,array>
	 */
	private $types = [];

	/**
	 * Field groups shown as tabs/sections in the builder sidebar.
	 *
	 * @var array<string,string>
	 */
	private $groups = [];

	/**
	 * Register the built-in field types.
	 */
	public function __construct() {
		$this->groups = [
			'standard' => __( 'Standard Fields', 'phemightforms' ),
			'fancy'    => __( 'Fancy Fields', 'phemightforms' ),
			'payment'  => __( 'Payment Fields', 'phemightforms' ),
			'layout'   => __( 'Layout', 'phemightforms' ),
		];

		$this->types = [
			'text'      => [
				'label' => __( 'Single Line Text', 'phemightforms' ),
				'icon'  => 'dashicons-editor-textcolor',
				'group' => 'standard',
			],
			'textarea'  => [
				'label' => __( 'Paragraph Text', 'phemightforms' ),
				'icon'  => 'dashicons-text',
				'group' => 'standard',
			],
			'email'     => [
				'label' => __( 'Email', 'phemightforms' ),
				'icon'  => 'dashicons-email',
				'group' => 'standard',
			],
			'phone'     => [
				'label' => __( 'Phone', 'phemightforms' ),
				'icon'  => 'dashicons-phone',
				'group' => 'standard',
			],
			'number'    => [
				'label' => __( 'Number', 'phemightforms' ),
				'icon'  => 'dashicons-calculator',
				'group' => 'standard',
			],
			'url'       => [
				'label' => __( 'Website / URL', 'phemightforms' ),
				'icon'  => 'dashicons-admin-links',
				'group' => 'standard',
			],
			'select'    => [
				'label'   => __( 'Dropdown', 'phemightforms' ),
				'icon'    => 'dashicons-menu',
				'group'   => 'standard',
				'choices' => true,
			],
			'radio'     => [
				'label'   => __( 'Multiple Choice', 'phemightforms' ),
				'icon'    => 'dashicons-marker',
				'group'   => 'standard',
				'choices' => true,
			],
			'checkbox'  => [
				'label'   => __( 'Checkboxes', 'phemightforms' ),
				'icon'    => 'dashicons-yes',
				'group'   => 'standard',
				'choices' => true,
			],
			'date'      => [
				'label' => __( 'Date', 'phemightforms' ),
				'icon'  => 'dashicons-calendar-alt',
				'group' => 'standard',
			],
			'name'      => [
				'label'     => __( 'Name', 'phemightforms' ),
				'icon'      => 'dashicons-admin-users',
				'group'     => 'fancy',
				'composite' => [ 'first', 'last' ],
			],
			'address'   => [
				'label'     => __( 'Address', 'phemightforms' ),
				'icon'      => 'dashicons-location',
				'group'     => 'fancy',
				'composite' => [ 'line1', 'line2', 'city', 'state', 'zip', 'country' ],
			],
			'file'      => [
				'label' => __( 'File Upload', 'phemightforms' ),
				'icon'  => 'dashicons-upload',
				'group' => 'fancy',
			],
			'consent'   => [
				'label' => __( 'GDPR / Consent', 'phemightforms' ),
				'icon'  => 'dashicons-privacy',
				'group' => 'fancy',
			],
			'signature' => [
				'label'    => __( 'Signature', 'phemightforms' ),
				'icon'     => 'dashicons-edit',
				'group'    => 'fancy',
				'no_logic' => true,
			],
			'repeater'  => [
				'label'    => __( 'Repeater', 'phemightforms' ),
				'icon'     => 'dashicons-plus-alt2',
				'group'    => 'fancy',
				'no_logic' => true,
			],
			'hidden'    => [
				'label'      => __( 'Hidden Field', 'phemightforms' ),
				'icon'       => 'dashicons-hidden',
				'group'      => 'fancy',
				'no_label'   => true,
				'no_logic'   => true,
			],
			'section'   => [
				'label'    => __( 'Section Divider', 'phemightforms' ),
				'icon'     => 'dashicons-minus',
				'group'    => 'layout',
				'display'  => true,
				'no_logic' => true,
			],
			'pagebreak' => [
				'label'    => __( 'Page Break', 'phemightforms' ),
				'icon'     => 'dashicons-flag',
				'group'    => 'layout',
				'display'  => true,
				'no_logic' => true,
			],
			'time'      => [
				'label' => __( 'Time', 'phemightforms' ),
				'icon'  => 'dashicons-clock',
				'group' => 'standard',
			],
			'rating'    => [
				'label' => __( 'Rating', 'phemightforms' ),
				'icon'  => 'dashicons-star-filled',
				'group' => 'fancy',
			],
			'html'      => [
				'label'    => __( 'HTML / Content', 'phemightforms' ),
				'icon'     => 'dashicons-editor-code',
				'group'    => 'layout',
				'display'  => true,
				'no_logic' => true,
			],
			'country'   => [
				'label' => __( 'Country', 'phemightforms' ),
				'icon'  => 'dashicons-admin-site-alt3',
				'group' => 'fancy',
			],
			'image_choice' => [
				'label'   => __( 'Image Choices', 'phemightforms' ),
				'icon'    => 'dashicons-format-image',
				'group'   => 'fancy',
				'choices' => true,
			],
			'payment_single' => [
				'label' => __( 'Single Item', 'phemightforms' ),
				'icon'  => 'dashicons-products',
				'group' => 'payment',
			],
			'payment_multiple' => [
				'label'   => __( 'Multiple Items', 'phemightforms' ),
				'icon'    => 'dashicons-cart',
				'group'   => 'payment',
				'choices' => true,
			],
			'payment_select' => [
				'label'   => __( 'Dropdown Items', 'phemightforms' ),
				'icon'    => 'dashicons-list-view',
				'group'   => 'payment',
				'choices' => true,
			],
			'payment_quantity' => [
				'label' => __( 'Quantity', 'phemightforms' ),
				'icon'  => 'dashicons-plus-alt2',
				'group' => 'payment',
			],
			'payment_coupon' => [
				'label'    => __( 'Coupon Code', 'phemightforms' ),
				'icon'     => 'dashicons-tickets-alt',
				'group'    => 'payment',
				'no_logic' => true,
			],
			'payment_total' => [
				'label'    => __( 'Total', 'phemightforms' ),
				'icon'     => 'dashicons-money-alt',
				'group'    => 'payment',
				'no_logic' => true,
			],
		];

		/**
		 * Allow other code to register additional field types.
		 *
		 * @param array $types Field definitions keyed by type slug.
		 */
		$this->types = apply_filters( 'phemightforms_field_types', $this->types );
	}

	/**
	 * Return all registered field definitions.
	 *
	 * @return array<string,array>
	 */
	public function all() {
		return $this->types;
	}

	/**
	 * Return the field group labels.
	 *
	 * @return array<string,string>
	 */
	public function groups() {
		return $this->groups;
	}

	/**
	 * Check whether a field type exists.
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public function exists( $type ) {
		return isset( $this->types[ $type ] );
	}

	/**
	 * Whether the given type supports a list of choices.
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public function has_choices( $type ) {
		return ! empty( $this->types[ $type ]['choices'] );
	}

	/**
	 * Return the sub-keys for a composite field (e.g. name -> first,last),
	 * or an empty array for simple fields.
	 *
	 * @param string $type Field type slug.
	 * @return array
	 */
	public function composite_parts( $type ) {
		return isset( $this->types[ $type ]['composite'] ) ? $this->types[ $type ]['composite'] : [];
	}

	/**
	 * Whether the type is composite (multiple sub-inputs).
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public function is_composite( $type ) {
		return ! empty( $this->types[ $type ]['composite'] );
	}

	/**
	 * Whether the type is display-only (no value collected), e.g. section, pagebreak.
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public function is_display( $type ) {
		return ! empty( $this->types[ $type ]['display'] );
	}

	/**
	 * Whether the type can participate in conditional logic as a trigger.
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public function supports_logic( $type ) {
		return $this->exists( $type ) && empty( $this->types[ $type ]['no_logic'] );
	}
}
