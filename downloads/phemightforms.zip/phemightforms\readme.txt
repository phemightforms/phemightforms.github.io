=== PhemightForms ===
Contributors: asaajupeter
Tags: forms, contact form, form builder, payment forms, surveys
Requires at least: 5.8
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 2.10.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Drag and drop WordPress form builder with payments, invoices, SMTP, CAPTCHA, GDPR tools, and addon integrations.

== Description ==

PhemightForms is a full-featured WordPress form builder by Phemight Website Developer. Build contact forms, payment forms, surveys, quizzes, and lead capture forms without writing code.

**Core features**

* Drag and drop form builder with live preview
* 50+ pre-built form templates
* 30+ field types including file upload, signature, and payment fields
* Conditional logic and multi-page forms
* Entry management with search, export, and notes
* Email notifications with custom SMTP support
* CAPTCHA: reCAPTCHA v2, hCaptcha, and Cloudflare Turnstile
* Gutenberg block and `[phemightform]` shortcode
* Popup and slide-in embed modes
* Save & Resume partial submissions
* Webhooks and CSV export
* GDPR privacy compliance tools

**Payments**

* Stripe, PayPal, Square, Razorpay, Mollie, Paystack, Flutterwave, Coinbase Commerce, and NOWPayments
* Coupons, donations, and user-defined amounts
* Invoices and payment links with PDF download

**Integrations**

* Mailchimp, Google Sheets, webhooks, and Akismet
* Addons catalog for marketing and CRM tools

== External services ==

PhemightForms only contacts an external service when you enable and configure that specific feature. Nothing is sent to any external service by default. The services below are optional and each one is used only after you enter your own API keys or enable the option in the plugin settings.

= Payment gateways =

When you enable a payment gateway and a visitor pays through a form, invoice, or payment link, the plugin sends the payment amount, currency, a description of the purchase, and the customer's name and email address to the gateway you selected, at the moment the payment is initiated. This is required to create the checkout session or payment request.

* **Stripe** (api.stripe.com): [Terms of Service](https://stripe.com/legal/consumer), [Privacy Policy](https://stripe.com/privacy)
* **PayPal** (paypal.com): [Terms of Service](https://www.paypal.com/us/legalhub/useragreement-full), [Privacy Policy](https://www.paypal.com/us/legalhub/privacy-full)
* **Paystack** (api.paystack.co): [Terms of Service](https://paystack.com/terms), [Privacy Policy](https://paystack.com/privacy/merchant)
* **Flutterwave** (api.flutterwave.com): [Terms of Service](https://flutterwave.com/us/terms), [Privacy Policy](https://flutterwave.com/us/privacy-policy)
* **Razorpay** (api.razorpay.com): [Terms of Service](https://razorpay.com/terms/), [Privacy Policy](https://razorpay.com/privacy/)
* **Mollie** (api.mollie.com): [Terms of Service](https://www.mollie.com/user-agreement), [Privacy Policy](https://www.mollie.com/privacy)
* **Square** (connect.squareup.com): [Terms of Service](https://squareup.com/legal/general/ua), [Privacy Policy](https://squareup.com/legal/general/privacy)
* **Coinbase Commerce** (api.commerce.coinbase.com): [Terms of Service](https://www.coinbase.com/legal/user_agreement/united_states), [Privacy Policy](https://www.coinbase.com/legal/privacy)
* **NOWPayments** (api.nowpayments.io): [Terms of Service](https://nowpayments.io/terms-of-use), [Privacy Policy](https://nowpayments.io/privacy-policy)

= CAPTCHA providers =

When you enable a CAPTCHA provider under PhemightForms > CAPTCHA, the provider's challenge script is loaded on pages that contain a form, and the visitor's CAPTCHA response token (together with the visitor's IP address, as required by the verification API) is sent to the provider when the form is submitted, to verify the visitor is human.

* **Google reCAPTCHA** (google.com/recaptcha): [Terms of Service](https://policies.google.com/terms), [Privacy Policy](https://policies.google.com/privacy)
* **hCaptcha** (hcaptcha.com): [Terms of Service](https://www.hcaptcha.com/terms), [Privacy Policy](https://www.hcaptcha.com/privacy)
* **Cloudflare Turnstile** (challenges.cloudflare.com): [Terms of Service](https://www.cloudflare.com/website-terms/), [Privacy Policy](https://www.cloudflare.com/privacypolicy/)

= Spam filtering =

* **Akismet** (rest.akismet.com): When you enter an Akismet API key and enable spam checking, submitted form field values, the submitter's IP address, and user agent are sent to Akismet on each form submission to check for spam. [Terms of Service](https://akismet.com/tos/), [Privacy Policy](https://automattic.com/privacy/)

= Marketing and data integrations =

* **Mailchimp** (api.mailchimp.com): When you enter a Mailchimp API key and enable the integration on a form, the submitter's email address is sent to Mailchimp on submission to subscribe them to your selected audience list. [Terms of Service](https://mailchimp.com/legal/terms/), [Privacy Policy](https://www.intuit.com/privacy/statement/)
* **Google Sheets** (your own Apps Script URL): When you configure a Google Apps Script webhook URL, submitted form field values are sent to that URL on each submission. [Terms of Service](https://policies.google.com/terms), [Privacy Policy](https://policies.google.com/privacy)
* **Custom webhooks** (Slack, Discord, Telegram, or any URL you provide): When you configure a webhook URL on a form, submitted form field values are sent to that URL on each submission. The receiving service is chosen and controlled by you; please review the terms and privacy policy of the endpoint you configure.

== Installation ==

1. Upload the `phemightforms` folder to `/wp-content/plugins/`, or install via Plugins > Add New > Upload.
2. Activate the plugin through the Plugins screen.
3. Open **PhemightForms** in the WordPress admin sidebar.
4. Create a form, then embed it with the shortcode or Gutenberg block.

== Frequently Asked Questions ==

= Is PhemightForms free? =

Yes. All features are included at no cost.

= Does it support payments? =

Yes. Enable gateways under PhemightForms > Payments and add payment fields in the builder.

= Where are submissions stored? =

In a dedicated database table, viewable under PhemightForms > Entries.

== Changelog ==

= 2.10.0 =
* Removed the custom code (arbitrary CSS/JS) feature
* Removed attribution text from public pages
* Documented all external services in the readme
* Improved input sanitization and settings registration

= 2.9.0 =
* Brand icons, mobile header scroll indicator, SMTP mailer pills
* Addons page with real brand logos
* Invoices & payment links, multi-gateway checkout
* Privacy compliance and About page alignment

= 2.0.0 =
* Payments, invoices, PDF exports, and payment gateways
* Full admin redesign with gold brand theme

= 1.0.0 =
* Initial release: builder, entries, notifications, shortcode, and block
