<?php
/**
 * Country list helper for country and phone fields.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Static ISO country names for dropdown fields.
 */
class Countries {

	/**
	 * Return an associative list of country code => label.
	 *
	 * @return array<string,string>
	 */
	public static function list() {
		return [
			'US' => __( 'United States', 'phemightforms' ),
			'GB' => __( 'United Kingdom', 'phemightforms' ),
			'CA' => __( 'Canada', 'phemightforms' ),
			'AU' => __( 'Australia', 'phemightforms' ),
			'DE' => __( 'Germany', 'phemightforms' ),
			'FR' => __( 'France', 'phemightforms' ),
			'NG' => __( 'Nigeria', 'phemightforms' ),
			'IN' => __( 'India', 'phemightforms' ),
			'BR' => __( 'Brazil', 'phemightforms' ),
			'MX' => __( 'Mexico', 'phemightforms' ),
			'ES' => __( 'Spain', 'phemightforms' ),
			'IT' => __( 'Italy', 'phemightforms' ),
			'NL' => __( 'Netherlands', 'phemightforms' ),
			'SE' => __( 'Sweden', 'phemightforms' ),
			'ZA' => __( 'South Africa', 'phemightforms' ),
			'JP' => __( 'Japan', 'phemightforms' ),
			'CN' => __( 'China', 'phemightforms' ),
			'AE' => __( 'United Arab Emirates', 'phemightforms' ),
			'SA' => __( 'Saudi Arabia', 'phemightforms' ),
			'KE' => __( 'Kenya', 'phemightforms' ),
			'GH' => __( 'Ghana', 'phemightforms' ),
			'PH' => __( 'Philippines', 'phemightforms' ),
			'PK' => __( 'Pakistan', 'phemightforms' ),
			'BD' => __( 'Bangladesh', 'phemightforms' ),
			'OTHER' => __( 'Other', 'phemightforms' ),
		];
	}
}
