<?php
/**
 * CAPTCHA settings screen: choose and configure an anti-spam provider.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Captcha;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and saves the CAPTCHA page.
 */
class CaptchaPage {

	/**
	 * Hook the save handler.
	 */
	public function __construct() {
		add_action( 'admin_post_phemightforms_save_captcha', [ $this, 'handle_save' ] );
	}

	/**
	 * Provider cards shown on the page.
	 *
	 * @return array
	 */
	private static function providers() {
		return [
			'hcaptcha'     => [
				'name' => 'hCaptcha',
				'desc' => __( 'Privacy focused CAPTCHA that pays website owners. A drop in replacement for reCAPTCHA.', 'phemightforms' ),
				'link' => 'https://dashboard.hcaptcha.com/sites',
				'logo' => 'hcaptcha',
			],
			'recaptcha_v2' => [
				'name' => 'reCAPTCHA',
				'desc' => __( 'Google reCAPTCHA v2 checkbox: the classic "I\'m not a robot" box trusted across the web.', 'phemightforms' ),
				'link' => 'https://www.google.com/recaptcha/admin',
				'logo' => 'recaptcha',
			],
			'turnstile'    => [
				'name' => 'Turnstile',
				'desc' => __( 'Cloudflare\'s invisible, user friendly CAPTCHA alternative. No puzzles for most visitors.', 'phemightforms' ),
				'link' => 'https://dash.cloudflare.com/?to=/:account/turnstile',
				'logo' => 'turnstile',
			],
			''             => [
				'name' => __( 'None', 'phemightforms' ),
				'desc' => __( 'No CAPTCHA on your forms. The built in honeypot still quietly blocks most bots.', 'phemightforms' ),
				'link' => '',
				'logo' => 'none',
			],
		];
	}

	/**
	 * Persist the CAPTCHA settings.
	 */
	public function handle_save() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_captcha' );

		$settings = get_option( 'phemightforms_settings', [] );

		$provider = isset( $_POST['captcha_provider'] ) ? sanitize_key( wp_unslash( $_POST['captcha_provider'] ) ) : '';
		if ( ! in_array( $provider, [ '', 'recaptcha_v2', 'hcaptcha', 'turnstile' ], true ) ) {
			$provider = '';
		}

		$settings['captcha_provider'] = $provider;
		$settings['captcha_site_key'] = isset( $_POST['captcha_site_key'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_site_key'] ) ) : '';

		$secret = isset( $_POST['captcha_secret_key'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_secret_key'] ) ) : '';
		if ( '' !== $secret ) {
			$settings['captcha_secret_key'] = $secret;
		}

		update_option( 'phemightforms_settings', $settings );

		wp_safe_redirect(
			add_query_arg(
				[
					'page'  => Admin::SLUG . '-captcha',
					'saved' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render the CAPTCHA settings page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$settings = get_option( 'phemightforms_settings', [] );
		$current  = isset( $settings['captcha_provider'] ) ? $settings['captcha_provider'] : '';
		$site_key = isset( $settings['captcha_site_key'] ) ? $settings['captcha_site_key'] : '';
		$secret   = isset( $settings['captcha_secret_key'] ) ? $settings['captcha_secret_key'] : '';
		$active   = Captcha::is_active();
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'captcha' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'CAPTCHA', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'A CAPTCHA is an anti spam technique that protects your forms from bots and abuse while letting real people pass through with ease. Pick a provider, paste your keys, and every form is protected automatically.', 'phemightforms' ); ?></p>
					</div>
					<?php if ( $active ) : ?>
						<span class="phf-badge phf-badge-success phf-captcha-status"><span class="dashicons dashicons-shield"></span> <?php esc_html_e( 'Protection Active', 'phemightforms' ); ?></span>
					<?php endif; ?>
				</div>

				<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'CAPTCHA settings saved.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'phemightforms_captcha' ); ?>
					<input type="hidden" name="action" value="phemightforms_save_captcha">

					<div class="phf-captcha-grid">
						<?php foreach ( self::providers() as $slug => $provider ) : ?>
							<label class="phf-captcha-card<?php echo $slug === $current ? ' is-selected' : ''; ?>">
								<input type="radio" name="captcha_provider" value="<?php echo esc_attr( $slug ); ?>" <?php checked( $current, $slug ); ?>>
								<span class="phf-captcha-check"><span class="dashicons dashicons-yes"></span></span>
								<span class="phf-captcha-logo phf-captcha-logo-<?php echo esc_attr( $provider['logo'] ); ?>">
									<?php if ( 'hcaptcha' === $provider['logo'] ) : ?>
										<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M9 2h6v3.2c1.1-.7 2.5-.6 3.5.4s1.1 2.4.4 3.5H22v6h-3.1c.7 1.1.6 2.5-.4 3.5s-2.4 1.1-3.5.4V22H9v-3.1c-1.1.7-2.5.6-3.5-.4s-1.1-2.4-.4-3.5H2V9h3.2c-.7-1.1-.6-2.5.4-3.5S8 4.4 9 5.1V2z"/></svg>
									<?php elseif ( 'recaptcha' === $provider['logo'] ) : ?>
										<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 1 9.6 7.2h-3.2A7 7 0 0 0 12 5c-1.9 0-3.6.8-4.9 2L10 10H2V2l2.9 2.9A10 10 0 0 1 12 2zm-9.6 12.8h3.2A7 7 0 0 0 12 19c1.9 0 3.6-.8 4.9-2L14 14h8v8l-2.9-2.9A10 10 0 0 1 12 22a10 10 0 0 1-9.6-7.2z"/></svg>
									<?php elseif ( 'turnstile' === $provider['logo'] ) : ?>
										<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M16.6 8.5a6.6 6.6 0 0 0-12.4 1.4A5 5 0 0 0 5 19.8h11.5a4.6 4.6 0 0 0 .1-9.2 6.6 6.6 0 0 0 0-2.1z"/></svg>
									<?php else : ?>
										<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 2a8 8 0 0 1 6.3 12.9L7.1 5.7A8 8 0 0 1 12 4zm-6.3 3.1 11.2 11.2A8 8 0 0 1 5.7 7.1z"/></svg>
									<?php endif; ?>
								</span>
								<span class="phf-captcha-name"><?php echo esc_html( $provider['name'] ); ?></span>
								<span class="phf-captcha-desc"><?php echo esc_html( $provider['desc'] ); ?></span>
								<?php if ( $slug === $current && $slug && $active ) : ?>
									<span class="phf-badge phf-badge-success"><?php esc_html_e( 'Active', 'phemightforms' ); ?></span>
								<?php endif; ?>
							</label>
						<?php endforeach; ?>
					</div>

					<div class="phf-card-panel phf-settings-card phf-captcha-keys" <?php echo '' === $current ? 'style="display:none"' : ''; ?>>
						<div class="phf-panel-head">
							<h3><span class="dashicons dashicons-admin-network"></span> <?php esc_html_e( 'API Keys', 'phemightforms' ); ?></h3>
							<span class="phf-muted phf-captcha-keys-hint" data-links='<?php echo esc_attr( wp_json_encode( wp_list_pluck( self::providers(), 'link' ) ) ); ?>'>
								<?php esc_html_e( 'Create free keys in your provider dashboard, then paste them here.', 'phemightforms' ); ?>
								<a href="#" target="_blank" rel="noopener" class="phf-captcha-keys-link" style="<?php echo $current ? '' : 'display:none'; ?>"><?php esc_html_e( 'Get your keys', 'phemightforms' ); ?> &rarr;</a>
							</span>
						</div>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-captcha-site-key"><?php esc_html_e( 'Site Key', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Public key rendered with the widget on your forms.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control">
								<input type="text" id="phf-captcha-site-key" name="captcha_site_key" value="<?php echo esc_attr( $site_key ); ?>" placeholder="0x0000...">
							</div>
						</div>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-captcha-secret-key"><?php esc_html_e( 'Secret Key', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Used server side to verify responses. Stored securely; leave blank to keep the current key.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control">
								<input type="password" id="phf-captcha-secret-key" name="captcha_secret_key" value="" placeholder="<?php echo esc_attr( $secret ? '••••••••' : '' ); ?>" autocomplete="new-password">
							</div>
						</div>
					</div>

					<div class="phf-settings-actions">
						<button type="submit" class="phf-btn phf-btn-primary phf-btn-lg"><?php esc_html_e( 'Save Settings', 'phemightforms' ); ?></button>
					</div>
				</form>

				<?php ob_start(); ?>
					( function () {
						var cards = document.querySelectorAll( '.phf-captcha-card' );
						var keys = document.querySelector( '.phf-captcha-keys' );
						var hint = document.querySelector( '.phf-captcha-keys-hint' );
						var link = document.querySelector( '.phf-captcha-keys-link' );
						var links = hint ? JSON.parse( hint.getAttribute( 'data-links' ) || '{}' ) : {};

						function update() {
							var value = '';
							cards.forEach( function ( card ) {
								var input = card.querySelector( 'input' );
								card.classList.toggle( 'is-selected', input.checked );
								if ( input.checked ) { value = input.value; }
							} );
							if ( keys ) { keys.style.display = value ? '' : 'none'; }
							if ( link ) {
								if ( value && links[ value ] ) {
									link.href = links[ value ];
									link.style.display = '';
								} else {
									link.style.display = 'none';
								}
							}
						}

						cards.forEach( function ( card ) {
							card.querySelector( 'input' ).addEventListener( 'change', update );
						} );
						update();
					} )();
				<?php wp_add_inline_script( 'phemightforms-admin', ob_get_clean() ); ?>
			</div>
		</div>
		<?php
	}
}
