<?php
/**
 * Addons gallery: every PhemightForms extension in one searchable library.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Addons page.
 */
class AddonsPage {

	/**
	 * Full addon catalog.
	 *
	 * @return array<string,array>
	 */
	public static function catalog() {
		$items = [
			'paypal-commerce'   => [ 'name' => 'PayPal Commerce Pro', 'cat' => 'payment', 'color' => '#003087', 'abbr' => 'PP', 'desc' => __( 'Accept PayPal and credit card payments on your WordPress site. Set it up in a few clicks from the Payments screen.', 'phemightforms' ) ],
			'stripe-pro'        => [ 'name' => 'Stripe Pro', 'cat' => 'payment', 'color' => '#635bff', 'abbr' => 'S', 'desc' => __( 'Conditional logic for payments and lower transaction fees. Works alongside the core Stripe integration for donations and orders.', 'phemightforms' ) ],
			'airtable'          => [ 'name' => 'Airtable', 'cat' => 'productivity', 'color' => '#18bfff', 'abbr' => 'AT', 'desc' => __( 'Turn each form submission into a neatly organized record. Send data straight to your bases automatically.', 'phemightforms' ) ],
			'dropbox'           => [ 'name' => 'Dropbox', 'cat' => 'productivity', 'color' => '#0061ff', 'abbr' => 'Db', 'desc' => __( 'Receive user submitted files directly in your Dropbox account to streamline file management.', 'phemightforms' ) ],
			'entry-automation'  => [ 'name' => 'Entry Automation', 'cat' => 'productivity', 'color' => '#d89a2d', 'abbr' => 'EA', 'desc' => __( 'Automatically export or delete form entries on a daily, weekly, or monthly schedule you choose.', 'phemightforms' ) ],
			'google-calendar'   => [ 'name' => 'Google Calendar', 'cat' => 'productivity', 'color' => '#4285f4', 'abbr' => 'GC', 'desc' => __( 'Send form submissions to your linked Google calendars at intervals you select.', 'phemightforms' ) ],
			'google-drive'      => [ 'name' => 'Google Drive', 'cat' => 'productivity', 'color' => '#0f9d58', 'abbr' => 'GD', 'desc' => __( 'Filter and export form entries and file uploads to your Google Drive automatically.', 'phemightforms' ) ],
			'make'              => [ 'name' => 'Make', 'cat' => 'automation', 'color' => '#6d00cc', 'abbr' => 'Mk', 'desc' => __( 'Connect your forms to multiple apps and services for powerful automations that save time.', 'phemightforms' ) ],
			'n8n'               => [ 'name' => 'n8n', 'cat' => 'automation', 'color' => '#ea4b71', 'abbr' => 'n8', 'desc' => __( 'Turn each form submission into an automated workflow. Send data to n8n and let your forms handle the busywork.', 'phemightforms' ) ],
			'notion'            => [ 'name' => 'Notion', 'cat' => 'productivity', 'color' => '#000000', 'abbr' => 'N', 'desc' => __( 'Transform each submission into a new Notion page. Map your fields once and keep your workspace up to date.', 'phemightforms' ) ],
			'pdf'               => [ 'name' => 'PDF', 'cat' => 'productivity', 'color' => '#e5252a', 'abbr' => 'PDF', 'desc' => __( 'Save email notification entries to a PDF file with your logo and advanced customization options.', 'phemightforms' ) ],
			'quiz'              => [ 'name' => 'Quiz', 'cat' => 'forms', 'color' => '#8a4c0d', 'abbr' => 'Qz', 'desc' => __( 'Build graded, personality, or weighted quizzes that capture leads and assess knowledge with AI powered generation.', 'phemightforms' ) ],
			'sendgrid'          => [ 'name' => 'SendGrid', 'cat' => 'marketing', 'color' => '#1a82e2', 'abbr' => 'SG', 'desc' => __( 'Grow your email marketing by adding every submission as a contact to the lists you choose.', 'phemightforms' ) ],
			'zoho-crm'          => [ 'name' => 'Zoho CRM', 'cat' => 'crm', 'color' => '#e42527', 'abbr' => 'Z', 'desc' => __( 'Create and update Zoho CRM contacts, leads, and more automatically from form submissions.', 'phemightforms' ) ],
			'calculations'      => [ 'name' => 'Calculations', 'cat' => 'forms', 'color' => '#f2b541', 'abbr' => 'Ca', 'desc' => __( 'Create custom calculations for shipping, quotes, lead magnets, and more to get more sales and leads.', 'phemightforms' ) ],
			'geolocation'       => [ 'name' => 'Geolocation', 'cat' => 'forms', 'color' => '#34a853', 'abbr' => 'Geo', 'desc' => __( 'Store visitor geolocation data with submissions and enable address autocomplete for easier forms.', 'phemightforms' ) ],
			'google-sheets'     => [ 'name' => 'Google Sheets', 'cat' => 'productivity', 'color' => '#0f9d58', 'abbr' => 'GS', 'desc' => __( 'Send form entries and leads to a Google Sheet automatically on every submission.', 'phemightforms' ) ],
			'surveys-polls'     => [ 'name' => 'Surveys and Polls', 'cat' => 'forms', 'color' => '#4285f4', 'abbr' => 'SP', 'desc' => __( 'Add interactive polls and survey forms with best in class reporting for data driven decisions.', 'phemightforms' ) ],
			'user-journey'      => [ 'name' => 'User Journey', 'cat' => 'analytics', 'color' => '#b56d18', 'abbr' => 'UJ', 'desc' => __( 'See the steps visitors take before submitting your forms and which content drives conversions.', 'phemightforms' ) ],
			'activecampaign'    => [ 'name' => 'ActiveCampaign', 'cat' => 'marketing', 'color' => '#356ae6', 'abbr' => 'AC', 'desc' => __( 'Add contacts to your account, record events, add notes to contacts, and more from every submission.', 'phemightforms' ) ],
			'authorize-net'     => [ 'name' => 'Authorize.Net', 'cat' => 'payment', 'color' => '#003087', 'abbr' => 'AN', 'desc' => __( 'Connect your WordPress site with Authorize.Net to collect payments, donations, and online orders.', 'phemightforms' ) ],
			'aweber'            => [ 'name' => 'AWeber', 'cat' => 'marketing', 'color' => '#0b7c3e', 'abbr' => 'AW', 'desc' => __( 'Create AWeber newsletter signup forms in WordPress so you can grow your email list.', 'phemightforms' ) ],
			'brevo'             => [ 'name' => 'Brevo', 'cat' => 'marketing', 'color' => '#0b996e', 'abbr' => 'Br', 'desc' => __( 'Organize your leads, automate your marketing, and engage your subscribers from form data.', 'phemightforms' ) ],
			'campaign-monitor'  => [ 'name' => 'Campaign Monitor', 'cat' => 'marketing', 'color' => '#7856ff', 'abbr' => 'CM', 'desc' => __( 'Create Campaign Monitor newsletter signup forms in WordPress to grow your email list.', 'phemightforms' ) ],
			'conversational'    => [ 'name' => 'Conversational Forms', 'cat' => 'forms', 'color' => '#d89a2d', 'abbr' => 'CF', 'desc' => __( 'Make web forms feel more human to improve conversions. Interactive, one question at a time layouts made easy.', 'phemightforms' ) ],
			'coupons'           => [ 'name' => 'Coupons', 'cat' => 'payment', 'color' => '#ffd66b', 'abbr' => 'Cp', 'desc' => __( 'Drive more sales by offering coupon discounts on payment forms with percentage or fixed amounts.', 'phemightforms' ) ],
			'drip'              => [ 'name' => 'Drip', 'cat' => 'marketing', 'color' => '#6f42c1', 'abbr' => 'Dr', 'desc' => __( 'Create Drip newsletter signup forms in WordPress so you can grow your email list.', 'phemightforms' ) ],
			'form-abandonment'  => [ 'name' => 'Form Abandonment', 'cat' => 'forms', 'color' => '#ea4335', 'abbr' => 'FA', 'desc' => __( 'Capture partial entries from your forms, follow up with interested leads, and turn them into customers.', 'phemightforms' ) ],
			'form-locker'       => [ 'name' => 'Form Locker', 'cat' => 'forms', 'color' => '#5f6368', 'abbr' => 'FL', 'desc' => __( 'Lock forms with passwords, members only access, date/time windows, max entry limits, and more.', 'phemightforms' ) ],
			'form-pages'        => [ 'name' => 'Form Pages', 'cat' => 'forms', 'color' => '#1a73e8', 'abbr' => 'FP', 'desc' => __( 'Create distraction free form landing pages to boost conversions without writing any code.', 'phemightforms' ) ],
			'getresponse'       => [ 'name' => 'GetResponse', 'cat' => 'marketing', 'color' => '#00baff', 'abbr' => 'GR', 'desc' => __( 'Create GetResponse newsletter signup forms in WordPress to grow your email list.', 'phemightforms' ) ],
			'hubspot'           => [ 'name' => 'HubSpot', 'cat' => 'crm', 'color' => '#ff7a59', 'abbr' => 'HS', 'desc' => __( 'Send leads from WordPress directly to your HubSpot CRM with field mapping and conditional logic.', 'phemightforms' ) ],
			'kit'               => [ 'name' => 'Kit', 'cat' => 'marketing', 'color' => '#000000', 'abbr' => 'Kt', 'desc' => __( 'Collect subscribers, automate email marketing, and connect with your audience from form submissions.', 'phemightforms' ) ],
			'klaviyo'           => [ 'name' => 'Klaviyo', 'cat' => 'marketing', 'color' => '#2b2b2b', 'abbr' => 'Kl', 'desc' => __( 'Send form submissions into Klaviyo as profiles and list members in real time to grow your email list.', 'phemightforms' ) ],
			'lead-forms'        => [ 'name' => 'Lead Forms', 'cat' => 'forms', 'color' => '#f2b541', 'abbr' => 'LF', 'desc' => __( 'Embed beautiful forms that show one question at a time to increase conversions and generate leads.', 'phemightforms' ) ],
			'mailchimp'         => [ 'name' => 'Mailchimp', 'cat' => 'marketing', 'color' => '#ffe01b', 'abbr' => 'MC', 'desc' => __( 'Create Mailchimp newsletter signup forms in WordPress to grow your email list.', 'phemightforms' ) ],
			'mailerlite'        => [ 'name' => 'MailerLite', 'cat' => 'marketing', 'color' => '#09c269', 'abbr' => 'ML', 'desc' => __( 'Send contacts from your WordPress forms to your MailerLite Groups automatically.', 'phemightforms' ) ],
			'mailpoet'          => [ 'name' => 'MailPoet', 'cat' => 'marketing', 'color' => '#fe5301', 'abbr' => 'MP', 'desc' => __( 'Integrate email marketing forms with WordPress to manage subscribers and grow your mailing list.', 'phemightforms' ) ],
			'offline-forms'     => [ 'name' => 'Offline Forms', 'cat' => 'forms', 'color' => '#607d8b', 'abbr' => 'OF', 'desc' => __( 'Let users save entered data offline and submit when their internet connection is restored.', 'phemightforms' ) ],
			'paypal-standard'   => [ 'name' => 'PayPal Standard', 'cat' => 'payment', 'color' => '#009cde', 'abbr' => 'PS', 'desc' => __( 'Connect your WordPress site with PayPal to collect payments, donations, and online orders.', 'phemightforms' ) ],
			'pipedrive'         => [ 'name' => 'Pipedrive', 'cat' => 'crm', 'color' => '#017737', 'abbr' => 'PD', 'desc' => __( 'Automate tasks through the Pipedrive CRM to nurture leads, discover insights, and more.', 'phemightforms' ) ],
			'post-submissions'  => [ 'name' => 'Post Submissions', 'cat' => 'forms', 'color' => '#2271b1', 'abbr' => 'Po', 'desc' => __( 'Have user submitted content in WordPress. Front end post submission without logging into admin.', 'phemightforms' ) ],
			'salesforce'        => [ 'name' => 'Salesforce', 'cat' => 'crm', 'color' => '#00a1e0', 'abbr' => 'SF', 'desc' => __( 'Easily send your WordPress form contacts and leads to your Salesforce CRM account.', 'phemightforms' ) ],
			'save-resume'       => [ 'name' => 'Save and Resume', 'cat' => 'forms', 'color' => '#8a4c0d', 'abbr' => 'SR', 'desc' => __( 'Let visitors save their progress and restore their entry with a click when they return.', 'phemightforms' ) ],
			'signature'         => [ 'name' => 'Signature', 'cat' => 'forms', 'color' => '#333333', 'abbr' => 'Sig', 'desc' => __( 'Let users sign your forms with mouse or touch screen for contracts and agreements.', 'phemightforms' ) ],
			'slack'             => [ 'name' => 'Slack', 'cat' => 'automation', 'color' => '#4a154b', 'abbr' => 'Sl', 'desc' => __( 'Send direct messages, channel messages, and reminders to a Slack workspace on submission.', 'phemightforms' ) ],
			'square-pro'        => [ 'name' => 'Square Pro', 'cat' => 'payment', 'color' => '#006aff', 'abbr' => 'Sq', 'desc' => __( 'Connect your WordPress site with Square to collect payments, donations, and online orders.', 'phemightforms' ) ],
			'twilio'            => [ 'name' => 'Twilio', 'cat' => 'automation', 'color' => '#f22f46', 'abbr' => 'Tw', 'desc' => __( 'Send confirmations to customers via SMS or WhatsApp upon form submission.', 'phemightforms' ) ],
			'user-registration' => [ 'name' => 'User Registration', 'cat' => 'forms', 'color' => '#2271b1', 'abbr' => 'UR', 'desc' => __( 'Create custom user registration, password reset, and login forms for your website.', 'phemightforms' ) ],
			'webhooks'          => [ 'name' => 'Webhooks', 'cat' => 'automation', 'color' => '#5c6bc0', 'abbr' => 'Wh', 'desc' => __( 'Send form entry data to external tools and services. No code and no third party connector required.', 'phemightforms' ) ],
			'zapier'            => [ 'name' => 'Zapier', 'cat' => 'automation', 'color' => '#ff4a00', 'abbr' => 'Zp', 'desc' => __( 'Connect your WordPress forms with over 9,000 web apps. Integration possibilities are endless.', 'phemightforms' ) ],
		];

		// Mark built-in features as active in this free edition.
		$built_in = [
			'stripe-pro', 'coupons', 'quiz', 'calculations', 'geolocation', 'google-sheets',
			'surveys-polls', 'user-journey', 'conversational', 'form-abandonment', 'form-locker',
			'form-pages', 'lead-forms', 'offline-forms', 'paypal-standard', 'post-submissions',
			'save-resume', 'signature', 'webhooks', 'entry-automation', 'pdf', 'mailchimp',
		];

		foreach ( $built_in as $slug ) {
			if ( isset( $items[ $slug ] ) ) {
				$items[ $slug ]['active'] = true;
			}
		}

		return $items;
	}

	/**
	 * Public URL for an addon brand logo SVG.
	 *
	 * @param string $slug Addon slug.
	 * @return string
	 */
	public static function logo_url( $slug ) {
		$file = \PHEMIGHTFORMS_DIR . 'assets/images/addons/' . sanitize_file_name( $slug ) . '.svg';

		if ( ! file_exists( $file ) ) {
			return '';
		}

		return \PHEMIGHTFORMS_URL . 'assets/images/addons/' . sanitize_file_name( $slug ) . '.svg';
	}

	/**
	 * Category labels for the sidebar filter.
	 *
	 * @return array<string,string>
	 */
	public static function categories() {
		return [
			'all'          => __( 'All Addons', 'phemightforms' ),
			'payment'      => __( 'Payments', 'phemightforms' ),
			'marketing'    => __( 'Marketing', 'phemightforms' ),
			'crm'          => __( 'CRM', 'phemightforms' ),
			'productivity' => __( 'Productivity', 'phemightforms' ),
			'automation'   => __( 'Automation', 'phemightforms' ),
			'forms'        => __( 'Form Features', 'phemightforms' ),
			'analytics'    => __( 'Analytics', 'phemightforms' ),
		];
	}

	/**
	 * Render the Addons page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$catalog     = self::catalog();
		$categories  = self::categories();
		$active      = count( array_filter( $catalog, static function ( $a ) {
			return ! empty( $a['active'] );
		} ) );
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'addons' ); ?>

			<div class="phf-page-body">
				<div class="phf-addon-hero">
					<div class="phf-addon-hero-text">
						<h2><?php esc_html_e( 'PhemightForms Addons', 'phemightforms' ); ?></h2>
						<p><?php esc_html_e( 'Access powerful marketing and payment integrations, advanced form fields, and more. All included free with PhemightForms.', 'phemightforms' ); ?></p>
						<div class="phf-addon-hero-stats">
							<span><strong><?php echo esc_html( count( $catalog ) ); ?></strong> <?php esc_html_e( 'Addons Available', 'phemightforms' ); ?></span>
							<span><strong><?php echo esc_html( $active ); ?></strong> <?php esc_html_e( 'Active Now', 'phemightforms' ); ?></span>
						</div>
					</div>
					<div class="phf-addon-hero-badge">
						<img src="<?php echo esc_url( PHEMIGHTFORMS_URL . 'assets/images/icon-topbar.png' ); ?>" alt="">
						<span><?php esc_html_e( 'Included Free', 'phemightforms' ); ?></span>
					</div>
				</div>

				<div class="phf-addon-toolbar">
					<div class="phf-tpl-search phf-addon-search">
						<span class="dashicons dashicons-search"></span>
						<input type="search" id="phf-addon-search" placeholder="<?php esc_attr_e( 'Search addons...', 'phemightforms' ); ?>" autocomplete="off">
					</div>
				</div>

				<div class="phf-tpl-layout phf-addon-layout">
					<aside class="phf-tpl-sidebar phf-addon-sidebar">
						<?php foreach ( $categories as $slug => $label ) : ?>
							<?php
							$count = 'all' === $slug
								? count( $catalog )
								: count( array_filter( $catalog, static function ( $a ) use ( $slug ) {
									return isset( $a['cat'] ) && $a['cat'] === $slug;
								} ) );
							?>
							<button type="button" class="phf-tpl-cat phf-addon-cat<?php echo 'all' === $slug ? ' is-active' : ''; ?>" data-cat="<?php echo esc_attr( $slug ); ?>">
								<?php echo esc_html( $label ); ?>
								<span class="phf-tpl-count"><?php echo esc_html( $count ); ?></span>
							</button>
						<?php endforeach; ?>
					</aside>

					<div class="phf-addon-grid" id="phf-addon-grid">
						<?php foreach ( $catalog as $slug => $addon ) : ?>
							<article class="phf-addon-card" data-cat="<?php echo esc_attr( $addon['cat'] ); ?>" data-name="<?php echo esc_attr( strtolower( $addon['name'] ) ); ?>">
								<div class="phf-addon-card-top">
									<?php $logo_url = self::logo_url( $slug ); ?>
									<span class="phf-addon-logo<?php echo $logo_url ? ' phf-addon-logo-img' : ''; ?>"<?php echo $logo_url ? '' : ' style="background:' . esc_attr( $addon['color'] ) . '"'; ?>>
										<?php if ( $logo_url ) : ?>
											<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $addon['name'] ); ?>" loading="lazy">
										<?php else : ?>
											<?php echo esc_html( $addon['abbr'] ); ?>
										<?php endif; ?>
									</span>
									<?php if ( ! empty( $addon['active'] ) ) : ?>
										<span class="phf-badge phf-badge-success"><?php esc_html_e( 'Active', 'phemightforms' ); ?></span>
									<?php endif; ?>
								</div>
								<h3><?php echo esc_html( $addon['name'] ); ?></h3>
								<p><?php echo esc_html( $addon['desc'] ); ?></p>
								<div class="phf-addon-card-actions">
									<?php if ( ! empty( $addon['active'] ) ) : ?>
										<span class="phf-btn phf-btn-ghost phf-btn-sm phf-addon-included"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Included Free', 'phemightforms' ); ?></span>
									<?php else : ?>
										<a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-settings', 'tab' => 'integrations' ], admin_url( 'admin.php' ) ) ); ?>" class="phf-btn phf-btn-primary phf-btn-sm"><?php esc_html_e( 'Configure', 'phemightforms' ); ?></a>
									<?php endif; ?>
								</div>
							</article>
						<?php endforeach; ?>
						<div class="phf-tpl-none phf-addon-none" style="display:none">
							<span class="dashicons dashicons-search"></span>
							<p><?php esc_html_e( 'No addons match your search.', 'phemightforms' ); ?></p>
						</div>
					</div>
				</div>

				<?php
				$js = <<<'JS'
( function () {
	var search = document.getElementById( 'phf-addon-search' );
	var grid = document.getElementById( 'phf-addon-grid' );
	var cards = grid ? grid.querySelectorAll( '.phf-addon-card' ) : [];
	var cats = document.querySelectorAll( '.phf-addon-cat' );
	var none = grid ? grid.querySelector( '.phf-addon-none' ) : null;
	var activeCat = 'all';

	function filter() {
		var q = search ? search.value.toLowerCase().trim() : '';
		var visible = 0;
		cards.forEach( function ( card ) {
			var matchCat = 'all' === activeCat || card.getAttribute( 'data-cat' ) === activeCat;
			var matchQ = ! q || card.getAttribute( 'data-name' ).indexOf( q ) !== -1 || card.textContent.toLowerCase().indexOf( q ) !== -1;
			var show = matchCat && matchQ;
			card.style.display = show ? '' : 'none';
			if ( show ) { visible++; }
		} );
		if ( none ) { none.style.display = visible ? 'none' : ''; }
	}

	if ( search ) { search.addEventListener( 'input', filter ); }
	cats.forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			cats.forEach( function ( b ) { b.classList.remove( 'is-active' ); } );
			btn.classList.add( 'is-active' );
			activeCat = btn.getAttribute( 'data-cat' );
			filter();
		} );
	} );
} )();
JS;
				wp_add_inline_script( 'phemightforms-admin', $js );
				?>
			</div>
		</div>
		<?php
	}
}
