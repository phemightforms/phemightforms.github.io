<?php
/**
 * Form model backed by a custom post type.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Represents a single form and its stored configuration.
 */
class Form {

	const POST_TYPE = 'phemightforms_form';

	/**
	 * WordPress post ID.
	 *
	 * @var int
	 */
	public $id;

	/**
	 * Form title.
	 *
	 * @var string
	 */
	public $title;

	/**
	 * Decoded configuration array.
	 *
	 * @var array
	 */
	public $config;

	/**
	 * Build a form object from a post ID.
	 *
	 * @param int $id Post ID.
	 */
	public function __construct( $id = 0 ) {
		$this->id     = (int) $id;
		$this->config = self::default_config();

		if ( $this->id ) {
			$post = get_post( $this->id );

			if ( $post && self::POST_TYPE === $post->post_type ) {
				$this->title  = $post->post_title;
				$stored       = json_decode( $post->post_content, true );
				$this->config = is_array( $stored ) ? wp_parse_args( $stored, self::default_config() ) : self::default_config();
			}
		}
	}

	/**
	 * Register the custom post type that stores forms.
	 */
	public static function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			[
				'label'               => __( 'PhemightForms', 'phemightforms' ),
				'public'              => false,
				'show_ui'             => false,
				'show_in_menu'        => false,
				'exclude_from_search' => true,
				'supports'            => [ 'title' ],
				'capability_type'     => 'page',
			]
		);
	}

	/**
	 * Default configuration for a new form.
	 *
	 * @return array
	 */
	public static function default_config() {
		return [
			'fields'       => [],
			'_next_id'     => 1,
			'settings'     => [
				'submit_text'           => __( 'Submit', 'phemightforms' ),
				'confirmation'          => __( 'Thanks! Your submission has been received.', 'phemightforms' ),
				'confirmation_type'     => 'message',
				'confirmation_redirect' => '',
				'confirmation_page'     => 0,
				'notify_enabled'        => 1,
				'notify_to'             => get_option( 'admin_email' ),
				'notify_subject'        => __( 'New form submission', 'phemightforms' ),
				'notify_routes'         => [],
				'confirm_rules'         => [],
				'is_quiz'               => 0,
				'webhook_enabled'       => 0,
				'webhook_url'           => '',
				'webhook_format'        => 'generic',
				'save_resume'           => 0,
				'mailchimp_enabled'     => 0,
				'mailchimp_list'        => '',
				'sheets_url'            => '',
				'landing_page'          => 0,
				'payments_enabled'      => 0,
				'payment_method'        => 'offline',
				'accent_color'          => '#b56d18',
				'button_text_color'     => '#ffffff',
				'form_bg_color'         => '#ffffff',
				'text_color'            => '#0f172a',
				'border_color'          => '#e2e8f0',
				'border_width'          => '1',
				'button_style'          => 'solid',
				'border_radius'         => '12',
				'font_size'             => '16',
				'label_position'        => 'top',
				'embed_mode'            => 'inline',
				'embed_button_text'     => __( 'Open Form', 'phemightforms' ),
			],
		];
	}

	/**
	 * Persist a form. Creates or updates the underlying post.
	 *
	 * @param string $title  Form title.
	 * @param array  $config Configuration array.
	 * @param int    $id     Existing form ID, or 0 to create.
	 * @return int Saved form ID, or 0 on failure.
	 */
	public static function save( $title, array $config, $id = 0 ) {
		$postarr = [
			'ID'           => (int) $id,
			'post_title'   => sanitize_text_field( $title ),
			'post_content' => wp_json_encode( $config ),
			'post_type'    => self::POST_TYPE,
			'post_status'  => 'publish',
		];

		$result = $id ? wp_update_post( $postarr, true ) : wp_insert_post( $postarr, true );

		return is_wp_error( $result ) ? 0 : (int) $result;
	}

	/**
	 * Delete a form.
	 *
	 * @param int $id Form ID.
	 * @return bool
	 */
	public static function delete( $id ) {
		return (bool) wp_delete_post( (int) $id, true );
	}

	/**
	 * Fetch all forms.
	 *
	 * @return \WP_Post[]
	 */
	public static function all() {
		return get_posts(
			[
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'numberposts'    => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
			]
		);
	}

	/**
	 * Whether this instance refers to a real, stored form.
	 *
	 * @return bool
	 */
	public function exists() {
		return $this->id > 0 && null !== get_post( $this->id );
	}

	/**
	 * Return the configured fields.
	 *
	 * @return array
	 */
	public function get_fields() {
		return isset( $this->config['fields'] ) && is_array( $this->config['fields'] ) ? $this->config['fields'] : [];
	}

	/**
	 * Return a single form setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public function setting( $key, $default = '' ) {
		return isset( $this->config['settings'][ $key ] ) ? $this->config['settings'][ $key ] : $default;
	}

	/**
	 * Whether this form is starred in the admin.
	 *
	 * @return bool
	 */
	public function is_starred() {
		return (bool) get_post_meta( $this->id, '_phf_starred', true );
	}

	/**
	 * Set or unset the starred flag.
	 *
	 * @param bool $starred Starred state.
	 */
	public function set_starred( $starred ) {
		update_post_meta( $this->id, '_phf_starred', $starred ? 1 : 0 );
	}

	/**
	 * Duplicate this form as a new post.
	 *
	 * @return int New form ID or 0 on failure.
	 */
	public function duplicate() {
		if ( ! $this->exists() ) {
			return 0;
		}

		$config = $this->config;
		return self::save( $this->title . ' ' . __( '(Copy)', 'phemightforms' ), $config, 0 );
	}

	/**
	 * Export configuration as a JSON string.
	 *
	 * @return string
	 */
	public function export_json() {
		return wp_json_encode(
			[
				'title'  => $this->title,
				'config' => $this->config,
			],
			JSON_PRETTY_PRINT
		);
	}
}
