<?php
/**
 * Survey and quiz reports.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Form;
use PhemightForms\Install;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Aggregates entry data into simple choice charts and quiz stats.
 */
class Reports {

	/**
	 * Placeholder constructor (instantiated by the plugin loader).
	 */
	public function __construct() {}

	/**
	 * Render the reports screen.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$forms   = Form::all();
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'reports' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Reports', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'Survey results and quiz scores for your forms.', 'phemightforms' ); ?></p>
					</div>
				</div>

				<form method="get" class="phf-filter-bar">
					<input type="hidden" name="page" value="<?php echo esc_attr( Admin::SLUG . '-reports' ); ?>">
					<select name="form" onchange="this.form.submit()">
						<option value="0"><?php esc_html_e( 'Select a form', 'phemightforms' ); ?></option>
						<?php foreach ( $forms as $post ) : ?>
							<option value="<?php echo esc_attr( $post->ID ); ?>" <?php selected( $form_id, $post->ID ); ?>><?php echo esc_html( $post->post_title ); ?></option>
						<?php endforeach; ?>
					</select>
				</form>

				<?php
				if ( $form_id ) {
					self::render_report( $form_id );
				} elseif ( $forms ) {
					?>
					<div class="phf-card-panel">
						<div class="phf-empty-state">
							<span class="dashicons dashicons-chart-bar"></span>
							<p><?php esc_html_e( 'Select a form above to view its report.', 'phemightforms' ); ?></p>
						</div>
					</div>
					<?php
				} else {
					?>
					<div class="phf-card-panel">
						<div class="phf-empty-state">
							<span class="dashicons dashicons-chart-bar"></span>
							<p><?php esc_html_e( 'Create a form first to see reports.', 'phemightforms' ); ?></p>
						</div>
					</div>
					<?php
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the aggregated report for one form.
	 *
	 * @param int $form_id Form ID.
	 */
	private static function render_report( $form_id ) {
		global $wpdb;

		$form  = new Form( $form_id );
		$table = Install::entries_table();
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT fields FROM {$table} WHERE form_id = %d", $form_id ) ); // phpcs:ignore WordPress.DB
		$total = count( $rows );

		if ( 0 === $total ) {
			echo '<div class="phf-card-panel"><div class="phf-empty-state"><span class="dashicons dashicons-chart-bar"></span><p>' . esc_html__( 'No entries yet for this form.', 'phemightforms' ) . '</p></div></div>';
			return;
		}

		/* translators: %d: total submission count. */
		echo '<p class="phf-report-summary"><span class="dashicons dashicons-groups"></span> ' . sprintf( esc_html__( 'Total submissions: %d', 'phemightforms' ), (int) $total ) . '</p>';

		// Choice fields defined on the form (label + allowed choices).
		$registry      = \PhemightForms\phemightforms()->fields;
		$choice_fields = [];
		foreach ( $form->get_fields() as $field ) {
			if ( isset( $field['type'] ) && $registry->has_choices( $field['type'] ) ) {
				$choice_fields[ $field['label'] ] = [
					'choices' => isset( $field['choices'] ) ? $field['choices'] : [],
					'counts'  => [],
				];
			}
		}

		// Tally answers from the stored entries.
		$quiz_scores = [];
		foreach ( $rows as $row ) {
			$data = json_decode( $row->fields, true );
			if ( ! is_array( $data ) ) {
				continue;
			}
			foreach ( $data as $item ) {
				$label = isset( $item['label'] ) ? $item['label'] : '';

				if ( isset( $item['type'] ) && 'quiz' === $item['type'] ) {
					$quiz_scores[] = $item['value'];
					continue;
				}

				if ( ! isset( $choice_fields[ $label ] ) ) {
					continue;
				}

				$values = array_map( 'trim', explode( ',', (string) $item['value'] ) );
				foreach ( $values as $value ) {
					if ( '' === $value ) {
						continue;
					}
					if ( ! isset( $choice_fields[ $label ]['counts'][ $value ] ) ) {
						$choice_fields[ $label ]['counts'][ $value ] = 0;
					}
					$choice_fields[ $label ]['counts'][ $value ]++;
				}
			}
		}

		// Quiz summary.
		if ( $quiz_scores ) {
			self::render_quiz_summary( $quiz_scores );
		}

		// Choice charts.
		foreach ( $choice_fields as $label => $info ) {
			echo '<div class="phemightforms-report-block">';
			echo '<h2>' . esc_html( $label ) . '</h2>';

			$labels_to_show = ! empty( $info['choices'] ) ? $info['choices'] : array_keys( $info['counts'] );

			foreach ( $labels_to_show as $choice ) {
				$count = isset( $info['counts'][ $choice ] ) ? $info['counts'][ $choice ] : 0;
				$pct   = $total > 0 ? round( ( $count / $total ) * 100 ) : 0;
				?>
				<div class="phemightforms-bar-row">
					<span class="phemightforms-bar-label"><?php echo esc_html( $choice ); ?></span>
					<span class="phemightforms-bar-track"><span class="phemightforms-bar-fill" style="width:<?php echo esc_attr( $pct ); ?>%"></span></span>
					<span class="phemightforms-bar-value"><?php echo esc_html( $count . ' (' . $pct . '%)' ); ?></span>
				</div>
				<?php
			}
			echo '</div>';
		}
	}

	/**
	 * Render quiz score statistics.
	 *
	 * @param array $scores Array of "x / y" strings.
	 */
	private static function render_quiz_summary( array $scores ) {
		$total_pct = 0;
		$counted   = 0;

		foreach ( $scores as $score ) {
			if ( preg_match( '/(\d+)\s*\/\s*(\d+)/', $score, $m ) && (int) $m[2] > 0 ) {
				$total_pct += ( (int) $m[1] / (int) $m[2] ) * 100;
				$counted++;
			}
		}

		$avg = $counted > 0 ? round( $total_pct / $counted ) : 0;

		echo '<div class="phemightforms-report-block">';
		echo '<h2>' . esc_html__( 'Quiz results', 'phemightforms' ) . '</h2>';
		/* translators: %d: average quiz score percentage. */
		echo '<p>' . sprintf( esc_html__( 'Average score: %d%%', 'phemightforms' ), (int) $avg ) . '</p>';
		echo '</div>';
	}
}
