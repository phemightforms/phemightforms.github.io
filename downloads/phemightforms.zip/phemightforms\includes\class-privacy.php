<?php
/**
 * Privacy compliance: controls what personal data is stored and hooks
 * PhemightForms entries into the WordPress core privacy tools.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Privacy behaviors applied to submissions plus WP core exporter/eraser.
 */
class Privacy {

	/**
	 * Register WordPress personal data exporter and eraser.
	 */
	public function __construct() {
		add_filter( 'wp_privacy_personal_data_exporters', [ $this, 'register_exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers', [ $this, 'register_eraser' ] );
	}

	/**
	 * Filter an IP address according to the privacy settings.
	 *
	 * @param string $ip Raw client IP.
	 * @return string Stored value.
	 */
	public static function store_ip( $ip ) {
		if ( Plugin::get_option( 'privacy_disable_ip', 0 ) ) {
			return '';
		}

		if ( Plugin::get_option( 'privacy_anonymize_ip', 0 ) && function_exists( 'wp_privacy_anonymize_ip' ) ) {
			return wp_privacy_anonymize_ip( $ip );
		}

		return $ip;
	}

	/**
	 * Filter a user agent string according to the privacy settings.
	 *
	 * @param string $ua Raw user agent.
	 * @return string Stored value.
	 */
	public static function store_ua( $ua ) {
		return Plugin::get_option( 'privacy_disable_ua', 0 ) ? '' : $ua;
	}

	/**
	 * Add the PhemightForms exporter to WP's personal data export tool.
	 *
	 * @param array $exporters Registered exporters.
	 * @return array
	 */
	public function register_exporter( $exporters ) {
		$exporters['phemightforms'] = [
			'exporter_friendly_name' => __( 'PhemightForms Entries', 'phemightforms' ),
			'callback'               => [ $this, 'export_personal_data' ],
		];

		return $exporters;
	}

	/**
	 * Add the PhemightForms eraser to WP's personal data erase tool.
	 *
	 * @param array $erasers Registered erasers.
	 * @return array
	 */
	public function register_eraser( $erasers ) {
		$erasers['phemightforms'] = [
			'eraser_friendly_name' => __( 'PhemightForms Entries', 'phemightforms' ),
			'callback'             => [ $this, 'erase_personal_data' ],
		];

		return $erasers;
	}

	/**
	 * WP core exporter callback: return entry data containing the email.
	 *
	 * @param string $email Email address being exported.
	 * @param int    $page  Pagination (unused; single pass).
	 * @return array
	 */
	public function export_personal_data( $email, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		$export = [];

		foreach ( self::find_entries( $email ) as $row ) {
			$data   = [];
			$fields = json_decode( $row->fields, true );

			if ( is_array( $fields ) ) {
				foreach ( $fields as $field ) {
					if ( isset( $field['label'], $field['value'] ) && '' !== $field['value'] ) {
						$data[] = [
							'name'  => $field['label'],
							'value' => is_array( $field['value'] ) ? implode( ', ', $field['value'] ) : $field['value'],
						];
					}
				}
			}

			if ( $row->ip_address ) {
				$data[] = [
					'name'  => __( 'IP Address', 'phemightforms' ),
					'value' => $row->ip_address,
				];
			}

			$data[] = [
				'name'  => __( 'Submitted', 'phemightforms' ),
				'value' => $row->created_at,
			];

			$export[] = [
				'group_id'    => 'phemightforms-entries',
				'group_label' => __( 'Form Submissions (PhemightForms)', 'phemightforms' ),
				'item_id'     => 'phemightforms-entry-' . $row->id,
				'data'        => $data,
			];
		}

		return [
			'data' => $export,
			'done' => true,
		];
	}

	/**
	 * WP core eraser callback: delete entries containing the email.
	 *
	 * @param string $email Email address being erased.
	 * @param int    $page  Pagination (unused; single pass).
	 * @return array
	 */
	public function erase_personal_data( $email, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		global $wpdb;

		$table   = Install::entries_table();
		$removed = 0;

		foreach ( self::find_entries( $email ) as $row ) {
			$wpdb->delete( $table, [ 'id' => $row->id ], [ '%d' ] ); // phpcs:ignore WordPress.DB
			$removed++;
		}

		return [
			'items_removed'  => $removed,
			'items_retained' => false,
			'messages'       => [],
			'done'           => true,
		];
	}

	/**
	 * Entry rows whose stored JSON contains the email address.
	 *
	 * @param string $email Email address.
	 * @return array
	 */
	private static function find_entries( $email ) {
		global $wpdb;

		if ( ! is_email( $email ) ) {
			return [];
		}

		$table = Install::entries_table();
		$like  = '%' . $wpdb->esc_like( $email ) . '%';

		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE fields LIKE %s", $like ) ); // phpcs:ignore WordPress.DB
	}
}
