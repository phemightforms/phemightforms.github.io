<?php
/**
 * Save & Resume: lets visitors store a partial submission and finish later.
 *
 * Partial data is stored in a transient keyed by a random token. The visitor
 * gets a link containing the token; opening it repopulates the form.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AJAX endpoints for storing and retrieving partial submissions.
 */
class SaveResume {

	const TTL = WEEK_IN_SECONDS;

	/**
	 * Register AJAX handlers.
	 */
	public function __construct() {
		add_action( 'wp_ajax_phemightforms_save_partial', [ $this, 'save' ] );
		add_action( 'wp_ajax_nopriv_phemightforms_save_partial', [ $this, 'save' ] );
		add_action( 'wp_ajax_phemightforms_get_partial', [ $this, 'get' ] );
		add_action( 'wp_ajax_nopriv_phemightforms_get_partial', [ $this, 'get' ] );
	}

	/**
	 * Store a partial submission and return a resume token/URL.
	 */
	public function save() {
		$form_id = isset( $_POST['form_id'] ) ? absint( wp_unslash( $_POST['form_id'] ) ) : 0;
		$nonce   = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'phemightforms_submit_' . $form_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'phemightforms' ) ], 403 );
		}

		$raw    = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- decoded and sanitized below.
		$fields = json_decode( $raw, true );

		if ( ! is_array( $fields ) ) {
			$fields = [];
		}

		$clean = [];
		foreach ( $fields as $key => $value ) {
			$key = sanitize_key( $key );
			if ( is_array( $value ) ) {
				$clean[ $key ] = array_map( 'sanitize_text_field', $value );
			} else {
				$clean[ $key ] = sanitize_text_field( $value );
			}
		}

		$token = wp_generate_password( 20, false );
		set_transient( 'phf_resume_' . $token, [ 'form_id' => $form_id, 'fields' => $clean ], self::TTL );

		wp_send_json_success(
			[
				'token' => $token,
				'url'   => add_query_arg( 'phf_resume', $token, $this->current_url() ),
			]
		);
	}

	/**
	 * Return a stored partial submission by token.
	 */
	public function get() {
		$token = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		$data  = $token ? get_transient( 'phf_resume_' . $token ) : false;

		if ( ! $data ) {
			wp_send_json_error( [ 'message' => __( 'Saved data not found or expired.', 'phemightforms' ) ], 404 );
		}

		wp_send_json_success( $data );
	}

	/**
	 * Best-effort current front-end URL (referer based).
	 *
	 * @return string
	 */
	private function current_url() {
		$ref = wp_get_referer();

		return $ref ? $ref : home_url( '/' );
	}
}
