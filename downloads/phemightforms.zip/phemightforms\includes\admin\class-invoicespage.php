<?php
/**
 * Invoices & Payment Links admin screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Invoices;
use PhemightForms\InvoicePdf;
use PhemightForms\Payments;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Create, list, and manage invoices and payment links.
 */
class InvoicesPage {

	/**
	 * Hook save and delete handlers.
	 */
	public function __construct() {
		add_action( 'admin_post_phemightforms_save_invoice', [ $this, 'handle_save' ] );
		add_action( 'admin_post_phemightforms_delete_invoice', [ $this, 'handle_delete' ] );
		add_action( 'admin_post_phemightforms_invoice_pdf', [ $this, 'handle_pdf' ] );
	}

	/**
	 * Save a new or updated invoice / payment link.
	 */
	public function handle_save() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_invoice' );

		$id = isset( $_POST['invoice_id'] ) ? sanitize_text_field( wp_unslash( $_POST['invoice_id'] ) ) : '';

		$saved_id = Invoices::save(
			[
				'type'                => isset( $_POST['invoice_type'] ) ? sanitize_key( wp_unslash( $_POST['invoice_type'] ) ) : 'invoice',
				'title'               => isset( $_POST['title'] ) ? wp_unslash( $_POST['title'] ) : '',
				'description'         => isset( $_POST['description'] ) ? wp_unslash( $_POST['description'] ) : '',
				'amount'              => isset( $_POST['amount'] ) ? wp_unslash( $_POST['amount'] ) : 0,
				'customer_name'       => isset( $_POST['customer_name'] ) ? wp_unslash( $_POST['customer_name'] ) : '',
				'customer_email'      => isset( $_POST['customer_email'] ) ? wp_unslash( $_POST['customer_email'] ) : '',
				'payment_methods_all' => ! empty( $_POST['payment_methods_all'] ),
				'payment_methods'     => isset( $_POST['payment_methods'] ) ? wp_unslash( $_POST['payment_methods'] ) : [],
				'due_date'            => isset( $_POST['due_date'] ) ? wp_unslash( $_POST['due_date'] ) : '',
				'line_items'          => isset( $_POST['line_items'] ) ? wp_unslash( $_POST['line_items'] ) : '',
			],
			$id
		);

		wp_safe_redirect(
			add_query_arg(
				[
					'page'  => Admin::SLUG . '-invoices',
					'edit'  => $saved_id,
					'saved' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Download an invoice PDF from the admin.
	 */
	public function handle_pdf() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_invoice_pdf' );

		$id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$item = $id ? Invoices::get( $id ) : null;

		if ( ! $item ) {
			wp_die( esc_html__( 'Invoice not found.', 'phemightforms' ) );
		}

		InvoicePdf::download( $item );
	}

	/**
	 * Delete an invoice.
	 */
	public function handle_delete() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_delete_invoice' );

		$id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( $id ) {
			Invoices::delete( $id );
		}

		wp_safe_redirect(
			add_query_arg(
				[
					'page'    => Admin::SLUG . '-invoices',
					'deleted' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render the admin page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$tab      = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$edit_id  = isset( $_GET['edit'] ) ? sanitize_text_field( wp_unslash( $_GET['edit'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$items    = Invoices::all();
		$providers = Payments::enabled_providers();

		if ( ! $providers ) {
			$providers = [ 'offline' => __( 'Offline / Manual', 'phemightforms' ) ];
		}

		$paid_total = 0;
		$pending    = 0;

		foreach ( $items as $row ) {
			if ( 'paid' === ( $row['status'] ?? '' ) ) {
				$paid_total += (float) ( $row['amount'] ?? 0 );
			} else {
				$pending++;
			}
		}

		$editing = $edit_id ? Invoices::get( $edit_id ) : null;

		if ( 'create' === $tab || $editing ) {
			self::render_form( $editing, $providers, $tab );
			return;
		}

		$filter = isset( $_GET['filter'] ) ? sanitize_key( wp_unslash( $_GET['filter'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$base   = add_query_arg( [ 'page' => Admin::SLUG . '-invoices' ], admin_url( 'admin.php' ) );
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'invoices' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Invoices & Payment Links', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'Create standalone invoices or simple payment links you can share anywhere. Customers pay through your configured gateways.', 'phemightforms' ); ?></p>
					</div>
					<a href="<?php echo esc_url( add_query_arg( [ 'tab' => 'create', 'type' => 'invoice' ], $base ) ); ?>" class="phf-btn phf-btn-primary"><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'Create Invoice', 'phemightforms' ); ?></a>
				</div>

				<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Saved successfully.', 'phemightforms' ); ?></div>
				<?php endif; ?>
				<?php if ( isset( $_GET['deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Deleted.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<div class="phf-stat-grid">
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-green"><span class="dashicons dashicons-money-alt"></span></span>
						<div><span class="phf-stat-number"><?php echo esc_html( Payments::format( $paid_total ) ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Collected', 'phemightforms' ); ?></span></div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-blue"><span class="dashicons dashicons-media-text"></span></span>
						<div><span class="phf-stat-number"><?php echo esc_html( count( $items ) ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Total', 'phemightforms' ); ?></span></div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-amber"><span class="dashicons dashicons-clock"></span></span>
						<div><span class="phf-stat-number"><?php echo esc_html( $pending ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Awaiting Payment', 'phemightforms' ); ?></span></div>
					</div>
				</div>

				<div class="phf-subnav">
					<a href="<?php echo esc_url( add_query_arg( 'filter', 'all', $base ) ); ?>" class="phf-subnav-item<?php echo 'all' === $filter ? ' is-active' : ''; ?>"><?php esc_html_e( 'All', 'phemightforms' ); ?></a>
					<a href="<?php echo esc_url( add_query_arg( 'filter', 'invoice', $base ) ); ?>" class="phf-subnav-item<?php echo 'invoice' === $filter ? ' is-active' : ''; ?>"><span class="dashicons dashicons-media-text"></span> <?php esc_html_e( 'Invoices', 'phemightforms' ); ?></a>
					<a href="<?php echo esc_url( add_query_arg( 'filter', 'payment_link', $base ) ); ?>" class="phf-subnav-item<?php echo 'payment_link' === $filter ? ' is-active' : ''; ?>"><span class="dashicons dashicons-admin-links"></span> <?php esc_html_e( 'Payment Links', 'phemightforms' ); ?></a>
					<a href="<?php echo esc_url( add_query_arg( [ 'tab' => 'create', 'type' => 'payment_link' ], $base ) ); ?>" class="phf-subnav-item phf-subnav-action"><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'New Payment Link', 'phemightforms' ); ?></a>
				</div>

				<div class="phf-card-panel phf-table-panel">
					<?php
					$filtered = array_filter(
						$items,
						static function ( $row ) use ( $filter ) {
							if ( 'all' === $filter ) {
								return true;
							}
							return ( $row['type'] ?? 'invoice' ) === $filter;
						}
					);
					?>
					<?php if ( ! $filtered ) : ?>
						<div class="phf-empty-state">
							<span class="dashicons dashicons-media-text"></span>
							<p><?php esc_html_e( 'No invoices or payment links yet. Create one and share the link with your customer.', 'phemightforms' ); ?></p>
							<a href="<?php echo esc_url( add_query_arg( [ 'tab' => 'create', 'type' => 'payment_link' ], $base ) ); ?>" class="phf-btn phf-btn-primary"><?php esc_html_e( 'Create Payment Link', 'phemightforms' ); ?></a>
						</div>
					<?php else : ?>
						<table class="phf-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Title', 'phemightforms' ); ?></th>
									<th><?php esc_html_e( 'Type', 'phemightforms' ); ?></th>
									<th><?php esc_html_e( 'Amount', 'phemightforms' ); ?></th>
									<th><?php esc_html_e( 'Customer', 'phemightforms' ); ?></th>
									<th><?php esc_html_e( 'Status', 'phemightforms' ); ?></th>
									<th><?php esc_html_e( 'Payment Link', 'phemightforms' ); ?></th>
									<th></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $filtered as $row ) : ?>
									<?php
									$pay_url = Invoices::url( $row['slug'] );
									$type_l  = 'payment_link' === ( $row['type'] ?? '' ) ? __( 'Payment Link', 'phemightforms' ) : __( 'Invoice', 'phemightforms' );
									$status  = $row['status'] ?? 'pending';
									?>
									<tr>
										<td data-label="<?php esc_attr_e( 'Title', 'phemightforms' ); ?>"><strong><?php echo esc_html( $row['title'] ); ?></strong></td>
										<td data-label="<?php esc_attr_e( 'Type', 'phemightforms' ); ?>"><span class="phf-badge"><?php echo esc_html( $type_l ); ?></span></td>
										<td data-label="<?php esc_attr_e( 'Amount', 'phemightforms' ); ?>"><strong><?php echo esc_html( Payments::format( $row['amount'] ) ); ?></strong></td>
										<td data-label="<?php esc_attr_e( 'Customer', 'phemightforms' ); ?>"><?php echo esc_html( $row['customer_name'] ? $row['customer_name'] : ( $row['customer_email'] ? $row['customer_email'] : __( 'None', 'phemightforms' ) ) ); ?></td>
										<td data-label="<?php esc_attr_e( 'Status', 'phemightforms' ); ?>">
											<span class="phf-badge <?php echo 'paid' === $status ? 'phf-badge-success' : 'phf-badge-warning'; ?>"><?php echo esc_html( ucfirst( $status ) ); ?></span>
										</td>
										<td data-label="<?php esc_attr_e( 'Payment Link', 'phemightforms' ); ?>">
											<div class="phf-invoice-link">
												<input type="text" readonly value="<?php echo esc_attr( $pay_url ); ?>" class="phf-copy-input" id="phf-link-<?php echo esc_attr( $row['id'] ); ?>">
												<button type="button" class="phf-btn phf-btn-ghost phf-btn-sm phf-copy-btn" data-target="phf-link-<?php echo esc_attr( $row['id'] ); ?>"><span class="dashicons dashicons-admin-page"></span></button>
												<a href="<?php echo esc_url( $pay_url ); ?>" target="_blank" rel="noopener" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-external"></span></a>
											</div>
										</td>
										<td>
											<?php if ( 'invoice' === ( $row['type'] ?? 'invoice' ) ) : ?>
												<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'phemightforms_invoice_pdf', 'id' => $row['id'] ], admin_url( 'admin-post.php' ) ), 'phemightforms_invoice_pdf' ) ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm" title="<?php esc_attr_e( 'Download PDF', 'phemightforms' ); ?>"><span class="dashicons dashicons-pdf"></span></a>
											<?php endif; ?>
											<a href="<?php echo esc_url( add_query_arg( 'edit', $row['id'], $base ) ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-edit"></span></a>
											<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'phemightforms_delete_invoice', 'id' => $row['id'] ], admin_url( 'admin-post.php' ) ), 'phemightforms_delete_invoice' ) ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm phf-btn-danger" onclick="return confirm('<?php echo esc_js( __( 'Delete this item?', 'phemightforms' ) ); ?>');"><span class="dashicons dashicons-trash"></span></a>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>

				<?php
				wp_add_inline_script(
					'phemightforms-admin',
					"document.querySelectorAll( '.phf-copy-btn' ).forEach( function ( btn ) {
						btn.addEventListener( 'click', function () {
							var input = document.getElementById( btn.getAttribute( 'data-target' ) );
							if ( ! input ) { return; }
							input.select();
							input.setSelectionRange( 0, 99999 );
							navigator.clipboard.writeText( input.value ).then( function () {
								btn.innerHTML = '<span class=\"dashicons dashicons-yes\"></span>';
								setTimeout( function () { btn.innerHTML = '<span class=\"dashicons dashicons-admin-page\"></span>'; }, 1500 );
							} );
						} );
					} );"
				);
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Create / edit form.
	 *
	 * @param array|null $item      Existing row or null.
	 * @param array      $providers Enabled payment methods.
	 * @param string     $tab       Current tab.
	 */
	private static function render_form( $item, array $providers, $tab ) {
		$is_edit   = (bool) $item;
		$type      = $item['type'] ?? ( isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : 'invoice' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$base      = add_query_arg( [ 'page' => Admin::SLUG . '-invoices' ], admin_url( 'admin.php' ) );
		$is_link   = 'payment_link' === $type;
		$currency  = Payments::symbol();
		$status    = $item['status'] ?? 'pending';
		$pay_url   = ( $is_edit && ! empty( $item['slug'] ) ) ? Invoices::url( $item['slug'] ) : '';
		$pdf_url   = ( $is_edit && ! empty( $item['slug'] ) && ! $is_link ) ? Invoices::pdf_url( $item['slug'] ) : '';
		$saved_methods = $item ? array_keys( Invoices::payment_methods_for( $item ) ) : array_keys( $providers );
		$all_methods   = count( $saved_methods ) === count( $providers );
		$method_preview = count( $saved_methods ) > 1
			? sprintf(
				/* translators: %d: number of payment methods */
				__( 'Customer chooses from %d payment options', 'phemightforms' ),
				count( $saved_methods )
			)
			: ( $providers[ $saved_methods[0] ?? 'offline' ] ?? __( 'Offline / Manual', 'phemightforms' ) );

		if ( $is_edit ) {
			$hero_title = $is_link ? __( 'Edit Payment Link', 'phemightforms' ) : __( 'Edit Invoice', 'phemightforms' );
			$hero_desc  = $is_link
				? __( 'Update your payment link details. The share URL stays the same unless you change the title.', 'phemightforms' )
				: __( 'Update invoice details, customer info, and line items. Share the link when you\'re ready to collect payment.', 'phemightforms' );
		} elseif ( $is_link ) {
			$hero_title = __( 'Create Payment Link', 'phemightforms' );
			$hero_desc  = __( 'Build a clean, shareable checkout page in seconds. Perfect for deposits, donations, or one time fees.', 'phemightforms' );
		} else {
			$hero_title = __( 'Create Invoice', 'phemightforms' );
			$hero_desc  = __( 'Send a professional invoice with customer details, line items, due date, and a branded pay now page.', 'phemightforms' );
		}
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'invoices' ); ?>

			<div class="phf-page-body phf-invoice-page">
				<div class="phf-invoice-hero">
					<div class="phf-invoice-hero-text">
						<h2><?php echo esc_html( $hero_title ); ?></h2>
						<p><?php echo esc_html( $hero_desc ); ?></p>
					</div>
					<div class="phf-invoice-hero-badge">
						<div class="phf-invoice-hero-icon">
							<span class="dashicons <?php echo $is_link ? 'dashicons-admin-links' : 'dashicons-media-text'; ?>"></span>
						</div>
						<span><?php echo $is_link ? esc_html__( 'Payment Link', 'phemightforms' ) : esc_html__( 'Invoice', 'phemightforms' ); ?></span>
					</div>
				</div>

				<?php if ( ! $is_edit ) : ?>
					<div class="phf-invoice-type-tabs">
						<a href="<?php echo esc_url( add_query_arg( [ 'tab' => 'create', 'type' => 'invoice' ], $base ) ); ?>" class="phf-invoice-type-tab<?php echo ! $is_link ? ' is-active' : ''; ?>">
							<span class="dashicons dashicons-media-text"></span>
							<?php esc_html_e( 'Invoice', 'phemightforms' ); ?>
						</a>
						<a href="<?php echo esc_url( add_query_arg( [ 'tab' => 'create', 'type' => 'payment_link' ], $base ) ); ?>" class="phf-invoice-type-tab<?php echo $is_link ? ' is-active' : ''; ?>">
							<span class="dashicons dashicons-admin-links"></span>
							<?php esc_html_e( 'Payment Link', 'phemightforms' ); ?>
						</a>
					</div>
				<?php else : ?>
					<div class="phf-page-title" style="margin-bottom:18px;">
						<a href="<?php echo esc_url( $base ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-arrow-left-alt2"></span> <?php esc_html_e( 'Back to list', 'phemightforms' ); ?></a>
					</div>
				<?php endif; ?>

				<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success" style="margin-bottom:18px;"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Saved successfully! Your payment link is ready to share below.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="phf-invoice-form" id="phf-invoice-form">
					<?php wp_nonce_field( 'phemightforms_invoice' ); ?>
					<input type="hidden" name="action" value="phemightforms_save_invoice">
					<input type="hidden" name="invoice_type" value="<?php echo esc_attr( $type ); ?>">
					<?php if ( $is_edit ) : ?>
						<input type="hidden" name="invoice_id" value="<?php echo esc_attr( $item['id'] ); ?>">
					<?php endif; ?>

					<div class="phf-invoice-builder">
						<div class="phf-invoice-main">
							<?php if ( $is_edit && $pay_url ) : ?>
								<div class="phf-invoice-share-banner">
									<div class="phf-invoice-share-icon"><span class="dashicons dashicons-admin-links"></span></div>
									<div class="phf-invoice-share-body">
										<h3><?php esc_html_e( 'Share this payment link', 'phemightforms' ); ?></h3>
										<p><?php esc_html_e( 'Send this URL to your customer by email, SMS, or chat. They\'ll see a branded checkout page.', 'phemightforms' ); ?></p>
										<div class="phf-invoice-link">
											<input type="text" readonly value="<?php echo esc_attr( $pay_url ); ?>" id="phf-share-link">
											<button type="button" class="phf-btn phf-btn-ghost phf-copy-btn" data-target="phf-share-link"><span class="dashicons dashicons-admin-page"></span> <?php esc_html_e( 'Copy', 'phemightforms' ); ?></button>
											<a href="<?php echo esc_url( $pay_url ); ?>" target="_blank" rel="noopener" class="phf-btn phf-btn-ghost"><span class="dashicons dashicons-external"></span> <?php esc_html_e( 'Preview', 'phemightforms' ); ?></a>
											<?php if ( ! $is_link && $is_edit ) : ?>
												<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'phemightforms_invoice_pdf', 'id' => $item['id'] ], admin_url( 'admin-post.php' ) ), 'phemightforms_invoice_pdf' ) ); ?>" class="phf-btn phf-btn-ghost"><span class="dashicons dashicons-pdf"></span> <?php esc_html_e( 'PDF', 'phemightforms' ); ?></a>
											<?php endif; ?>
										</div>
									</div>
									<?php if ( 'paid' === $status ) : ?>
										<span class="phf-badge phf-badge-success"><?php esc_html_e( 'Paid', 'phemightforms' ); ?></span>
									<?php else : ?>
										<span class="phf-badge phf-badge-warning"><?php esc_html_e( 'Pending', 'phemightforms' ); ?></span>
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<div class="phf-card-panel phf-settings-card">
								<div class="phf-panel-head">
									<h3><span class="dashicons dashicons-cart"></span> <?php esc_html_e( 'Payment Details', 'phemightforms' ); ?></h3>
									<span class="phf-muted"><?php echo $is_link ? esc_html__( 'What your customer will pay for.', 'phemightforms' ) : esc_html__( 'Title, amount, and how the customer pays.', 'phemightforms' ); ?></span>
								</div>
								<div class="phf-setting-row">
									<div class="phf-setting-label">
										<label for="phf-inv-title"><?php esc_html_e( 'Title', 'phemightforms' ); ?></label>
										<p><?php esc_html_e( 'Shown as the main heading on the checkout page.', 'phemightforms' ); ?></p>
									</div>
									<div class="phf-setting-control">
										<input type="text" id="phf-inv-title" name="title" required value="<?php echo esc_attr( $item['title'] ?? '' ); ?>" placeholder="<?php echo esc_attr( $is_link ? __( 'Consultation fee', 'phemightforms' ) : __( 'Website design deposit', 'phemightforms' ) ); ?>" data-preview="title">
									</div>
								</div>
								<div class="phf-setting-row">
									<div class="phf-setting-label">
										<label for="phf-inv-desc"><?php esc_html_e( 'Description', 'phemightforms' ); ?></label>
										<p><?php esc_html_e( 'Optional note displayed below the title.', 'phemightforms' ); ?></p>
									</div>
									<div class="phf-setting-control">
										<textarea id="phf-inv-desc" name="description" rows="3" placeholder="<?php esc_attr_e( 'Thank you for your business. Payment is due upon receipt.', 'phemightforms' ); ?>" data-preview="description"><?php echo esc_textarea( $item['description'] ?? '' ); ?></textarea>
									</div>
								</div>
								<div class="phf-setting-row">
									<div class="phf-setting-label">
										<label for="phf-inv-amount"><?php esc_html_e( 'Amount', 'phemightforms' ); ?></label>
										<p><?php
										/* translators: %s: currency code. */
										printf( esc_html__( 'Charged in %s.', 'phemightforms' ), esc_html( Payments::currency() ) );
										?></p>
									</div>
									<div class="phf-setting-control">
										<div class="phf-amount-input">
											<span class="phf-amount-symbol"><?php echo esc_html( $currency ); ?></span>
											<input type="number" step="0.01" min="0.01" id="phf-inv-amount" name="amount" required value="<?php echo esc_attr( $item['amount'] ?? '' ); ?>" placeholder="99.00" data-preview="amount">
										</div>
									</div>
								</div>
								<div class="phf-setting-row phf-setting-row-stack">
									<div class="phf-setting-label">
										<label><?php esc_html_e( 'Accepted payment methods', 'phemightforms' ); ?></label>
										<p><?php esc_html_e( 'Choose which gateways customers can use. Enable all to let them pick at checkout.', 'phemightforms' ); ?></p>
									</div>
									<div class="phf-setting-control">
										<label class="phf-inv-method-all">
											<input type="checkbox" name="payment_methods_all" value="1" id="phf-methods-all" <?php checked( $all_methods ); ?>>
											<strong><?php esc_html_e( 'All enabled payment integrations (recommended)', 'phemightforms' ); ?></strong>
											<span><?php esc_html_e( 'Customer selects their preferred gateway on the checkout page.', 'phemightforms' ); ?></span>
										</label>
										<div class="phf-inv-methods-grid" id="phf-methods-grid">
											<?php foreach ( $providers as $slug => $label ) : ?>
												<?php $brand = Payments::provider_brand( $slug ); ?>
												<label class="phf-inv-method-option">
													<input type="checkbox" name="payment_methods[]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, $saved_methods, true ) ); ?> data-method-label="<?php echo esc_attr( $label ); ?>">
													<span class="phf-provider-logo <?php echo esc_attr( $brand['class'] ); ?>"><?php echo esc_html( $brand['abbr'] ); ?></span>
													<span class="phf-inv-method-name"><?php echo esc_html( $label ); ?></span>
												</label>
											<?php endforeach; ?>
										</div>
									</div>
								</div>
							</div>

							<?php if ( ! $is_link ) : ?>
								<div class="phf-card-panel phf-settings-card">
									<div class="phf-panel-head">
										<h3><span class="dashicons dashicons-businessman"></span> <?php esc_html_e( 'Customer & Line Items', 'phemightforms' ); ?></h3>
										<span class="phf-muted"><?php esc_html_e( 'Bill to details and itemized charges shown on the invoice.', 'phemightforms' ); ?></span>
									</div>
									<div class="phf-setting-row">
										<div class="phf-setting-label"><label for="phf-inv-name"><?php esc_html_e( 'Customer name', 'phemightforms' ); ?></label></div>
										<div class="phf-setting-control"><input type="text" id="phf-inv-name" name="customer_name" value="<?php echo esc_attr( $item['customer_name'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Jane Smith', 'phemightforms' ); ?>" data-preview="customer_name"></div>
									</div>
									<div class="phf-setting-row">
										<div class="phf-setting-label"><label for="phf-inv-email"><?php esc_html_e( 'Customer email', 'phemightforms' ); ?></label></div>
										<div class="phf-setting-control"><input type="email" id="phf-inv-email" name="customer_email" value="<?php echo esc_attr( $item['customer_email'] ?? '' ); ?>" placeholder="customer@example.com" data-preview="customer_email"></div>
									</div>
									<div class="phf-setting-row">
										<div class="phf-setting-label"><label for="phf-inv-due"><?php esc_html_e( 'Due date', 'phemightforms' ); ?></label></div>
										<div class="phf-setting-control"><input type="date" id="phf-inv-due" name="due_date" value="<?php echo esc_attr( $item['due_date'] ?? '' ); ?>" data-preview="due_date"></div>
									</div>
									<div class="phf-setting-row">
										<div class="phf-setting-label">
											<label for="phf-inv-lines"><?php esc_html_e( 'Line items', 'phemightforms' ); ?></label>
											<p><?php esc_html_e( 'One item per line.', 'phemightforms' ); ?></p>
										</div>
										<div class="phf-setting-control">
											<textarea id="phf-inv-lines" name="line_items" rows="5" placeholder="Design work|500&#10;Hosting setup|50" data-preview="line_items"><?php echo esc_textarea( $item['line_items'] ?? '' ); ?></textarea>
											<div class="phf-line-items-hint">
												<span class="dashicons dashicons-info-outline"></span>
												<span><?php esc_html_e( 'Format: Item name|Price (e.g. Logo design|250 or Monthly retainer|1500)', 'phemightforms' ); ?></span>
											</div>
										</div>
									</div>
								</div>
							<?php endif; ?>

							<div class="phf-invoice-actions">
								<div class="phf-invoice-actions-note">
									<span class="dashicons dashicons-visibility"></span>
									<?php esc_html_e( 'Preview updates live on the right as you type.', 'phemightforms' ); ?>
								</div>
								<div style="display:flex;gap:10px;flex-wrap:wrap;">
									<a href="<?php echo esc_url( $base ); ?>" class="phf-btn phf-btn-ghost"><?php esc_html_e( 'Cancel', 'phemightforms' ); ?></a>
									<button type="submit" class="phf-btn phf-btn-primary phf-btn-lg">
										<span class="dashicons dashicons-<?php echo $is_edit ? 'saved' : 'admin-links'; ?>"></span>
										<?php echo $is_edit ? esc_html__( 'Save Changes', 'phemightforms' ) : esc_html__( 'Create & Get Link', 'phemightforms' ); ?>
									</button>
								</div>
							</div>
						</div>

						<aside class="phf-invoice-preview-panel">
							<div class="phf-invoice-preview-label">
								<h4><?php esc_html_e( 'Customer Preview', 'phemightforms' ); ?></h4>
								<span><?php esc_html_e( 'Live', 'phemightforms' ); ?></span>
							</div>
							<div class="phf-invoice-preview-card" id="phf-inv-preview">
								<span class="phf-pay-badge<?php echo $is_link ? ' phf-pay-badge-link' : ''; ?>" id="phf-prev-badge"><?php echo $is_link ? esc_html__( 'Payment Link', 'phemightforms' ) : esc_html__( 'Invoice', 'phemightforms' ); ?></span>
								<h3 class="phf-invoice-preview-title" id="phf-prev-title"><?php echo esc_html( $item['title'] ?? ( $is_link ? __( 'Consultation fee', 'phemightforms' ) : __( 'Website design deposit', 'phemightforms' ) ) ); ?></h3>
								<p class="phf-invoice-preview-desc" id="phf-prev-desc"><?php echo esc_html( $item['description'] ?? __( 'Thank you for your business.', 'phemightforms' ) ); ?></p>

								<?php if ( ! $is_link ) : ?>
									<div class="phf-invoice-preview-meta" id="phf-prev-meta">
										<div id="phf-prev-billto" style="<?php echo empty( $item['customer_name'] ) ? 'display:none;' : ''; ?>">
											<span><?php esc_html_e( 'Bill to', 'phemightforms' ); ?></span>
											<strong><?php echo esc_html( $item['customer_name'] ?? '' ); ?></strong>
										</div>
										<div id="phf-prev-email" style="<?php echo empty( $item['customer_email'] ) ? 'display:none;' : ''; ?>">
											<span><?php esc_html_e( 'Email', 'phemightforms' ); ?></span>
											<strong><?php echo esc_html( $item['customer_email'] ?? '' ); ?></strong>
										</div>
										<div id="phf-prev-due" style="<?php echo empty( $item['due_date'] ) ? 'display:none;' : ''; ?>">
											<span><?php esc_html_e( 'Due date', 'phemightforms' ); ?></span>
											<strong><?php echo esc_html( $item['due_date'] ?? '' ); ?></strong>
										</div>
									</div>
									<div class="phf-invoice-preview-lines" id="phf-prev-lines"></div>
								<?php endif; ?>

								<div class="phf-invoice-preview-total">
									<span><?php esc_html_e( 'Total due', 'phemightforms' ); ?></span>
									<strong id="phf-prev-amount"><?php echo esc_html( Payments::format( $item['amount'] ?? 0 ) ); ?></strong>
								</div>
								<div class="phf-invoice-preview-method">
									<span class="dashicons dashicons-money-alt"></span>
									<span id="phf-prev-method"><?php echo esc_html( $method_preview ); ?></span>
								</div>
								<button type="button" class="phf-invoice-preview-btn" tabindex="-1"><?php esc_html_e( 'Pay Now', 'phemightforms' ); ?></button>
							</div>
						</aside>
					</div>
				</form>

				<?php ob_start(); ?>
				(function () {
					var currency = <?php echo wp_json_encode( $currency ); ?>;
					var isLink = <?php echo $is_link ? 'true' : 'false'; ?>;

					function formatAmount(val) {
						var n = parseFloat(val);
						if (isNaN(n) || n <= 0) { return currency + '0.00'; }
						return currency + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					}

					function parseLines(text) {
						if (!text) { return ''; }
						var html = '';
						text.split(/\r\n|\r|\n/).forEach(function (line) {
							line = line.trim();
							if (!line) { return; }
							var parts = line.split('|');
							var label = parts[0].trim();
							var price = parts[1] ? parts[1].trim() : '';
							html += '<div class="phf-invoice-preview-line"><span>' + label + '</span>' + (price ? '<strong>' + currency + parseFloat(price).toFixed(2) + '</strong>' : '') + '</div>';
						});
						return html;
					}

					function updateMethodPreview() {
						var allBox = document.getElementById( 'phf-methods-all' );
						var checks = document.querySelectorAll( '#phf-methods-grid input[type="checkbox"]' );
						var count = 0;
						var single = '';

						if ( allBox && allBox.checked ) {
							count = checks.length;
						} else {
							checks.forEach( function ( box ) {
								if ( box.checked ) {
									count++;
									single = box.getAttribute( 'data-method-label' );
								}
							} );
						}

						var el = document.getElementById( 'phf-prev-method' );
						if ( ! el ) { return; }

						if ( count > 1 ) {
							el.textContent = '<?php echo esc_js( __( 'Customer chooses from', 'phemightforms' ) ); ?> ' + count + ' <?php echo esc_js( __( 'payment options', 'phemightforms' ) ); ?>';
						} else if ( single ) {
							el.textContent = single;
						} else if ( checks.length ) {
							el.textContent = checks[0].getAttribute( 'data-method-label' );
						}
					}

					function syncMethodGrid() {
						var allBox = document.getElementById( 'phf-methods-all' );
						var grid = document.getElementById( 'phf-methods-grid' );
						if ( ! allBox || ! grid ) { return; }
						grid.querySelectorAll( 'input[type="checkbox"]' ).forEach( function ( box ) {
							box.disabled = allBox.checked;
							if ( allBox.checked ) {
								box.checked = true;
							}
						} );
						updateMethodPreview();
					}

					function updatePreview() {
						var title = document.getElementById('phf-inv-title');
						var desc = document.getElementById('phf-inv-desc');
						var amount = document.getElementById('phf-inv-amount');

						if (title) { document.getElementById('phf-prev-title').textContent = title.value || title.placeholder; }
						if (desc) {
							var descEl = document.getElementById('phf-prev-desc');
							descEl.textContent = desc.value || desc.placeholder;
							descEl.style.display = (desc.value || desc.placeholder) ? '' : 'none';
						}
						if (amount) { document.getElementById('phf-prev-amount').textContent = formatAmount(amount.value); }
						updateMethodPreview();

						if (!isLink) {
							var name = document.getElementById('phf-inv-name');
							var email = document.getElementById('phf-inv-email');
							var due = document.getElementById('phf-inv-due');
							var lines = document.getElementById('phf-inv-lines');

							var billRow = document.getElementById('phf-prev-billto');
							if (name && billRow) {
								billRow.style.display = name.value ? '' : 'none';
								billRow.querySelector('strong').textContent = name.value;
							}
							var emailRow = document.getElementById('phf-prev-email');
							if (email && emailRow) {
								emailRow.style.display = email.value ? '' : 'none';
								emailRow.querySelector('strong').textContent = email.value;
							}
							var dueRow = document.getElementById('phf-prev-due');
							if (due && dueRow) {
								dueRow.style.display = due.value ? '' : 'none';
								dueRow.querySelector('strong').textContent = due.value;
							}
							var linesEl = document.getElementById('phf-prev-lines');
							if (lines && linesEl) {
								var parsed = parseLines(lines.value);
								linesEl.innerHTML = parsed;
								linesEl.style.display = parsed ? '' : 'none';
							}
							var meta = document.getElementById('phf-prev-meta');
							if (meta) {
								var hasMeta = (name && name.value) || (email && email.value) || (due && due.value);
								meta.style.display = hasMeta ? '' : 'none';
							}
						}
					}

					document.getElementById('phf-invoice-form').addEventListener('input', updatePreview);
					document.getElementById('phf-invoice-form').addEventListener('change', function ( e ) {
						updatePreview();
						if ( e.target && ( e.target.id === 'phf-methods-all' || e.target.name === 'payment_methods[]' ) ) {
							if ( e.target.id === 'phf-methods-all' && e.target.checked ) {
								syncMethodGrid();
							} else if ( e.target.name === 'payment_methods[]' ) {
								var allBox = document.getElementById( 'phf-methods-all' );
								var total = document.querySelectorAll( '#phf-methods-grid input[type="checkbox"]' ).length;
								var checked = document.querySelectorAll( '#phf-methods-grid input[type="checkbox"]:checked' ).length;
								if ( allBox && checked < total ) {
									allBox.checked = false;
								}
								updateMethodPreview();
							}
						}
					});

					var allBox = document.getElementById( 'phf-methods-all' );
					if ( allBox ) {
						allBox.addEventListener( 'change', syncMethodGrid );
						syncMethodGrid();
					} else {
						updatePreview();
					}

					document.querySelectorAll('.phf-copy-btn').forEach(function (btn) {
						btn.addEventListener('click', function () {
							var input = document.getElementById(btn.getAttribute('data-target'));
							if (!input) { return; }
							input.select();
							input.setSelectionRange(0, 99999);
							navigator.clipboard.writeText(input.value).then(function () {
								var original = btn.innerHTML;
								btn.innerHTML = '<span class="dashicons dashicons-yes"></span> <?php echo esc_js( __( 'Copied', 'phemightforms' ) ); ?>';
								setTimeout(function () { btn.innerHTML = original; }, 1500);
							});
						});
					});
				})();
				<?php wp_add_inline_script( 'phemightforms-admin', ob_get_clean() ); ?>
			</div>
		</div>
		<?php
	}
}
