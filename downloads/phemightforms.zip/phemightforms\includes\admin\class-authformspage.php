<?php
/**
 * Login & Registration admin screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\AuthForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Demo previews, shortcode settings, and docs for auth forms.
 */
class AuthFormsPage {

	/**
	 * Register settings save handler.
	 */
	public function __construct() {
		add_action( 'admin_post_phemightforms_save_auth', [ $this, 'handle_save' ] );
	}

	/**
	 * Save auth shortcode toggles.
	 */
	public function handle_save() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_save_auth' );

		AuthForms::save_settings(
			[
				'login_enabled'    => ! empty( $_POST['login_enabled'] ),
				'register_enabled' => ! empty( $_POST['register_enabled'] ),
			]
		);

		if ( ! empty( $_POST['create_starters'] ) ) {
			AuthForms::ensure_starter_forms();
		}

		wp_safe_redirect(
			add_query_arg(
				[
					'page'  => Admin::SLUG . '-auth-forms',
					'saved' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render the page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'auth-forms' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Login & Registration', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'WordPress login and registration forms for your site.', 'phemightforms' ); ?></p>
					</div>
				</div>

				<?php self::render_content(); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Page content: demos, settings, docs.
	 */
	private static function render_content() {
		$settings = AuthForms::settings();
		$starters = [
			'login'    => (int) get_option( 'phemightforms_auth_login_form', 0 ),
			'register' => (int) get_option( 'phemightforms_auth_register_form', 0 ),
		];
		$saved = isset( $_GET['saved'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<?php if ( $saved ) : ?>
			<div class="phf-notice phf-notice-success">
				<span class="dashicons dashicons-yes-alt"></span>
				<?php esc_html_e( 'Settings saved.', 'phemightforms' ); ?>
			</div>
		<?php endif; ?>

		<div class="phf-auth-demos">
			<div class="phf-panel-head" style="margin-bottom:12px;">
				<h3><?php esc_html_e( 'Live preview', 'phemightforms' ); ?></h3>
				<span class="phf-muted"><?php esc_html_e( 'Styled demo panels (not connected to WordPress until you enable the shortcodes).', 'phemightforms' ); ?></span>
			</div>
			<div class="phf-auth-demo-grid">
				<div class="phf-auth-demo-panel">
					<h4><?php esc_html_e( 'Login form', 'phemightforms' ); ?></h4>
					<div class="phf-auth-demo-card">
						<label><?php esc_html_e( 'Username or email', 'phemightforms' ); ?></label>
						<input type="text" disabled placeholder="<?php esc_attr_e( 'you@example.com', 'phemightforms' ); ?>">
						<label><?php esc_html_e( 'Password', 'phemightforms' ); ?></label>
						<input type="password" disabled placeholder="••••••••">
						<button type="button" class="phf-btn phf-btn-primary" disabled><?php esc_html_e( 'Log in', 'phemightforms' ); ?></button>
					</div>
				</div>
				<div class="phf-auth-demo-panel">
					<h4><?php esc_html_e( 'Registration form', 'phemightforms' ); ?></h4>
					<div class="phf-auth-demo-card">
						<label><?php esc_html_e( 'Username', 'phemightforms' ); ?></label>
						<input type="text" disabled placeholder="<?php esc_attr_e( 'jane', 'phemightforms' ); ?>">
						<label><?php esc_html_e( 'Email', 'phemightforms' ); ?></label>
						<input type="email" disabled placeholder="<?php esc_attr_e( 'jane@example.com', 'phemightforms' ); ?>">
						<label><?php esc_html_e( 'Password', 'phemightforms' ); ?></label>
						<input type="password" disabled placeholder="••••••••">
						<button type="button" class="phf-btn phf-btn-primary" disabled><?php esc_html_e( 'Register', 'phemightforms' ); ?></button>
					</div>
				</div>
			</div>
		</div>

		<div class="phf-card-panel phf-settings-card" style="margin-top:20px;">
			<div class="phf-panel-head">
				<h3><span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e( 'Settings', 'phemightforms' ); ?></h3>
			</div>
			<div class="phf-card-body">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="phemightforms_save_auth">
					<?php wp_nonce_field( 'phemightforms_save_auth' ); ?>
					<div class="phf-field-row">
						<label class="phf-checkbox">
							<input type="checkbox" name="login_enabled" value="1" <?php checked( ! empty( $settings['login_enabled'] ) ); ?>>
							<?php esc_html_e( 'Enable login shortcode [phemightforms_login]', 'phemightforms' ); ?>
						</label>
					</div>
					<div class="phf-field-row">
						<label class="phf-checkbox">
							<input type="checkbox" name="register_enabled" value="1" <?php checked( ! empty( $settings['register_enabled'] ) ); ?>>
							<?php esc_html_e( 'Enable registration shortcode [phemightforms_register]', 'phemightforms' ); ?>
						</label>
					</div>
					<div class="phf-field-row">
						<label class="phf-checkbox">
							<input type="checkbox" name="create_starters" value="1">
							<?php esc_html_e( 'Create starter Login & Registration form posts (if missing)', 'phemightforms' ); ?>
						</label>
					</div>
					<?php if ( $starters['login'] || $starters['register'] ) : ?>
						<p class="phf-muted">
							<?php
							printf(
								/* translators: 1: login form ID, 2: register form ID */
								esc_html__( 'Starter form IDs — Login: %1$s, Register: %2$s', 'phemightforms' ),
								$starters['login'] ? (string) (int) $starters['login'] : '—',
								$starters['register'] ? (string) (int) $starters['register'] : '—'
							);
							?>
						</p>
					<?php endif; ?>
					<button type="submit" class="phf-btn phf-btn-primary"><?php esc_html_e( 'Save settings', 'phemightforms' ); ?></button>
				</form>
			</div>
		</div>

		<div class="phf-card-panel phf-settings-card" style="margin-top:20px;">
			<div class="phf-panel-head">
				<h3><span class="dashicons dashicons-editor-code"></span> <?php esc_html_e( 'Shortcode docs', 'phemightforms' ); ?></h3>
			</div>
			<div class="phf-card-body">
				<p><?php esc_html_e( 'Place these shortcodes on any page or post. They only work while the matching toggle above is enabled.', 'phemightforms' ); ?></p>
				<pre class="phf-code-sample">[phemightforms_login]
[phemightforms_register]</pre>
				<p class="phf-muted"><?php esc_html_e( 'Registration also requires “Anyone can register” under Settings → General in WordPress.', 'phemightforms' ); ?></p>
			</div>
		</div>
		<?php
	}
}
