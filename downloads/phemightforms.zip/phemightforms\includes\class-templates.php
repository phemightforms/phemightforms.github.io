<?php
/**
 * Pre-built form templates.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides ready-to-import form configurations, organised by category.
 */
class Templates {

	/**
	 * Template categories keyed by slug.
	 *
	 * @return array<string,string>
	 */
	public static function categories() {
		return [
			'business'     => __( 'Business Operations', 'phemightforms' ),
			'customer'     => __( 'Customer Service', 'phemightforms' ),
			'education'    => __( 'Education', 'phemightforms' ),
			'entertainment' => __( 'Entertainment', 'phemightforms' ),
			'events'       => __( 'Event Planning', 'phemightforms' ),
			'feedback'     => __( 'Feedback', 'phemightforms' ),
			'health'       => __( 'Health & Wellness', 'phemightforms' ),
			'marketing'    => __( 'Marketing', 'phemightforms' ),
			'nonprofit'    => __( 'Nonprofit', 'phemightforms' ),
			'payment'      => __( 'Payments & Orders', 'phemightforms' ),
			'quizzes'      => __( 'Quizzes', 'phemightforms' ),
			'registration' => __( 'Registrations', 'phemightforms' ),
		];
	}

	/**
	 * Return all templates keyed by slug.
	 *
	 * Each template is [ 'name', 'description', 'icon', 'category', 'fields' ].
	 *
	 * @return array
	 */
	public static function all() {
		$name    = static function ( $required = 1 ) {
			return [ 'type' => 'name', 'label' => 'Name', 'required' => $required ];
		};
		$email   = static function ( $required = 1 ) {
			return [ 'type' => 'email', 'label' => 'Email', 'required' => $required ];
		};
		$phone   = static function ( $required = 0 ) {
			return [ 'type' => 'phone', 'label' => 'Phone', 'required' => $required ];
		};
		$message = static function ( $label = 'Message', $required = 1 ) {
			return [ 'type' => 'textarea', 'label' => $label, 'required' => $required ];
		};

		$templates = [
			'blank' => [
				'name'        => __( 'Blank Form', 'phemightforms' ),
				'description' => __( 'Start from scratch and build any type of form with the drag & drop builder.', 'phemightforms' ),
				'icon'        => 'dashicons-plus-alt',
				'category'    => 'business',
				'fields'      => [],
			],

			/* ----------------------------- Business ----------------------------- */

			'contact' => [
				'name'        => __( 'Simple Contact Form', 'phemightforms' ),
				'description' => __( 'Collect names, emails, and messages from visitors who need to talk to you.', 'phemightforms' ),
				'icon'        => 'dashicons-email-alt',
				'category'    => 'business',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'text', 'label' => 'Subject' ],
					$message(),
				],
			],
			'demo-request' => [
				'name'        => __( 'Demo Request Form', 'phemightforms' ),
				'description' => __( 'Allow website visitors to request a product demo straight from your site.', 'phemightforms' ),
				'icon'        => 'dashicons-desktop',
				'category'    => 'business',
				'fields'      => [
					$name(), $email( 1 ),
					[ 'type' => 'text', 'label' => 'Company', 'required' => 1 ],
					[ 'type' => 'select', 'label' => 'Company Size', 'choices' => [ '1-10', '11-50', '51-200', '200+' ] ],
					[ 'type' => 'date', 'label' => 'Preferred Date' ],
					$message( 'What would you like to see?', 0 ),
				],
			],
			'job-application' => [
				'name'        => __( 'Job Application Form', 'phemightforms' ),
				'description' => __( 'Collect applications with a resume upload and screening questions.', 'phemightforms' ),
				'icon'        => 'dashicons-businessman',
				'category'    => 'business',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'text', 'label' => 'Position Applied For', 'required' => 1 ],
					[ 'type' => 'file', 'label' => 'Resume / CV', 'required' => 1 ],
					[ 'type' => 'url', 'label' => 'LinkedIn or Portfolio' ],
					$message( 'Cover Letter', 0 ),
				],
			],
			'quote-request' => [
				'name'        => __( 'Request a Quote Form', 'phemightforms' ),
				'description' => __( 'Let prospects describe their project and request pricing.', 'phemightforms' ),
				'icon'        => 'dashicons-media-spreadsheet',
				'category'    => 'business',
				'fields'      => [
					$name(), $email(), $phone(),
					[ 'type' => 'select', 'label' => 'Service Needed', 'required' => 1, 'choices' => [ 'Design', 'Development', 'Marketing', 'Consulting', 'Other' ] ],
					[ 'type' => 'select', 'label' => 'Budget Range', 'choices' => [ 'Under $500', '$500 to $2,000', '$2,000 to $10,000', '$10,000+' ] ],
					$message( 'Project Details' ),
				],
			],
			'appointment' => [
				'name'        => __( 'Appointment Booking Form', 'phemightforms' ),
				'description' => __( 'Let clients pick a date and time that works for them.', 'phemightforms' ),
				'icon'        => 'dashicons-calendar',
				'category'    => 'business',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'date', 'label' => 'Preferred Date', 'required' => 1 ],
					[ 'type' => 'time', 'label' => 'Preferred Time', 'required' => 1 ],
					$message( 'Notes', 0 ),
				],
			],
			'vehicle-info' => [
				'name'        => __( 'Automobile Information Form', 'phemightforms' ),
				'description' => __( 'Gather vehicle details for insurance, repairs, or services.', 'phemightforms' ),
				'icon'        => 'dashicons-car',
				'category'    => 'business',
				'fields'      => [
					$name(), $email(), $phone(),
					[ 'type' => 'text', 'label' => 'Vehicle Make & Model', 'required' => 1 ],
					[ 'type' => 'number', 'label' => 'Year', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'License Plate' ],
					$message( 'Describe the issue or request', 0 ),
				],
			],
			'eviction-notice' => [
				'name'        => __( 'Eviction Notice Form', 'phemightforms' ),
				'description' => __( 'Create a notification of eviction for both landlord and tenant.', 'phemightforms' ),
				'icon'        => 'dashicons-admin-multisite',
				'category'    => 'business',
				'fields'      => [
					[ 'type' => 'name', 'label' => 'Tenant Name', 'required' => 1 ],
					[ 'type' => 'address', 'label' => 'Property Address', 'required' => 1 ],
					[ 'type' => 'date', 'label' => 'Notice Date', 'required' => 1 ],
					[ 'type' => 'date', 'label' => 'Vacate By', 'required' => 1 ],
					$message( 'Reason for Notice' ),
					[ 'type' => 'signature', 'label' => 'Landlord Signature', 'required' => 1 ],
				],
			],
			'packing-list' => [
				'name'        => __( 'Packing List Form', 'phemightforms' ),
				'description' => __( 'Track shipments and packed items directly from your website.', 'phemightforms' ),
				'icon'        => 'dashicons-archive',
				'category'    => 'business',
				'fields'      => [
					[ 'type' => 'text', 'label' => 'Order Number', 'required' => 1 ],
					$name(),
					[ 'type' => 'address', 'label' => 'Shipping Address', 'required' => 1 ],
					[ 'type' => 'repeater', 'label' => 'Items', 'sub_label' => 'Item and quantity' ],
					$message( 'Special Instructions', 0 ),
				],
			],

			/* ----------------------------- Customer Service ----------------------------- */

			'support-ticket' => [
				'name'        => __( 'Support Ticket Form', 'phemightforms' ),
				'description' => __( 'Collect support requests with priority and details.', 'phemightforms' ),
				'icon'        => 'dashicons-sos',
				'category'    => 'customer',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'select', 'label' => 'Priority', 'required' => 1, 'choices' => [ 'Low', 'Normal', 'High', 'Urgent' ] ],
					[ 'type' => 'text', 'label' => 'Subject', 'required' => 1 ],
					$message( 'Describe the problem' ),
					[ 'type' => 'file', 'label' => 'Attachment / Screenshot' ],
				],
			],
			'feature-request' => [
				'name'        => __( 'Feature Request Form', 'phemightforms' ),
				'description' => __( 'Let your users easily submit feature requests for your products.', 'phemightforms' ),
				'icon'        => 'dashicons-lightbulb',
				'category'    => 'customer',
				'fields'      => [
					$email( 0 ),
					[ 'type' => 'text', 'label' => 'Feature Title', 'required' => 1 ],
					$message( 'Describe the feature and why it helps' ),
					[ 'type' => 'radio', 'label' => 'How important is this to you?', 'choices' => [ 'Nice to have', 'Important', 'Critical' ] ],
				],
			],
			'complaint' => [
				'name'        => __( 'Customer Complaint Form', 'phemightforms' ),
				'description' => __( 'Give customers a clear channel to report problems so you can fix them.', 'phemightforms' ),
				'icon'        => 'dashicons-megaphone',
				'category'    => 'customer',
				'fields'      => [
					$name(), $email(), $phone(),
					[ 'type' => 'date', 'label' => 'Date of Incident' ],
					[ 'type' => 'select', 'label' => 'Complaint Type', 'choices' => [ 'Product', 'Service', 'Billing', 'Staff', 'Other' ] ],
					$message( 'Describe your complaint' ),
				],
			],
			'cancellation' => [
				'name'        => __( 'Cancellation Request Form', 'phemightforms' ),
				'description' => __( 'Process cancellations gracefully and learn why customers leave.', 'phemightforms' ),
				'icon'        => 'dashicons-dismiss',
				'category'    => 'customer',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'text', 'label' => 'Account / Order Number', 'required' => 1 ],
					[ 'type' => 'radio', 'label' => 'Reason for cancelling', 'choices' => [ 'Too expensive', 'Not using it', 'Missing features', 'Switching provider', 'Other' ] ],
					$message( 'Anything we could have done better?', 0 ),
				],
			],
			'terms-contact' => [
				'name'        => __( 'Terms of Service Contact Form', 'phemightforms' ),
				'description' => __( 'Ask your visitor to agree to your terms when they submit your contact form.', 'phemightforms' ),
				'icon'        => 'dashicons-media-text',
				'category'    => 'customer',
				'fields'      => [
					$name(), $email(), $message(),
					[ 'type' => 'consent', 'label' => 'Terms', 'required' => 1, 'consent_text' => 'I agree to the terms of service and privacy policy.' ],
				],
			],

			/* ----------------------------- Education ----------------------------- */

			'course-registration' => [
				'name'        => __( 'Course Registration Form', 'phemightforms' ),
				'description' => __( 'Enrol students in classes with schedule preferences.', 'phemightforms' ),
				'icon'        => 'dashicons-welcome-learn-more',
				'category'    => 'education',
				'fields'      => [
					$name(), $email(), $phone(),
					[ 'type' => 'select', 'label' => 'Course', 'required' => 1, 'choices' => [ 'Beginner', 'Intermediate', 'Advanced' ] ],
					[ 'type' => 'radio', 'label' => 'Preferred Schedule', 'choices' => [ 'Weekday mornings', 'Weekday evenings', 'Weekends' ] ],
				],
			],
			'lesson-plan' => [
				'name'        => __( 'Lesson Plan Form', 'phemightforms' ),
				'description' => __( 'Collect course objectives, goals, and materials to help deliver lessons.', 'phemightforms' ),
				'icon'        => 'dashicons-clipboard',
				'category'    => 'education',
				'fields'      => [
					[ 'type' => 'text', 'label' => 'Lesson Title', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'Subject / Grade Level', 'required' => 1 ],
					$message( 'Objectives' ),
					$message( 'Materials Needed', 0 ),
					$message( 'Lesson Outline' ),
				],
			],
			'lecture-notes' => [
				'name'        => __( 'Lecture Notes Form', 'phemightforms' ),
				'description' => __( 'Keep all your notes in one convenient place for efficient teaching.', 'phemightforms' ),
				'icon'        => 'dashicons-edit-page',
				'category'    => 'education',
				'fields'      => [
					[ 'type' => 'text', 'label' => 'Course', 'required' => 1 ],
					[ 'type' => 'date', 'label' => 'Lecture Date', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'Topic', 'required' => 1 ],
					$message( 'Key Points' ),
					$message( 'Questions to Follow Up', 0 ),
				],
			],
			'grade-book' => [
				'name'        => __( 'Grade Book Form', 'phemightforms' ),
				'description' => __( 'Collect student information and assignments in one location.', 'phemightforms' ),
				'icon'        => 'dashicons-book-alt',
				'category'    => 'education',
				'fields'      => [
					[ 'type' => 'name', 'label' => 'Student Name', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'Class / Section', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'Assignment', 'required' => 1 ],
					[ 'type' => 'number', 'label' => 'Score', 'required' => 1 ],
					$message( 'Comments', 0 ),
				],
			],
			'library-request' => [
				'name'        => __( 'Library Book Request Form', 'phemightforms' ),
				'description' => __( 'Let patrons request books for your library.', 'phemightforms' ),
				'icon'        => 'dashicons-book',
				'category'    => 'education',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'text', 'label' => 'Book Title', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'Author' ],
					[ 'type' => 'radio', 'label' => 'Format', 'choices' => [ 'Hardcover', 'Paperback', 'eBook', 'Audiobook' ] ],
				],
			],
			'advisor-meeting' => [
				'name'        => __( 'Academic Advisor Meeting Form', 'phemightforms' ),
				'description' => __( 'Let students book meetings with their academic advisors.', 'phemightforms' ),
				'icon'        => 'dashicons-groups',
				'category'    => 'education',
				'fields'      => [
					[ 'type' => 'name', 'label' => 'Student Name', 'required' => 1 ],
					$email(),
					[ 'type' => 'text', 'label' => 'Student ID', 'required' => 1 ],
					[ 'type' => 'date', 'label' => 'Preferred Date', 'required' => 1 ],
					[ 'type' => 'time', 'label' => 'Preferred Time', 'required' => 1 ],
					$message( 'What would you like to discuss?', 0 ),
				],
			],
			'cornell-notes' => [
				'name'        => __( 'Cornell Notes Form', 'phemightforms' ),
				'description' => __( 'Implement the Cornell note taking system on your website.', 'phemightforms' ),
				'icon'        => 'dashicons-welcome-write-blog',
				'category'    => 'education',
				'fields'      => [
					[ 'type' => 'text', 'label' => 'Topic', 'required' => 1 ],
					[ 'type' => 'date', 'label' => 'Date', 'required' => 1 ],
					$message( 'Cues / Questions' ),
					$message( 'Notes' ),
					$message( 'Summary' ),
				],
			],

			/* ----------------------------- Entertainment ----------------------------- */

			'dj-request' => [
				'name'        => __( 'DJ Song Request Form', 'phemightforms' ),
				'description' => __( 'Let guests request a specific song from the DJ for a more interactive event.', 'phemightforms' ),
				'icon'        => 'dashicons-format-audio',
				'category'    => 'entertainment',
				'fields'      => [
					[ 'type' => 'text', 'label' => 'Your Name' ],
					[ 'type' => 'text', 'label' => 'Song Title', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'Artist', 'required' => 1 ],
					[ 'type' => 'text', 'label' => 'Dedication (optional)' ],
				],
			],
			'secret-santa' => [
				'name'        => __( 'Secret Santa Signup Form', 'phemightforms' ),
				'description' => __( 'Get signups for your Secret Santa gift exchange.', 'phemightforms' ),
				'icon'        => 'dashicons-buddicons-community',
				'category'    => 'entertainment',
				'fields'      => [
					$name(), $email(),
					$message( 'Gift ideas / wishlist', 0 ),
					[ 'type' => 'text', 'label' => 'Things to avoid' ],
				],
			],
			'refer-friend' => [
				'name'        => __( 'Refer a Friend and Win Form', 'phemightforms' ),
				'description' => __( 'Encourage people to recommend friends in exchange for prizes.', 'phemightforms' ),
				'icon'        => 'dashicons-awards',
				'category'    => 'entertainment',
				'fields'      => [
					[ 'type' => 'name', 'label' => 'Your Name', 'required' => 1 ],
					[ 'type' => 'email', 'label' => 'Your Email', 'required' => 1 ],
					[ 'type' => 'name', 'label' => "Friend's Name", 'required' => 1 ],
					[ 'type' => 'email', 'label' => "Friend's Email", 'required' => 1 ],
				],
			],
			'significant-other' => [
				'name'        => __( 'Significant Other Application Form', 'phemightforms' ),
				'description' => __( 'A lighthearted application to screen potential partners.', 'phemightforms' ),
				'icon'        => 'dashicons-heart',
				'category'    => 'entertainment',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'number', 'label' => 'Age' ],
					[ 'type' => 'radio', 'label' => 'Cooking skills?', 'choices' => [ 'Chef level', 'Decent', 'Cereal only' ] ],
					[ 'type' => 'checkbox', 'label' => 'Interests', 'choices' => [ 'Movies', 'Travel', 'Sports', 'Gaming', 'Reading' ] ],
					$message( 'Why should you be considered?' ),
				],
			],
			'complaint-fun' => [
				'name'        => __( 'Significant Other Complaint Form', 'phemightforms' ),
				'description' => __( 'A cheeky, fun form to air lighthearted grievances.', 'phemightforms' ),
				'icon'        => 'dashicons-format-chat',
				'category'    => 'entertainment',
				'fields'      => [
					[ 'type' => 'text', 'label' => 'Complainant Name', 'required' => 1 ],
					[ 'type' => 'select', 'label' => 'Severity', 'choices' => [ 'Mild annoyance', 'Moderate', 'Serious eye-roll', 'Code red' ] ],
					$message( 'Describe the offence' ),
					[ 'type' => 'radio', 'label' => 'Requested resolution', 'choices' => [ 'Apology', 'Dinner', 'Chores for a week', 'All of the above' ] ],
				],
			],

			/* ----------------------------- Event Planning ----------------------------- */

			'rsvp' => [
				'name'        => __( 'Party Invitation RSVP Form', 'phemightforms' ),
				'description' => __( 'Easily share party information and give guests the chance to RSVP.', 'phemightforms' ),
				'icon'        => 'dashicons-tickets-alt',
				'category'    => 'events',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'radio', 'label' => 'Will you attend?', 'required' => 1, 'choices' => [ 'Yes, count me in!', 'Sorry, can\'t make it' ] ],
					[ 'type' => 'number', 'label' => 'Number of Guests' ],
				],
			],
			'birthday-rsvp' => [
				'name'        => __( 'Birthday Party RSVP Form', 'phemightforms' ),
				'description' => __( 'Find out who is coming to your party and answer questions about the big day.', 'phemightforms' ),
				'icon'        => 'dashicons-buddicons-groups',
				'category'    => 'events',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'radio', 'label' => 'Attending?', 'required' => 1, 'choices' => [ 'Yes', 'No', 'Maybe' ] ],
					[ 'type' => 'number', 'label' => 'How many in your party?' ],
					[ 'type' => 'text', 'label' => 'Dietary restrictions' ],
				],
			],
			'potluck' => [
				'name'        => __( 'Potluck Invitation RSVP Form', 'phemightforms' ),
				'description' => __( 'Find out who will attend your party and what they plan to bring.', 'phemightforms' ),
				'icon'        => 'dashicons-food',
				'category'    => 'events',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'radio', 'label' => 'Will you attend?', 'required' => 1, 'choices' => [ 'Yes', 'No' ] ],
					[ 'type' => 'select', 'label' => 'What will you bring?', 'choices' => [ 'Appetizer', 'Main dish', 'Side dish', 'Dessert', 'Drinks' ] ],
					[ 'type' => 'text', 'label' => 'Dish name' ],
				],
			],
			'meeting-room' => [
				'name'        => __( 'Meeting Room Registration Form', 'phemightforms' ),
				'description' => __( 'Simplify the process of reserving meeting rooms.', 'phemightforms' ),
				'icon'        => 'dashicons-building',
				'category'    => 'events',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'select', 'label' => 'Room', 'required' => 1, 'choices' => [ 'Boardroom', 'Conference Room A', 'Conference Room B', 'Huddle Space' ] ],
					[ 'type' => 'date', 'label' => 'Date', 'required' => 1 ],
					[ 'type' => 'time', 'label' => 'Start Time', 'required' => 1 ],
					[ 'type' => 'time', 'label' => 'End Time', 'required' => 1 ],
					[ 'type' => 'number', 'label' => 'Attendees' ],
				],
			],
			'wedding-rsvp' => [
				'name'        => __( 'Wedding RSVP Form', 'phemightforms' ),
				'description' => __( 'Collect wedding attendance, meal choices, and song requests.', 'phemightforms' ),
				'icon'        => 'dashicons-heart',
				'category'    => 'events',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'radio', 'label' => 'Will you celebrate with us?', 'required' => 1, 'choices' => [ 'Joyfully accept', 'Regretfully decline' ] ],
					[ 'type' => 'select', 'label' => 'Meal Preference', 'choices' => [ 'Chicken', 'Beef', 'Fish', 'Vegetarian' ] ],
					[ 'type' => 'text', 'label' => 'Song request' ],
				],
			],
			'new-years-rsvp' => [
				'name'        => __( 'New Years Party RSVP Form', 'phemightforms' ),
				'description' => __( 'Share event information and find out who wants to come and who they will bring.', 'phemightforms' ),
				'icon'        => 'dashicons-star-filled',
				'category'    => 'events',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'radio', 'label' => 'Attending?', 'required' => 1, 'choices' => [ 'Yes', 'No' ] ],
					[ 'type' => 'text', 'label' => 'Who are you bringing?' ],
					[ 'type' => 'checkbox', 'label' => 'What can you bring?', 'choices' => [ 'Snacks', 'Drinks', 'Games', 'Fireworks (legal ones!)' ] ],
				],
			],

			/* ----------------------------- Feedback ----------------------------- */

			'feedback' => [
				'name'        => __( 'Feedback / Suggestion Form', 'phemightforms' ),
				'description' => __( 'Collect ratings and open feedback from visitors.', 'phemightforms' ),
				'icon'        => 'dashicons-format-status',
				'category'    => 'feedback',
				'fields'      => [
					$email( 0 ),
					[ 'type' => 'rating', 'label' => 'How would you rate us?', 'required' => 1 ],
					$message( 'Your feedback' ),
				],
			],
			'survey' => [
				'name'        => __( 'Customer Survey Form', 'phemightforms' ),
				'description' => __( 'Multiple choice questions with aggregated results reporting.', 'phemightforms' ),
				'icon'        => 'dashicons-chart-bar',
				'category'    => 'feedback',
				'fields'      => [
					[ 'type' => 'radio', 'label' => 'How did you hear about us?', 'required' => 1, 'choices' => [ 'Search engine', 'Social media', 'Friend', 'Other' ] ],
					[ 'type' => 'radio', 'label' => 'How satisfied are you?', 'required' => 1, 'choices' => [ 'Very satisfied', 'Satisfied', 'Neutral', 'Dissatisfied' ] ],
					[ 'type' => 'checkbox', 'label' => 'Which features do you use?', 'choices' => [ 'Forms', 'Reports', 'Notifications' ] ],
					$message( 'Any other comments?', 0 ),
				],
			],
			'nps' => [
				'name'        => __( 'NPS Survey Form', 'phemightforms' ),
				'description' => __( 'Measure loyalty with the classic "how likely are you to recommend us" survey.', 'phemightforms' ),
				'icon'        => 'dashicons-chart-line',
				'category'    => 'feedback',
				'fields'      => [
					[ 'type' => 'select', 'label' => 'How likely are you to recommend us? (0-10)', 'required' => 1, 'choices' => [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10' ] ],
					$message( 'What is the main reason for your score?', 0 ),
				],
			],
			'website-feedback' => [
				'name'        => __( 'Website Feedback Form', 'phemightforms' ),
				'description' => __( 'Find out what visitors think about your website and what to improve.', 'phemightforms' ),
				'icon'        => 'dashicons-admin-site-alt3',
				'category'    => 'feedback',
				'fields'      => [
					[ 'type' => 'rating', 'label' => 'Overall experience', 'required' => 1 ],
					[ 'type' => 'radio', 'label' => 'Did you find what you were looking for?', 'choices' => [ 'Yes', 'Partially', 'No' ] ],
					$message( 'What can we improve?', 0 ),
				],
			],

			/* ----------------------------- Health & Wellness ----------------------------- */

			'facial-consult' => [
				'name'        => __( 'Facial Consultation Form', 'phemightforms' ),
				'description' => __( 'Prepare for a facial consultation with your clients, directly from your website.', 'phemightforms' ),
				'icon'        => 'dashicons-smiley',
				'category'    => 'health',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'radio', 'label' => 'Skin type', 'choices' => [ 'Dry', 'Oily', 'Combination', 'Sensitive', 'Normal' ] ],
					[ 'type' => 'checkbox', 'label' => 'Skin concerns', 'choices' => [ 'Acne', 'Aging', 'Pigmentation', 'Redness', 'Dullness' ] ],
					$message( 'Current skincare routine', 0 ),
				],
			],
			'hair-consult' => [
				'name'        => __( 'Hair Extension Consultation Form', 'phemightforms' ),
				'description' => __( 'Gather information from clients to prepare for a consultation.', 'phemightforms' ),
				'icon'        => 'dashicons-admin-appearance',
				'category'    => 'health',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'radio', 'label' => 'Desired length', 'choices' => [ 'Shoulder', 'Mid-back', 'Waist' ] ],
					[ 'type' => 'file', 'label' => 'Photo of current hair' ],
					[ 'type' => 'date', 'label' => 'Preferred appointment date' ],
				],
			],
			'patient-intake' => [
				'name'        => __( 'Patient Intake Form', 'phemightforms' ),
				'description' => __( 'Collect new patient details and medical history before the first visit.', 'phemightforms' ),
				'icon'        => 'dashicons-plus-alt',
				'category'    => 'health',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'date', 'label' => 'Date of Birth', 'required' => 1 ],
					[ 'type' => 'address', 'label' => 'Address' ],
					$message( 'Current medications', 0 ),
					$message( 'Allergies', 0 ),
					[ 'type' => 'consent', 'label' => 'Consent', 'required' => 1, 'consent_text' => 'I confirm the information provided is accurate.' ],
				],
			],
			'class-booking' => [
				'name'        => __( 'Fitness Class Booking Form', 'phemightforms' ),
				'description' => __( 'Let members book yoga, spin, or gym classes online.', 'phemightforms' ),
				'icon'        => 'dashicons-universal-access',
				'category'    => 'health',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'select', 'label' => 'Class', 'required' => 1, 'choices' => [ 'Yoga', 'Pilates', 'Spin', 'HIIT', 'Strength' ] ],
					[ 'type' => 'date', 'label' => 'Date', 'required' => 1 ],
					[ 'type' => 'radio', 'label' => 'Experience level', 'choices' => [ 'Beginner', 'Intermediate', 'Advanced' ] ],
				],
			],

			/* ----------------------------- Marketing ----------------------------- */

			'newsletter' => [
				'name'        => __( 'Newsletter Signup Form', 'phemightforms' ),
				'description' => __( 'Collect email addresses and add visitors to your newsletter.', 'phemightforms' ),
				'icon'        => 'dashicons-email',
				'category'    => 'marketing',
				'fields'      => [
					[ 'type' => 'name', 'label' => 'Name' ],
					$email(),
					[ 'type' => 'consent', 'label' => 'Consent', 'required' => 1, 'consent_text' => 'I agree to receive email updates and newsletters.' ],
				],
			],
			'lead-magnet' => [
				'name'        => __( 'Lead Magnet Download Form', 'phemightforms' ),
				'description' => __( 'Offer an instant download when your visitor submits this form.', 'phemightforms' ),
				'icon'        => 'dashicons-download',
				'category'    => 'marketing',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'text', 'label' => 'Company' ],
					[ 'type' => 'consent', 'label' => 'Consent', 'consent_text' => 'Send me occasional marketing emails. Unsubscribe anytime.' ],
				],
			],
			'gdpr-contact' => [
				'name'        => __( 'GDPR Contact Form', 'phemightforms' ),
				'description' => __( 'Publish a contact form with a GDPR checkbox to stay compliant.', 'phemightforms' ),
				'icon'        => 'dashicons-privacy',
				'category'    => 'marketing',
				'fields'      => [
					$name(), $email(), $message(),
					[ 'type' => 'consent', 'label' => 'GDPR Agreement', 'required' => 1, 'consent_text' => 'I consent to having this website store my submitted information so they can respond to my inquiry.' ],
				],
			],
			'optin' => [
				'name'        => __( 'Opt In Form', 'phemightforms' ),
				'description' => __( 'Ask visitors for their email address and convert them into loyal subscribers.', 'phemightforms' ),
				'icon'        => 'dashicons-yes-alt',
				'category'    => 'marketing',
				'fields'      => [
					$email(),
					[ 'type' => 'radio', 'label' => 'How often do you want to hear from us?', 'choices' => [ 'Weekly', 'Monthly', 'Big news only' ] ],
				],
			],
			'country-contact' => [
				'name'        => __( 'Country Dropdown Contact Form', 'phemightforms' ),
				'description' => __( 'Contact form with a country dropdown so visitors can pick their location.', 'phemightforms' ),
				'icon'        => 'dashicons-admin-site',
				'category'    => 'marketing',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'country', 'label' => 'Country', 'required' => 1 ],
					$message(),
				],
			],

			/* ----------------------------- Nonprofit ----------------------------- */

			'volunteer' => [
				'name'        => __( 'Volunteer Application Form', 'phemightforms' ),
				'description' => __( 'Recruit volunteers with availability and skills information.', 'phemightforms' ),
				'icon'        => 'dashicons-groups',
				'category'    => 'nonprofit',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'checkbox', 'label' => 'Availability', 'choices' => [ 'Weekday mornings', 'Weekday evenings', 'Weekends' ] ],
					[ 'type' => 'checkbox', 'label' => 'Areas of interest', 'choices' => [ 'Events', 'Fundraising', 'Admin', 'Outreach' ] ],
					$message( 'Why do you want to volunteer?', 0 ),
				],
			],
			'community-service' => [
				'name'        => __( 'Community Service Form', 'phemightforms' ),
				'description' => __( 'Track volunteers\' service requirement activities.', 'phemightforms' ),
				'icon'        => 'dashicons-clock',
				'category'    => 'nonprofit',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'text', 'label' => 'Organization', 'required' => 1 ],
					[ 'type' => 'date', 'label' => 'Service Date', 'required' => 1 ],
					[ 'type' => 'number', 'label' => 'Hours Completed', 'required' => 1 ],
					$message( 'Describe the activity' ),
					[ 'type' => 'signature', 'label' => 'Supervisor Signature' ],
				],
			],
			'stall-application' => [
				'name'        => __( 'Stall Holder Application Form', 'phemightforms' ),
				'description' => __( 'Allow local businesses to apply to run a stall at your event.', 'phemightforms' ),
				'icon'        => 'dashicons-store',
				'category'    => 'nonprofit',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'text', 'label' => 'Business Name', 'required' => 1 ],
					[ 'type' => 'select', 'label' => 'Stall Type', 'choices' => [ 'Food & drink', 'Crafts', 'Clothing', 'Services', 'Other' ] ],
					$message( 'What will you be selling?' ),
				],
			],

			/* ----------------------------- Payments & Orders ----------------------------- */

			'order-form' => [
				'name'        => __( 'Customer Order Form', 'phemightforms' ),
				'description' => __( 'Collect customer info, product choices, and payment to process orders quickly.', 'phemightforms' ),
				'icon'        => 'dashicons-cart',
				'category'    => 'payment',
				'fields'      => [
					$name(), $email(), $phone(),
					[ 'type' => 'payment_multiple', 'label' => 'Choose your item', 'required' => 1, 'choices' => [ 'Small|10', 'Medium|15', 'Large|20' ] ],
					[ 'type' => 'payment_quantity', 'label' => 'Quantity' ],
					[ 'type' => 'payment_coupon', 'label' => 'Coupon Code' ],
					[ 'type' => 'payment_total', 'label' => 'Total' ],
				],
			],
			'stripe-payment' => [
				'name'        => __( 'Product Payment Form', 'phemightforms' ),
				'description' => __( 'Let your visitor pick an item and instantly pay for it online.', 'phemightforms' ),
				'icon'        => 'dashicons-money-alt',
				'category'    => 'payment',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'payment_select', 'label' => 'Select a product', 'required' => 1, 'choices' => [ 'Starter Package|49', 'Pro Package|99', 'Agency Package|199' ] ],
					[ 'type' => 'payment_total', 'label' => 'Total' ],
				],
			],
			'donation' => [
				'name'        => __( 'Variable Donation Form', 'phemightforms' ),
				'description' => __( 'Let your donor choose their own donation amount and pay online.', 'phemightforms' ),
				'icon'        => 'dashicons-heart',
				'category'    => 'payment',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'payment_single', 'label' => 'Donation Amount', 'required' => 1, 'user_price' => 1, 'price' => '25' ],
					[ 'type' => 'payment_total', 'label' => 'Total' ],
					$message( 'Leave a message of support', 0 ),
				],
			],
			'buy-coffee' => [
				'name'        => __( 'Buy Me a Coffee Form', 'phemightforms' ),
				'description' => __( 'Ask visitors to buy you a coffee with a customizable amount.', 'phemightforms' ),
				'icon'        => 'dashicons-coffee',
				'category'    => 'payment',
				'fields'      => [
					[ 'type' => 'text', 'label' => 'Your Name' ],
					[ 'type' => 'payment_multiple', 'label' => 'Coffee size', 'required' => 1, 'choices' => [ 'One coffee|5', 'Two coffees|10', 'Coffee for the week|25' ] ],
					[ 'type' => 'payment_total', 'label' => 'Total' ],
					[ 'type' => 'text', 'label' => 'Say something nice' ],
				],
			],
			'lemonade-order' => [
				'name'        => __( 'Lemonade Stand Order Form', 'phemightforms' ),
				'description' => __( 'Let people order ahead so they can pick up their lemonade.', 'phemightforms' ),
				'icon'        => 'dashicons-carrot',
				'category'    => 'payment',
				'fields'      => [
					$name(),
					[ 'type' => 'payment_multiple', 'label' => 'Drink', 'required' => 1, 'choices' => [ 'Classic Lemonade|3', 'Pink Lemonade|3.50', 'Iced Tea|3' ] ],
					[ 'type' => 'payment_quantity', 'label' => 'How many?' ],
					[ 'type' => 'time', 'label' => 'Pickup time' ],
					[ 'type' => 'payment_total', 'label' => 'Total' ],
				],
			],
			'event-ticket' => [
				'name'        => __( 'Event Ticket Payment Form', 'phemightforms' ),
				'description' => __( 'Sell event tickets with tiered pricing and coupons.', 'phemightforms' ),
				'icon'        => 'dashicons-tickets',
				'category'    => 'payment',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'payment_multiple', 'label' => 'Ticket Type', 'required' => 1, 'choices' => [ 'General Admission|25', 'VIP|75', 'Backstage|150' ] ],
					[ 'type' => 'payment_quantity', 'label' => 'Number of tickets' ],
					[ 'type' => 'payment_coupon', 'label' => 'Promo code' ],
					[ 'type' => 'payment_total', 'label' => 'Total' ],
				],
			],

			/* ----------------------------- Quizzes ----------------------------- */

			'quiz' => [
				'name'        => __( 'General Knowledge Quiz', 'phemightforms' ),
				'description' => __( 'Graded quiz with correct answers and a score on submission.', 'phemightforms' ),
				'icon'        => 'dashicons-welcome-learn-more',
				'category'    => 'quizzes',
				'is_quiz'     => 1,
				'fields'      => [
					[ 'type' => 'radio', 'label' => 'What is 2 + 2?', 'required' => 1, 'choices' => [ '3', '4', '5' ], 'correct' => '4' ],
					[ 'type' => 'radio', 'label' => 'Capital of France?', 'required' => 1, 'choices' => [ 'London', 'Paris', 'Berlin' ], 'correct' => 'Paris' ],
					[ 'type' => 'radio', 'label' => 'Largest planet?', 'required' => 1, 'choices' => [ 'Earth', 'Jupiter', 'Mars' ], 'correct' => 'Jupiter' ],
				],
			],
			'math-quiz' => [
				'name'        => __( 'Math Quiz', 'phemightforms' ),
				'description' => __( 'A quick arithmetic test with automatic scoring.', 'phemightforms' ),
				'icon'        => 'dashicons-calculator',
				'category'    => 'quizzes',
				'is_quiz'     => 1,
				'fields'      => [
					[ 'type' => 'radio', 'label' => '12 × 8 = ?', 'required' => 1, 'choices' => [ '84', '96', '108' ], 'correct' => '96' ],
					[ 'type' => 'radio', 'label' => '15% of 200 = ?', 'required' => 1, 'choices' => [ '20', '25', '30' ], 'correct' => '30' ],
					[ 'type' => 'radio', 'label' => '√144 = ?', 'required' => 1, 'choices' => [ '10', '12', '14' ], 'correct' => '12' ],
					[ 'type' => 'radio', 'label' => '7 + 6 × 2 = ?', 'required' => 1, 'choices' => [ '26', '19', '20' ], 'correct' => '19' ],
				],
			],
			'personality-quiz' => [
				'name'        => __( 'Personality Quiz', 'phemightforms' ),
				'description' => __( 'A fun, ungraded quiz to engage your audience.', 'phemightforms' ),
				'icon'        => 'dashicons-superhero',
				'category'    => 'quizzes',
				'fields'      => [
					[ 'type' => 'radio', 'label' => 'Your ideal weekend?', 'required' => 1, 'choices' => [ 'Adventure outdoors', 'Movie marathon', 'Time with friends', 'Learning something new' ] ],
					[ 'type' => 'radio', 'label' => 'Pick a drink', 'required' => 1, 'choices' => [ 'Coffee', 'Tea', 'Smoothie', 'Water' ] ],
					[ 'type' => 'radio', 'label' => 'Work style?', 'required' => 1, 'choices' => [ 'Planner', 'Improviser', 'Team player', 'Solo focus' ] ],
					$email( 0 ),
				],
			],

			/* ----------------------------- Registrations ----------------------------- */

			'registration' => [
				'name'        => __( 'Event Registration Form', 'phemightforms' ),
				'description' => __( 'Register attendees with contact and preference fields.', 'phemightforms' ),
				'icon'        => 'dashicons-calendar-alt',
				'category'    => 'registration',
				'fields'      => [
					$name(), $email(), $phone(),
					[ 'type' => 'select', 'label' => 'Ticket Type', 'required' => 1, 'choices' => [ 'General', 'VIP', 'Student' ] ],
					[ 'type' => 'number', 'label' => 'Number of Guests' ],
				],
			],
			'conference' => [
				'name'        => __( 'Conference Registration Form', 'phemightforms' ),
				'description' => __( 'Collect attendee information to plan and manage your next conference.', 'phemightforms' ),
				'icon'        => 'dashicons-nametag',
				'category'    => 'registration',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'text', 'label' => 'Company / Organization' ],
					[ 'type' => 'text', 'label' => 'Job Title' ],
					[ 'type' => 'checkbox', 'label' => 'Sessions you plan to attend', 'choices' => [ 'Keynote', 'Workshops', 'Networking', 'Panel discussion' ] ],
					[ 'type' => 'select', 'label' => 'T-shirt size', 'choices' => [ 'S', 'M', 'L', 'XL' ] ],
				],
			],
			'camp-registration' => [
				'name'        => __( 'Camp Registration Form', 'phemightforms' ),
				'description' => __( 'Register participants for camp with guardian and medical details.', 'phemightforms' ),
				'icon'        => 'dashicons-palmtree',
				'category'    => 'registration',
				'fields'      => [
					[ 'type' => 'name', 'label' => 'Camper Name', 'required' => 1 ],
					[ 'type' => 'number', 'label' => 'Age', 'required' => 1 ],
					[ 'type' => 'name', 'label' => 'Parent / Guardian Name', 'required' => 1 ],
					[ 'type' => 'email', 'label' => 'Guardian Email', 'required' => 1 ],
					[ 'type' => 'phone', 'label' => 'Emergency Contact', 'required' => 1 ],
					$message( 'Allergies or medical conditions', 0 ),
					[ 'type' => 'consent', 'label' => 'Waiver', 'required' => 1, 'consent_text' => 'I give permission for my child to participate in camp activities.' ],
				],
			],
			'sports-tryout' => [
				'name'        => __( 'Sports Tryout Registration Form', 'phemightforms' ),
				'description' => __( 'Streamline tryout signups for basketball, football, volleyball, and more.', 'phemightforms' ),
				'icon'        => 'dashicons-awards',
				'category'    => 'registration',
				'fields'      => [
					$name(), $email(), $phone( 1 ),
					[ 'type' => 'select', 'label' => 'Sport', 'required' => 1, 'choices' => [ 'Basketball', 'Football', 'Softball', 'Volleyball', 'Cheerleading', 'Dance Team' ] ],
					[ 'type' => 'select', 'label' => 'Position / Specialty', 'choices' => [ 'Offense', 'Defense', 'Utility', 'Not sure yet' ] ],
					[ 'type' => 'number', 'label' => 'Years of experience' ],
				],
			],
			'intramural' => [
				'name'        => __( 'Intramural Sports Registration Form', 'phemightforms' ),
				'description' => __( 'Have intramural players register and pay directly on the form.', 'phemightforms' ),
				'icon'        => 'dashicons-groups',
				'category'    => 'registration',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'select', 'label' => 'League', 'required' => 1, 'choices' => [ 'Soccer', 'Basketball', 'Softball', 'Ultimate Frisbee' ] ],
					[ 'type' => 'text', 'label' => 'Team Name' ],
					[ 'type' => 'payment_single', 'label' => 'Registration Fee', 'price' => '20' ],
					[ 'type' => 'payment_total', 'label' => 'Total' ],
				],
			],
			'user-registration' => [
				'name'        => __( 'User Registration Form', 'phemightforms' ),
				'description' => __( 'Collect new member signups with account preferences.', 'phemightforms' ),
				'icon'        => 'dashicons-admin-users',
				'category'    => 'registration',
				'fields'      => [
					$name(), $email(),
					[ 'type' => 'text', 'label' => 'Preferred Username', 'required' => 1 ],
					[ 'type' => 'country', 'label' => 'Country' ],
					[ 'type' => 'consent', 'label' => 'Terms', 'required' => 1, 'consent_text' => 'I agree to the terms and privacy policy.' ],
				],
			],
		];

		/**
		 * Filter the available form templates.
		 *
		 * @param array $templates Template definitions.
		 */
		return apply_filters( 'phemightforms_templates', $templates );
	}

	/**
	 * Build a complete, save-ready form config from a template slug.
	 *
	 * @param string $slug Template slug.
	 * @return array|null Config array, or null if the slug is unknown.
	 */
	public static function build_config( $slug ) {
		$templates = self::all();

		if ( ! isset( $templates[ $slug ] ) ) {
			return null;
		}

		$template = $templates[ $slug ];
		$config   = Form::default_config();
		$id       = 1;

		foreach ( $template['fields'] as $field ) {
			$field['id']        = $id++;
			$config['fields'][] = $field;

			// Templates that contain payment fields start with payments on.
			if ( isset( $field['type'] ) && 0 === strpos( $field['type'], 'payment_' ) ) {
				$config['settings']['payments_enabled'] = 1;
			}
		}

		$config['_next_id'] = $id;

		if ( ! empty( $template['is_quiz'] ) ) {
			$config['settings']['is_quiz'] = 1;
		}

		return $config;
	}

	/**
	 * Suggested title for a template.
	 *
	 * @param string $slug Template slug.
	 * @return string
	 */
	public static function title( $slug ) {
		$templates = self::all();

		return isset( $templates[ $slug ] ) ? $templates[ $slug ]['name'] : __( 'New Form', 'phemightforms' );
	}
}
