<?php
/**
 * Third-party integrations (Mailchimp, Google Sheets, Akismet, webhooks).
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dispatches submissions to external services.
 */
class Integrations {

	/**
	 * Run all enabled integrations after a successful submission.
	 *
	 * @param Form  $form   Form.
	 * @param array $stored Stored field rows.
	 */
	public static function dispatch( Form $form, array $stored ) {
		self::maybe_mailchimp( $form, $stored );
		self::maybe_google_sheets( $form, $stored );

		if ( $form->setting( 'webhook_enabled' ) && $form->setting( 'webhook_url' ) ) {
			self::webhook( $form, $stored );
		}
	}

	/**
	 * Check submission against Akismet when enabled.
	 *
	 * @param Form  $form Form.
	 * @param array $raw  Raw POST (unslashed).
	 * @return bool True if spam.
	 */
	public static function is_spam( Form $form, array $raw ) {
		if ( ! Plugin::get_option( 'akismet_enabled', 0 ) ) {
			return false;
		}

		$key = Plugin::get_option( 'akismet_key', '' );
		if ( ! $key && defined( 'WPAKISMET_VERSION' ) ) {
			$key = get_option( 'wordpress_api_key', '' );
		}
		if ( ! $key ) {
			return false;
		}

		$content = '';
		$author  = '';
		$email   = '';

		foreach ( $form->get_fields() as $field ) {
			$fid = (int) $field['id'];
			$key_name = 'field_' . $fid;
			$type = isset( $field['type'] ) ? $field['type'] : 'text';

			if ( 'email' === $type && ! empty( $raw[ $key_name ] ) ) {
				$email = sanitize_email( $raw[ $key_name ] );
			}
			if ( in_array( $type, [ 'text', 'textarea' ], true ) && ! empty( $raw[ $key_name ] ) ) {
				$content .= sanitize_text_field( is_array( $raw[ $key_name ] ) ? implode( ' ', $raw[ $key_name ] ) : $raw[ $key_name ] ) . "\n";
			}
			if ( 'name' === $type ) {
				$first = isset( $raw[ $key_name . '_first' ] ) ? $raw[ $key_name . '_first' ] : '';
				$last  = isset( $raw[ $key_name . '_last' ] ) ? $raw[ $key_name . '_last' ] : '';
				$author = trim( $first . ' ' . $last );
			}
		}

		$response = wp_remote_post(
			'https://rest.akismet.com/1.1/comment-check',
			[
				'timeout' => 8,
				'body'    => [
					'api_key'          => $key,
					'blog'             => home_url(),
					'user_ip'          => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
					'user_agent'       => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
					'comment_type'     => 'contact-form',
					'comment_author'   => $author,
					'comment_author_email' => $email,
					'comment_content'  => $content,
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return 'true' === wp_remote_retrieve_body( $response );
	}

	/**
	 * Subscribe an email address to Mailchimp.
	 *
	 * @param Form  $form   Form.
	 * @param array $stored Stored data.
	 */
	private static function maybe_mailchimp( Form $form, array $stored ) {
		if ( ! $form->setting( 'mailchimp_enabled' ) ) {
			return;
		}

		$api_key = Plugin::get_option( 'mailchimp_api_key', '' );
		$list_id = $form->setting( 'mailchimp_list', Plugin::get_option( 'mailchimp_list_id', '' ) );

		if ( ! $api_key || ! $list_id ) {
			return;
		}

		$email = self::find_email( $form, $stored );
		if ( ! $email ) {
			return;
		}

		if ( ! preg_match( '/-([a-z0-9]+)$/i', $api_key, $m ) ) {
			return;
		}

		$dc   = $m[1];
		$url  = 'https://' . $dc . '.api.mailchimp.com/3.0/lists/' . rawurlencode( $list_id ) . '/members';
		$body = wp_json_encode(
			[
				'email_address' => $email,
				'status'        => 'subscribed',
			]
		);

		wp_remote_post(
			$url,
			[
				'timeout' => 8,
				'headers' => [
					'Authorization' => 'Basic ' . base64_encode( 'user:' . $api_key ),
					'Content-Type'  => 'application/json',
				],
				'body'    => $body,
			]
		);
	}

	/**
	 * Push a row to Google Sheets via Apps Script webhook URL.
	 *
	 * @param Form  $form   Form.
	 * @param array $stored Stored data.
	 */
	private static function maybe_google_sheets( Form $form, array $stored ) {
		$url = $form->setting( 'sheets_url', Plugin::get_option( 'google_sheets_url', '' ) );
		if ( ! $url ) {
			return;
		}

		$row = [ 'form' => $form->title, 'date' => current_time( 'mysql' ) ];
		foreach ( $stored as $item ) {
			$row[ $item['label'] ] = $item['value'];
		}

		wp_remote_post(
			$url,
			[
				'timeout'  => 8,
				'blocking' => false,
				'headers'  => [ 'Content-Type' => 'application/json' ],
				'body'     => wp_json_encode( $row ),
			]
		);
	}

	/**
	 * POST submission to webhook with optional format template.
	 *
	 * @param Form  $form   Form.
	 * @param array $stored Stored data.
	 */
	private static function webhook( Form $form, array $stored ) {
		$url    = $form->setting( 'webhook_url' );
		$format = $form->setting( 'webhook_format', 'generic' );

		$payload = [
			'form_id'   => $form->id,
			'form_name' => $form->title,
			'fields'    => $stored,
			'date'      => current_time( 'mysql' ),
		];

		$body = wp_json_encode( $payload );
		$headers = [ 'Content-Type' => 'application/json' ];

		if ( 'slack' === $format ) {
			$lines = array_map(
				static function ( $row ) {
					return '*' . $row['label'] . '*: ' . $row['value'];
				},
				$stored
			);
			$body = wp_json_encode( [ 'text' => '*' . $form->title . "*\n" . implode( "\n", $lines ) ] );
		} elseif ( 'discord' === $format ) {
			$lines = array_map(
				static function ( $row ) {
					return '**' . $row['label'] . '**: ' . $row['value'];
				},
				$stored
			);
			$body = wp_json_encode( [ 'content' => '**' . $form->title . "**\n" . implode( "\n", $lines ) ] );
		} elseif ( 'telegram' === $format ) {
			$lines = array_map(
				static function ( $row ) {
					return $row['label'] . ': ' . $row['value'];
				},
				$stored
			);
			$body = wp_json_encode( [ 'text' => $form->title . "\n" . implode( "\n", $lines ) ] );
		}

		wp_remote_post(
			$url,
			[
				'timeout'  => 8,
				'blocking' => false,
				'headers'  => $headers,
				'body'     => $body,
			]
		);
	}

	/**
	 * Find the first email value in stored submission data.
	 *
	 * @param Form  $form   Form.
	 * @param array $stored Stored rows.
	 * @return string
	 */
	private static function find_email( Form $form, array $stored ) {
		foreach ( $stored as $row ) {
			if ( isset( $row['type'] ) && 'email' === $row['type'] && is_email( $row['value'] ) ) {
				return $row['value'];
			}
		}

		foreach ( $stored as $row ) {
			if ( is_email( $row['value'] ) ) {
				return $row['value'];
			}
		}

		return '';
	}
}
