<?php
/**
 * GDPR data export and erasure tools.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Install;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin tools for personal data requests.
 */
class GDPR {

	/**
	 * Export must run on admin_init, before any admin page output, so the
	 * JSON download headers can be sent.
	 */
	public static function maybe_export() {
		if ( ! isset( $_POST['phf_gdpr_action'] ) || 'export' !== sanitize_key( wp_unslash( $_POST['phf_gdpr_action'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			return;
		}

		check_admin_referer( 'phemightforms_gdpr' );

		$email = isset( $_POST['phf_gdpr_email'] ) ? sanitize_email( wp_unslash( $_POST['phf_gdpr_email'] ) ) : '';

		if ( is_email( $email ) ) {
			self::export_by_email( $email );
		}
	}

	/**
	 * Render the GDPR tools section (called from Settings).
	 */
	public static function render_section() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			return;
		}

		$message = '';
		if ( isset( $_POST['phf_gdpr_action'] ) && check_admin_referer( 'phemightforms_gdpr' ) ) {
			$email  = isset( $_POST['phf_gdpr_email'] ) ? sanitize_email( wp_unslash( $_POST['phf_gdpr_email'] ) ) : '';
			$action = sanitize_key( wp_unslash( $_POST['phf_gdpr_action'] ) );

			if ( ! is_email( $email ) ) {
				$message = 'error:' . __( 'Please enter a valid email address.', 'phemightforms' );
			} elseif ( 'delete' === $action ) {
				$count   = self::delete_by_email( $email );
				$message = 'success:' . sprintf(
					/* translators: %d: number of entries removed. */
					__( 'Removed %d entries containing that email.', 'phemightforms' ),
					$count
				);
			}
		}
		?>
		<div class="phf-settings-section">
			<h3><?php esc_html_e( 'GDPR Tools', 'phemightforms' ); ?></h3>
			<p class="description phf-muted"><?php esc_html_e( 'Export or delete all stored entries that contain a specific email address.', 'phemightforms' ); ?></p>

			<?php if ( $message ) : ?>
				<?php
				list( $type, $text ) = array_pad( explode( ':', $message, 2 ), 2, '' );
				?>
				<div class="phf-notice phf-notice-<?php echo 'error' === $type ? 'error' : 'success'; ?>"><?php echo esc_html( $text ); ?></div>
			<?php endif; ?>

			<form method="post">
				<?php wp_nonce_field( 'phemightforms_gdpr' ); ?>
				<div class="phf-field-row">
					<label for="phf-gdpr-email"><?php esc_html_e( 'Email address', 'phemightforms' ); ?></label>
					<input type="email" id="phf-gdpr-email" name="phf_gdpr_email" required>
				</div>
				<div class="phf-filter-bar">
					<button type="submit" name="phf_gdpr_action" value="export" class="phf-btn phf-btn-ghost"><?php esc_html_e( 'Export data (JSON)', 'phemightforms' ); ?></button>
					<button type="submit" name="phf_gdpr_action" value="delete" class="phf-btn phf-btn-ghost phf-btn-danger" onclick="return confirm('<?php echo esc_js( __( 'Permanently delete all matching entries?', 'phemightforms' ) ); ?>');"><?php esc_html_e( 'Delete entries', 'phemightforms' ); ?></button>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * Download entries matching an email as JSON.
	 *
	 * @param string $email Email to search for.
	 */
	private static function export_by_email( $email ) {
		$rows    = self::find_entries( $email );
		$payload = [];

		foreach ( $rows as $row ) {
			$payload[] = [
				'id'         => (int) $row->id,
				'form_id'    => (int) $row->form_id,
				'fields'     => json_decode( $row->fields, true ),
				'ip_address' => $row->ip_address,
				'created_at' => $row->created_at,
			];
		}

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="phemightforms-gdpr-' . sanitize_file_name( $email ) . '.json"' );
		echo wp_json_encode( $payload, JSON_PRETTY_PRINT );
		exit;
	}

	/**
	 * Delete entries containing the given email.
	 *
	 * @param string $email Email to match.
	 * @return int Number deleted.
	 */
	private static function delete_by_email( $email ) {
		global $wpdb;

		$rows  = self::find_entries( $email );
		$table = Install::entries_table();
		$count = 0;

		foreach ( $rows as $row ) {
			$wpdb->delete( $table, [ 'id' => $row->id ], [ '%d' ] ); // phpcs:ignore WordPress.DB
			$count++;
		}

		return $count;
	}

	/**
	 * Find entry rows whose JSON contains the email.
	 *
	 * @param string $email Email address.
	 * @return array
	 */
	private static function find_entries( $email ) {
		global $wpdb;

		$table = Install::entries_table();
		$like  = '%' . $wpdb->esc_like( $email ) . '%';

		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE fields LIKE %s", $like ) ); // phpcs:ignore WordPress.DB
	}
}
