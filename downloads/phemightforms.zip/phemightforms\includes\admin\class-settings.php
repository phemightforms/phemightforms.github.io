<?php
/**
 * Global settings screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and saves the plugin-wide settings.
 */
class Settings {

	/**
	 * Register the settings storage.
	 */
	public function __construct() {
		add_action( 'admin_init', [ $this, 'register' ] );
		add_action( 'admin_init', [ PrivacyPage::class, 'maybe_export' ] );
	}

	/**
	 * Register the option and its sanitizer.
	 */
	public function register() {
		register_setting(
			'phemightforms_settings_group',
			'phemightforms_settings',
			[
				'type'              => 'array',
				'sanitize_callback' => [ $this, 'sanitize' ],
				'default'           => [],
			]
		);
	}

	/**
	 * Sanitize submitted settings.
	 *
	 * @param array $input Raw values.
	 * @return array
	 */
	public function sanitize( $input ) {
		if ( ! is_array( $input ) ) {
			$input = [];
		}

		$existing = get_option( 'phemightforms_settings', [] );

		$provider = isset( $input['captcha_provider'] ) ? sanitize_key( $input['captcha_provider'] ) : ( $existing['captcha_provider'] ?? '' );
		if ( ! in_array( $provider, [ '', 'recaptcha_v2', 'hcaptcha', 'turnstile' ], true ) ) {
			$provider = '';
		}

		$encryption = isset( $input['smtp_encryption'] ) ? sanitize_key( $input['smtp_encryption'] ) : ( $existing['smtp_encryption'] ?? 'tls' );
		if ( ! in_array( $encryption, [ 'none', 'ssl', 'tls' ], true ) ) {
			$encryption = 'tls';
		}

		$mailer = isset( $input['smtp_mailer'] ) ? sanitize_key( $input['smtp_mailer'] ) : ( $existing['smtp_mailer'] ?? 'default' );
		if ( ! in_array( $mailer, [ 'default', 'smtp' ], true ) ) {
			$mailer = 'default';
		}

		$smtp_pass = isset( $input['smtp_pass'] ) ? $input['smtp_pass'] : '';
		if ( '' === $smtp_pass && ! empty( $existing['smtp_pass'] ) ) {
			$smtp_pass = $existing['smtp_pass'];
		}

		return array_merge(
			$existing,
			[
			'from_name'            => isset( $input['from_name'] ) ? sanitize_text_field( $input['from_name'] ) : ( $existing['from_name'] ?? '' ),
			'from_email'           => isset( $input['from_email'] ) ? sanitize_email( $input['from_email'] ) : ( $existing['from_email'] ?? '' ),
			'honeypot'             => isset( $input['honeypot'] ) ? ( ! empty( $input['honeypot'] ) ? 1 : 0 ) : ( $existing['honeypot'] ?? 1 ),
			'store_entries'        => isset( $input['store_entries'] ) ? ( ! empty( $input['store_entries'] ) ? 1 : 0 ) : ( $existing['store_entries'] ?? 1 ),
			'captcha_provider'     => $provider,
			'captcha_site_key'     => isset( $input['captcha_site_key'] ) ? sanitize_text_field( $input['captcha_site_key'] ) : ( $existing['captcha_site_key'] ?? '' ),
			'captcha_secret_key'   => isset( $input['captcha_secret_key'] ) ? sanitize_text_field( $input['captcha_secret_key'] ) : ( $existing['captcha_secret_key'] ?? '' ),
			'entry_retention_days' => isset( $input['entry_retention_days'] ) ? absint( $input['entry_retention_days'] ) : ( $existing['entry_retention_days'] ?? 0 ),
			'smtp_mailer'          => $mailer,
			'smtp_enabled'         => 'smtp' === $mailer ? 1 : 0,
			'smtp_host'            => isset( $input['smtp_host'] ) ? sanitize_text_field( $input['smtp_host'] ) : ( $existing['smtp_host'] ?? '' ),
			'smtp_port'            => isset( $input['smtp_port'] ) ? absint( $input['smtp_port'] ) : ( $existing['smtp_port'] ?? 587 ),
			'smtp_encryption'      => $encryption,
			'smtp_auth'            => isset( $input['smtp_auth'] ) ? ( ! empty( $input['smtp_auth'] ) ? 1 : 0 ) : ( $existing['smtp_auth'] ?? 1 ),
			'smtp_user'            => isset( $input['smtp_user'] ) ? sanitize_text_field( $input['smtp_user'] ) : ( $existing['smtp_user'] ?? '' ),
			'smtp_pass'            => sanitize_text_field( $smtp_pass ),
			'smtp_from_email'      => isset( $input['smtp_from_email'] ) ? sanitize_email( $input['smtp_from_email'] ) : ( $existing['smtp_from_email'] ?? '' ),
			'smtp_from_name'       => isset( $input['smtp_from_name'] ) ? sanitize_text_field( $input['smtp_from_name'] ) : ( $existing['smtp_from_name'] ?? '' ),
			'mailchimp_api_key'    => isset( $input['mailchimp_api_key'] ) ? sanitize_text_field( $input['mailchimp_api_key'] ) : ( $existing['mailchimp_api_key'] ?? '' ),
			'mailchimp_list_id'    => isset( $input['mailchimp_list_id'] ) ? sanitize_text_field( $input['mailchimp_list_id'] ) : ( $existing['mailchimp_list_id'] ?? '' ),
			'google_sheets_url'    => isset( $input['google_sheets_url'] ) ? esc_url_raw( $input['google_sheets_url'] ) : ( $existing['google_sheets_url'] ?? '' ),
			'akismet_enabled'      => isset( $input['akismet_enabled'] ) ? ( ! empty( $input['akismet_enabled'] ) ? 1 : 0 ) : ( $existing['akismet_enabled'] ?? 0 ),
			'akismet_key'          => isset( $input['akismet_key'] ) ? sanitize_text_field( $input['akismet_key'] ) : ( $existing['akismet_key'] ?? '' ),
			]
		);
	}

	/**
	 * Output the settings form.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$tab      = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$settings = get_option( 'phemightforms_settings', [] );
		$get      = static function ( $key, $default = '' ) use ( $settings ) {
			return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
		};

		$tabs = [
			'general'      => __( 'General', 'phemightforms' ),
			'integrations' => __( 'Integrations', 'phemightforms' ),
		];
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'settings' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Settings', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'Spam protection, integrations, and compliance.', 'phemightforms' ); ?></p>
					</div>
				</div>

				<nav class="phf-settings-tabs">
					<?php foreach ( $tabs as $key => $label ) : ?>
						<a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-settings', 'tab' => $key ], admin_url( 'admin.php' ) ) ); ?>" class="<?php echo $tab === $key ? 'is-active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
					<?php endforeach; ?>
				</nav>

				<?php if ( isset( $_GET['settings-updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Settings saved.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<form method="post" action="options.php">
						<?php settings_fields( 'phemightforms_settings_group' ); ?>

						<?php if ( 'general' === $tab ) : ?>
							<div class="phf-settings-grid">
								<div class="phf-settings-section">
									<h3><?php esc_html_e( 'Email defaults', 'phemightforms' ); ?></h3>
									<div class="phf-field-row">
										<label for="phf-from-name"><?php esc_html_e( 'From name', 'phemightforms' ); ?></label>
										<input type="text" id="phf-from-name" name="phemightforms_settings[from_name]" value="<?php echo esc_attr( $get( 'from_name', get_bloginfo( 'name' ) ) ); ?>">
									</div>
									<div class="phf-field-row">
										<label for="phf-from-email"><?php esc_html_e( 'From email', 'phemightforms' ); ?></label>
										<input type="email" id="phf-from-email" name="phemightforms_settings[from_email]" value="<?php echo esc_attr( $get( 'from_email', get_option( 'admin_email' ) ) ); ?>">
									</div>
								</div>
								<div class="phf-settings-section">
									<h3><?php esc_html_e( 'Spam & entries', 'phemightforms' ); ?></h3>
									<div class="phf-field-row"><label class="phf-checkbox"><input type="checkbox" name="phemightforms_settings[honeypot]" value="1" <?php checked( $get( 'honeypot', 1 ), 1 ); ?>> <?php esc_html_e( 'Honeypot anti spam', 'phemightforms' ); ?></label></div>
									<div class="phf-field-row"><label class="phf-checkbox"><input type="checkbox" name="phemightforms_settings[store_entries]" value="1" <?php checked( $get( 'store_entries', 1 ), 1 ); ?>> <?php esc_html_e( 'Store submissions', 'phemightforms' ); ?></label></div>
									<div class="phf-field-row">
										<label for="phf-retention"><?php esc_html_e( 'Auto delete after (days)', 'phemightforms' ); ?></label>
										<input type="number" id="phf-retention" name="phemightforms_settings[entry_retention_days]" min="0" value="<?php echo esc_attr( $get( 'entry_retention_days', 0 ) ); ?>">
									</div>
								</div>
								<div class="phf-settings-section phf-settings-link-card">
									<h3><?php esc_html_e( 'CAPTCHA', 'phemightforms' ); ?></h3>
									<p class="phf-muted"><?php esc_html_e( 'Configure hCaptcha, reCAPTCHA, or Cloudflare Turnstile on a dedicated page with provider logos and key fields.', 'phemightforms' ); ?></p>
									<a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-captcha' ], admin_url( 'admin.php' ) ) ); ?>" class="phf-btn phf-btn-ghost"><span class="dashicons dashicons-shield"></span> <?php esc_html_e( 'Open CAPTCHA Settings', 'phemightforms' ); ?></a>
								</div>
								<div class="phf-settings-section phf-settings-link-card">
									<h3><?php esc_html_e( 'Privacy Compliance', 'phemightforms' ); ?></h3>
									<p class="phf-muted"><?php esc_html_e( 'GDPR tools, data retention, export/erase requests, and consent checklist.', 'phemightforms' ); ?></p>
									<a href="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-privacy' ], admin_url( 'admin.php' ) ) ); ?>" class="phf-btn phf-btn-ghost"><span class="dashicons dashicons-privacy"></span> <?php esc_html_e( 'Open Privacy Compliance', 'phemightforms' ); ?></a>
								</div>
							</div>
						<?php elseif ( 'integrations' === $tab ) : ?>
							<div class="phf-settings-grid">
								<div class="phf-settings-section">
									<h3><?php esc_html_e( 'Mailchimp', 'phemightforms' ); ?></h3>
									<p class="phf-muted"><?php esc_html_e( 'Enable per form Mailchimp subscribe in form settings.', 'phemightforms' ); ?></p>
									<div class="phf-field-row"><label for="phf-mc-key"><?php esc_html_e( 'API key', 'phemightforms' ); ?></label><input type="text" id="phf-mc-key" name="phemightforms_settings[mailchimp_api_key]" value="<?php echo esc_attr( $get( 'mailchimp_api_key', '' ) ); ?>"></div>
									<div class="phf-field-row"><label for="phf-mc-list"><?php esc_html_e( 'Default list ID', 'phemightforms' ); ?></label><input type="text" id="phf-mc-list" name="phemightforms_settings[mailchimp_list_id]" value="<?php echo esc_attr( $get( 'mailchimp_list_id', '' ) ); ?>"></div>
								</div>
								<div class="phf-settings-section">
									<h3><?php esc_html_e( 'Google Sheets', 'phemightforms' ); ?></h3>
									<p class="phf-muted"><?php esc_html_e( 'Paste a Google Apps Script web app URL. Each submission POSTs a JSON row.', 'phemightforms' ); ?></p>
									<div class="phf-field-row"><label for="phf-sheets-url"><?php esc_html_e( 'Apps Script URL', 'phemightforms' ); ?></label><input type="url" id="phf-sheets-url" name="phemightforms_settings[google_sheets_url]" value="<?php echo esc_attr( $get( 'google_sheets_url', '' ) ); ?>" class="widefat"></div>
								</div>
								<div class="phf-settings-section">
									<h3><?php esc_html_e( 'Akismet spam filter', 'phemightforms' ); ?></h3>
									<div class="phf-field-row"><label class="phf-checkbox"><input type="checkbox" name="phemightforms_settings[akismet_enabled]" value="1" <?php checked( $get( 'akismet_enabled', 0 ), 1 ); ?>> <?php esc_html_e( 'Check submissions with Akismet', 'phemightforms' ); ?></label></div>
									<div class="phf-field-row"><label for="phf-akismet-key"><?php esc_html_e( 'Akismet API key (optional if plugin active)', 'phemightforms' ); ?></label><input type="text" id="phf-akismet-key" name="phemightforms_settings[akismet_key]" value="<?php echo esc_attr( $get( 'akismet_key', '' ) ); ?>"></div>
								</div>
								<div class="phf-settings-section">
									<h3><?php esc_html_e( 'Webhook payload example', 'phemightforms' ); ?></h3>
									<p class="phf-muted"><?php esc_html_e( 'Use this structure for Zapier, Make, or custom endpoints. Set format to Slack/Discord/Telegram in form settings.', 'phemightforms' ); ?></p>
									<pre class="phf-code-sample"><?php echo esc_html( wp_json_encode( [ 'form_id' => 1, 'form_name' => 'Contact', 'fields' => [ [ 'label' => 'Email', 'value' => 'user@example.com' ] ], 'date' => '2026-01-01 12:00:00' ], JSON_PRETTY_PRINT ) ); ?></pre>
								</div>
							</div>
						<?php endif; ?>

					<div class="phf-settings-actions">
						<?php submit_button( __( 'Save Settings', 'phemightforms' ) ); ?>
					</div>
				</form>
			</div>
		</div>
		<?php
	}
}
