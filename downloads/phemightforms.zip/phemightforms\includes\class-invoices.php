<?php
/**
 * Standalone invoices and shareable payment links.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores invoices / payment links and renders public pay pages.
 */
class Invoices {

	const OPTION    = 'phemightforms_invoices';
	const QUERY_VAR = 'phemightforms_pay';
	const PDF_VAR   = 'phemightforms_pay_pdf';

	/**
	 * Hook rewrite rules, public pay page, and payment handler.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_rewrite' ], 5 );
		add_filter( 'query_vars', [ $this, 'query_vars' ] );
		add_action( 'template_redirect', [ $this, 'render_pay_page' ] );
		add_action( 'admin_init', [ $this, 'maybe_flush_rewrites' ] );
	}

	/**
	 * Register the public pay URL.
	 */
	public function register_rewrite() {
		add_rewrite_tag( '%' . self::QUERY_VAR . '%', '([a-zA-Z0-9_-]+)' );
		add_rewrite_tag( '%' . self::PDF_VAR . '%', '([0-1])' );
		add_rewrite_rule( '^phemight-pay/([a-zA-Z0-9_-]+)/pdf/?$', 'index.php?' . self::QUERY_VAR . '=$matches[1]&' . self::PDF_VAR . '=1', 'top' );
		add_rewrite_rule( '^phemight-pay/([a-zA-Z0-9_-]+)/?$', 'index.php?' . self::QUERY_VAR . '=$matches[1]', 'top' );
	}

	/**
	 * Flush permalinks once after this feature ships.
	 */
	public function maybe_flush_rewrites() {
		if ( get_option( 'phemightforms_pay_rewrite' ) === PHEMIGHTFORMS_VERSION ) {
			return;
		}

		flush_rewrite_rules();
		update_option( 'phemightforms_pay_rewrite', PHEMIGHTFORMS_VERSION );
	}

	/**
	 * @param array $vars Query vars.
	 * @return array
	 */
	public function query_vars( $vars ) {
		$vars[] = self::QUERY_VAR;
		$vars[] = self::PDF_VAR;
		return $vars;
	}

	/**
	 * All invoices, newest first.
	 *
	 * @return array
	 */
	public static function all() {
		$items = array_values( (array) get_option( self::OPTION, [] ) );
		usort(
			$items,
			static function ( $a, $b ) {
				return strcmp( $b['created'] ?? '', $a['created'] ?? '' );
			}
		);
		return $items;
	}

	/**
	 * Find one invoice by ID.
	 *
	 * @param string $id Invoice ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		foreach ( self::all() as $item ) {
			if ( isset( $item['id'] ) && $item['id'] === $id ) {
				return $item;
			}
		}
		return null;
	}

	/**
	 * Find one invoice by public slug.
	 *
	 * @param string $slug URL slug.
	 * @return array|null
	 */
	public static function get_by_slug( $slug ) {
		$slug = sanitize_title( $slug );
		foreach ( self::all() as $item ) {
			if ( isset( $item['slug'] ) && $item['slug'] === $slug ) {
				return $item;
			}
		}
		return null;
	}

	/**
	 * Create or update an invoice.
	 *
	 * @param array  $data Invoice fields.
	 * @param string $id   Existing ID, or empty to create.
	 * @return string Saved invoice ID.
	 */
	public static function save( array $data, $id = '' ) {
		$enabled = Payments::enabled_providers();
		$methods = self::sanitize_payment_methods( $data, $enabled );

		$type = isset( $data['type'] ) && 'payment_link' === $data['type'] ? 'payment_link' : 'invoice';

		$row = [
			'id'               => $id ? $id : 'inv_' . wp_generate_password( 10, false ),
			'slug'             => '',
			'type'             => $type,
			'title'            => isset( $data['title'] ) ? sanitize_text_field( $data['title'] ) : __( 'Payment', 'phemightforms' ),
			'description'      => isset( $data['description'] ) ? sanitize_textarea_field( $data['description'] ) : '',
			'amount'           => Payments::to_amount( isset( $data['amount'] ) ? $data['amount'] : 0 ),
			'customer_name'    => isset( $data['customer_name'] ) ? sanitize_text_field( $data['customer_name'] ) : '',
			'customer_email'   => isset( $data['customer_email'] ) ? sanitize_email( $data['customer_email'] ) : '',
			'payment_methods'  => $methods,
			'payment_method'   => $methods ? $methods[0] : 'offline',
			'due_date'         => isset( $data['due_date'] ) ? sanitize_text_field( $data['due_date'] ) : '',
			'line_items'       => isset( $data['line_items'] ) ? sanitize_textarea_field( $data['line_items'] ) : '',
			'status'           => isset( $data['status'] ) ? sanitize_key( $data['status'] ) : 'pending',
			'txn_id'           => '',
			'created'          => current_time( 'mysql' ),
			'updated'          => current_time( 'mysql' ),
		];

		$found = false;
		$items = (array) get_option( self::OPTION, [] );
		foreach ( $items as &$item ) {
			if ( isset( $item['id'] ) && $item['id'] === $row['id'] ) {
				$row['slug']    = $item['slug'] ?? self::make_slug( $row['title'], $row['id'] );
				$row['created'] = $item['created'] ?? $row['created'];
				$row['txn_id']  = $item['txn_id'] ?? '';
				if ( 'paid' === ( $item['status'] ?? '' ) ) {
					$row['status'] = 'paid';
				}
				$item   = $row;
				$found  = true;
				break;
			}
		}
		unset( $item );

		if ( ! $found ) {
			$row['slug'] = self::make_slug( $row['title'], $row['id'] );
			$items[]     = $row;
		}

		update_option( self::OPTION, $items );

		return $row['id'];
	}

	/**
	 * Delete an invoice.
	 *
	 * @param string $id Invoice ID.
	 */
	public static function delete( $id ) {
		$items = array_filter(
			self::all(),
			static function ( $item ) use ( $id ) {
				return ! isset( $item['id'] ) || $item['id'] !== $id;
			}
		);
		update_option( self::OPTION, array_values( $items ) );
	}

	/**
	 * Public pay URL for an invoice slug.
	 *
	 * @param string $slug URL slug.
	 * @return string
	 */
	public static function url( $slug ) {
		return home_url( 'phemight-pay/' . rawurlencode( sanitize_title( $slug ) ) . '/' );
	}

	/**
	 * Public PDF download URL for an invoice slug.
	 *
	 * @param string $slug URL slug.
	 * @return string
	 */
	public static function pdf_url( $slug ) {
		return home_url( 'phemight-pay/' . rawurlencode( sanitize_title( $slug ) ) . '/pdf/' );
	}

	/**
	 * Enabled payment methods allowed for this invoice.
	 *
	 * @param array $invoice Invoice row.
	 * @return array<string,string> slug => label
	 */
	public static function payment_methods_for( array $invoice ) {
		$enabled = Payments::enabled_providers();
		$stored  = [];

		if ( ! empty( $invoice['payment_methods'] ) && is_array( $invoice['payment_methods'] ) ) {
			$stored = array_map( 'sanitize_key', $invoice['payment_methods'] );
		} elseif ( ! empty( $invoice['payment_method'] ) ) {
			// Legacy invoices saved before multi-gateway support: offer every enabled gateway.
			return $enabled;
		}

		$methods = [];

		foreach ( $stored as $slug ) {
			if ( isset( $enabled[ $slug ] ) ) {
				$methods[ $slug ] = $enabled[ $slug ];
			}
		}

		return $methods ? $methods : $enabled;
	}

	/**
	 * Normalize payment method selection from save payload.
	 *
	 * @param array $data    Save payload.
	 * @param array $enabled Enabled providers.
	 * @return string[]
	 */
	private static function sanitize_payment_methods( array $data, array $enabled ) {
		$keys = array_keys( $enabled );

		if ( empty( $keys ) ) {
			return [ 'offline' ];
		}

		if ( ! empty( $data['payment_methods_all'] ) ) {
			return $keys;
		}

		$raw = isset( $data['payment_methods'] ) ? (array) $data['payment_methods'] : [];
		$raw = array_map( 'sanitize_key', wp_unslash( $raw ) );
		$raw = array_values( array_intersect( $raw, $keys ) );

		return $raw ? $raw : $keys;
	}

	/**
	 * Mark invoice paid when its transaction completes.
	 *
	 * @param string $txn_id Transaction ID.
	 */
	public static function mark_paid_by_txn( $txn_id ) {
		if ( ! $txn_id ) {
			return;
		}

		$items = (array) get_option( self::OPTION, [] );
		$dirty = false;

		foreach ( $items as &$item ) {
			if ( isset( $item['txn_id'] ) && $item['txn_id'] === $txn_id ) {
				$item['status']  = 'paid';
				$item['updated'] = current_time( 'mysql' );
				$dirty           = true;
			}
		}
		unset( $item );

		if ( $dirty ) {
			update_option( self::OPTION, $items );
		}
	}

	/**
	 * Process a pay-now submission and redirect or show instructions.
	 *
	 * @param array $invoice Invoice row.
	 * @return array{message:string,redirect?:string}
	 */
	public static function process_payment( array $invoice, $method = '' ) {
		if ( 'paid' === ( $invoice['status'] ?? '' ) ) {
			return [ 'message' => __( 'This invoice has already been paid. Thank you!', 'phemightforms' ) ];
		}

		$allowed = self::payment_methods_for( $invoice );
		$method  = $method ? sanitize_key( $method ) : '';

		if ( ! $method || ! isset( $allowed[ $method ] ) ) {
			return [ 'message' => __( 'Please select a valid payment method.', 'phemightforms' ) ];
		}
		$amount = (float) ( $invoice['amount'] ?? 0 );
		$email  = $invoice['customer_email'] ?? '';

		if ( $amount <= 0 ) {
			return [ 'message' => __( 'Invalid payment amount.', 'phemightforms' ) ];
		}

		$txn_id = Payments::record_transaction(
			[
				'form_id'  => 0,
				'amount'   => $amount,
				'method'   => $method,
				'status'   => 'pending',
				'currency' => Payments::currency(),
			]
		);

		self::attach_txn( $invoice['id'], $txn_id );

		$form        = new Form();
		$form->title = $invoice['title'];

		if ( ! in_array( $method, [ 'offline', 'cryptowallet' ], true ) ) {
			$url = Payments::checkout_url( $form, $method, $amount, $txn_id, $email );

			if ( $url ) {
				return [
					'message'  => __( 'Redirecting you to secure checkout...', 'phemightforms' ),
					'redirect' => $url,
				];
			}
		}

		$settings = Payments::settings();

		if ( 'cryptowallet' === $method ) {
			return [
				'message' => sprintf(
					/* translators: 1: total, 2: note, 3: addresses */
					__( "Thanks! Your total is %1\$s.\n%2\$s\n\n%3\$s", 'phemightforms' ),
					Payments::format( $amount ),
					trim( (string) $settings['cryptowallet_note'] ),
					trim( (string) $settings['cryptowallet_addresses'] )
				),
			];
		}

		return [
			'message' => sprintf(
				/* translators: 1: total, 2: instructions */
				__( 'Thanks! Your total is %1$s. %2$s', 'phemightforms' ),
				Payments::format( $amount ),
				trim( (string) $settings['offline_instructions'] )
			),
		];
	}

	/**
	 * Store the transaction ID on the invoice row.
	 *
	 * @param string $id     Invoice ID.
	 * @param string $txn_id Transaction ID.
	 */
	private static function attach_txn( $id, $txn_id ) {
		$items = (array) get_option( self::OPTION, [] );

		foreach ( $items as &$item ) {
			if ( isset( $item['id'] ) && $item['id'] === $id ) {
				$item['txn_id']  = $txn_id;
				$item['status']  = 'sent';
				$item['updated'] = current_time( 'mysql' );
			}
		}
		unset( $item );

		update_option( self::OPTION, $items );
	}

	/**
	 * Generate a unique URL slug.
	 *
	 * @param string $title Title.
	 * @param string $id    Invoice ID.
	 * @return string
	 */
	private static function make_slug( $title, $id ) {
		$base = sanitize_title( $title );
		if ( '' === $base ) {
			$base = 'pay';
		}

		$slug = $base;
		$i    = 1;

		while ( self::get_by_slug( $slug ) && ( self::get_by_slug( $slug )['id'] ?? '' ) !== $id ) {
			$slug = $base . '-' . $i;
			$i++;
		}

		return $slug;
	}

	/**
	 * Render the public pay page.
	 */
	public function render_pay_page() {
		$slug = get_query_var( self::QUERY_VAR );
		if ( ! $slug ) {
			return;
		}

		$invoice = self::get_by_slug( $slug );
		if ( ! $invoice ) {
			status_header( 404 );
			exit;
		}

		if ( get_query_var( self::PDF_VAR ) ) {
			InvoicePdf::download( $invoice );
		}

		$notice  = '';
		$success = false;

		if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['phf_pay_nonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['phf_pay_nonce'] ) ), 'phf_pay_' . $invoice['id'] ) ) {
				$method = isset( $_POST['phf_payment_method'] ) ? sanitize_key( wp_unslash( $_POST['phf_payment_method'] ) ) : '';
				$result = self::process_payment( $invoice, $method );

				if ( ! empty( $result['redirect'] ) ) {
					wp_safe_redirect( $result['redirect'] );
					exit;
				}

				$notice  = $result['message'];
				$success = true;
				$invoice = self::get( $invoice['id'] ) ?? $invoice;
			}
		}

		wp_enqueue_style( 'phemightforms' );
		status_header( 200 );
		nocache_headers();

		$is_invoice = 'invoice' === ( $invoice['type'] ?? 'invoice' );
		$is_paid    = 'paid' === ( $invoice['status'] ?? '' );
		$methods    = self::payment_methods_for( $invoice );
		$pdf_url    = self::pdf_url( $invoice['slug'] );
		$selected   = isset( $_POST['phf_payment_method'] ) ? sanitize_key( wp_unslash( $_POST['phf_payment_method'] ) ) : (string) array_key_first( $methods ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! isset( $methods[ $selected ] ) ) {
			$selected = (string) array_key_first( $methods );
		}

		?><!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php echo esc_html( $invoice['title'] ); ?> · <?php bloginfo( 'name' ); ?></title>
			<?php wp_head(); ?>
		</head>
		<body class="phf-pay-page">
			<div class="phf-pay-wrap">
				<div class="phemightforms-form phf-pay-card">
					<div class="phf-pay-top-actions">
						<?php if ( $is_invoice ) : ?>
							<span class="phf-pay-badge"><?php esc_html_e( 'Invoice', 'phemightforms' ); ?></span>
						<?php else : ?>
							<span class="phf-pay-badge phf-pay-badge-link"><?php esc_html_e( 'Payment Link', 'phemightforms' ); ?></span>
						<?php endif; ?>
						<?php if ( $is_invoice ) : ?>
							<a href="<?php echo esc_url( $pdf_url ); ?>" class="phf-pay-pdf-link" download>
								<span class="dashicons dashicons-pdf"></span>
								<?php esc_html_e( 'Download PDF', 'phemightforms' ); ?>
							</a>
						<?php endif; ?>
					</div>

					<h1 class="phemightforms-form-title"><?php echo esc_html( $invoice['title'] ); ?></h1>

					<?php if ( $notice ) : ?>
						<div class="phemightforms-alert <?php echo $success ? 'phemightforms-alert-success' : 'phemightforms-alert-error'; ?>"><?php echo esc_html( $notice ); ?></div>
					<?php endif; ?>

					<?php if ( ! empty( $invoice['description'] ) ) : ?>
						<p class="phf-pay-desc"><?php echo esc_html( $invoice['description'] ); ?></p>
					<?php endif; ?>

					<?php if ( $is_invoice && ( $invoice['customer_name'] || $invoice['customer_email'] ) ) : ?>
						<div class="phf-pay-meta">
							<?php if ( $invoice['customer_name'] ) : ?>
								<div><span><?php esc_html_e( 'Bill to', 'phemightforms' ); ?></span><strong><?php echo esc_html( $invoice['customer_name'] ); ?></strong></div>
							<?php endif; ?>
							<?php if ( $invoice['customer_email'] ) : ?>
								<div><span><?php esc_html_e( 'Email', 'phemightforms' ); ?></span><strong><?php echo esc_html( $invoice['customer_email'] ); ?></strong></div>
							<?php endif; ?>
							<?php if ( ! empty( $invoice['due_date'] ) ) : ?>
								<div><span><?php esc_html_e( 'Due date', 'phemightforms' ); ?></span><strong><?php echo esc_html( $invoice['due_date'] ); ?></strong></div>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $invoice['line_items'] ) ) : ?>
						<div class="phf-pay-lines">
							<?php foreach ( preg_split( '/\r\n|\r|\n/', $invoice['line_items'] ) as $line ) : ?>
								<?php
								$line = trim( $line );
								if ( '' === $line ) {
									continue;
								}
								$parts = array_map( 'trim', explode( '|', $line ) );
								$label = $parts[0];
								$price = isset( $parts[1] ) ? Payments::format( Payments::to_amount( $parts[1] ) ) : '';
								?>
								<div class="phf-pay-line">
									<span><?php echo esc_html( $label ); ?></span>
									<?php if ( $price ) : ?><strong><?php echo esc_html( $price ); ?></strong><?php endif; ?>
								</div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<div class="phf-pay-total">
						<span><?php esc_html_e( 'Total due', 'phemightforms' ); ?></span>
						<strong><?php echo esc_html( Payments::format( $invoice['amount'] ) ); ?></strong>
					</div>

					<?php if ( $is_paid ) : ?>
						<div class="phf-pay-paid"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Paid', 'phemightforms' ); ?></div>
					<?php else : ?>
						<form method="post" class="phf-pay-form">
							<?php wp_nonce_field( 'phf_pay_' . $invoice['id'], 'phf_pay_nonce' ); ?>

							<?php if ( count( $methods ) > 1 ) : ?>
								<div class="phf-pay-methods">
									<p class="phf-pay-methods-label"><?php esc_html_e( 'Choose payment method', 'phemightforms' ); ?></p>
									<div class="phf-pay-methods-grid">
										<?php foreach ( $methods as $slug => $label ) : ?>
											<?php $brand = Payments::provider_brand( $slug ); ?>
											<label class="phf-pay-method-option<?php echo $selected === $slug ? ' is-selected' : ''; ?>">
												<input type="radio" name="phf_payment_method" value="<?php echo esc_attr( $slug ); ?>" <?php checked( $selected, $slug ); ?>>
												<span class="phf-provider-logo <?php echo esc_attr( $brand['class'] ); ?>"><?php echo esc_html( $brand['abbr'] ); ?></span>
												<span class="phf-pay-method-name"><?php echo esc_html( $label ); ?></span>
											</label>
										<?php endforeach; ?>
									</div>
								</div>
							<?php else : ?>
								<?php
								$slug  = (string) array_key_first( $methods );
								$label = $methods[ $slug ] ?? '';
								$brand = Payments::provider_brand( $slug );
								?>
								<input type="hidden" name="phf_payment_method" value="<?php echo esc_attr( $slug ); ?>">
								<div class="phf-pay-method phf-pay-method-single">
									<span class="phf-provider-logo <?php echo esc_attr( $brand['class'] ); ?>"><?php echo esc_html( $brand['abbr'] ); ?></span>
									<span><?php echo esc_html( $label ); ?></span>
								</div>
							<?php endif; ?>

							<button type="submit" class="phemightforms-submit"><?php esc_html_e( 'Pay Now', 'phemightforms' ); ?></button>
						</form>
					<?php endif; ?>
				</div>
			</div>
			<?php
			wp_footer();

			wp_print_inline_script_tag(
				"document.querySelectorAll( '.phf-pay-method-option input' ).forEach( function ( input ) {
					input.addEventListener( 'change', function () {
						document.querySelectorAll( '.phf-pay-method-option' ).forEach( function ( el ) {
							el.classList.remove( 'is-selected' );
						} );
						if ( input.checked && input.closest( '.phf-pay-method-option' ) ) {
							input.closest( '.phf-pay-method-option' ).classList.add( 'is-selected' );
						}
					} );
				} );"
			);
			?>
		</body>
		</html>
		<?php
		exit;
	}
}
