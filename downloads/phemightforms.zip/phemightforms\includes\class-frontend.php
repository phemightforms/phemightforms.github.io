<?php
/**
 * Frontend rendering and shortcode.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders forms on the front end via shortcode.
 */
class Frontend {

	/**
	 * Hook rendering into WordPress.
	 */
	public function __construct() {
		add_shortcode( 'phemightform', [ $this, 'shortcode' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );
	}

	/**
	 * Register (but do not force-load) front-end assets.
	 */
	public function register_assets() {
		wp_register_style( 'phemightforms', PHEMIGHTFORMS_URL . 'assets/css/form.css', [], PHEMIGHTFORMS_VERSION );
		wp_register_script( 'phemightforms', PHEMIGHTFORMS_URL . 'assets/js/form.js', [], PHEMIGHTFORMS_VERSION, true );

		wp_localize_script(
			'phemightforms',
			'PhemightFormsData',
			[
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'currency' => Payments::symbol(),
				'i18n'     => [
					'next'          => __( 'Next', 'phemightforms' ),
					'previous'      => __( 'Previous', 'phemightforms' ),
					'step'          => __( 'Step', 'phemightforms' ),
					'of'            => __( 'of', 'phemightforms' ),
					'couponApplied' => __( 'Coupon applied:', 'phemightforms' ),
					'couponInvalid' => __( 'That coupon code is not valid.', 'phemightforms' ),
					'redirecting'   => __( 'Redirecting to secure checkout...', 'phemightforms' ),
				],
			]
		);
	}

	/**
	 * Handle the [phemightform id="123"] shortcode.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function shortcode( $atts ) {
		$atts = shortcode_atts(
			[
				'id'    => 0,
				'title' => 'true',
			],
			$atts,
			'phemightform'
		);
		$form = new Form( (int) $atts['id'] );

		if ( ! $form->exists() ) {
			return '';
		}

		wp_enqueue_style( 'phemightforms' );
		wp_enqueue_script( 'phemightforms' );
		Captcha::enqueue();

		Analytics::track_view( $form->id );

		$embed_mode = $form->setting( 'embed_mode', 'inline' );
		$html       = $this->render( $form, 'false' === $atts['title'] );

		if ( 'popup' === $embed_mode || 'slide' === $embed_mode ) {
			$btn_text = $form->setting( 'embed_button_text', __( 'Open Form', 'phemightforms' ) );
			return sprintf(
				'<div class="phemightforms-embed phemightforms-embed-%1$s" data-mode="%1$s"><button type="button" class="phemightforms-embed-trigger">%2$s</button><div class="phemightforms-embed-panel" hidden>%3$s</div></div>',
				esc_attr( $embed_mode ),
				esc_html( $btn_text ),
				$html
			);
		}

		return $html;
	}

	/**
	 * Split fields into pages using pagebreak fields as separators.
	 *
	 * @param array $fields Fields.
	 * @return array Array of pages, each an array of [index, field] pairs.
	 */
	private function paginate( array $fields ) {
		$pages   = [];
		$current = [];

		foreach ( $fields as $index => $field ) {
			$type = isset( $field['type'] ) ? $field['type'] : 'text';

			if ( 'pagebreak' === $type ) {
				$pages[]  = $current;
				$current  = [];
				continue;
			}

			$current[] = [ $index, $field ];
		}

		$pages[] = $current;

		return $pages;
	}

	/**
	 * Produce the HTML for a form.
	 *
	 * @param Form  $form       Form to render.
	 * @param bool  $hide_title Whether to hide the form title heading.
	 * @return string
	 */
	public function render( Form $form, $hide_title = false ) {
		$fields    = $form->get_fields();
		$nonce     = wp_create_nonce( 'phemightforms_submit_' . $form->id );
		$pages     = $this->paginate( $fields );
		$multipage = count( $pages ) > 1;
		$has_file  = $this->has_file_field( $fields );
		$enctype   = $has_file ? ' enctype="multipart/form-data"' : '';
		$accent     = sanitize_hex_color( $form->setting( 'accent_color', '#b56d18' ) );
		$btn_text   = sanitize_hex_color( $form->setting( 'button_text_color', '#ffffff' ) );
		$form_bg    = sanitize_hex_color( $form->setting( 'form_bg_color', '#ffffff' ) );
		$text_color = sanitize_hex_color( $form->setting( 'text_color', '#0f172a' ) );
		$border_c   = sanitize_hex_color( $form->setting( 'border_color', '#e2e8f0' ) );
		$border_w   = min( 8, absint( $form->setting( 'border_width', 1 ) ) );
		$radius     = absint( $form->setting( 'border_radius', 12 ) );
		$fsize      = absint( $form->setting( 'font_size', 16 ) );
		$btn_style  = sanitize_key( $form->setting( 'button_style', 'solid' ) );
		$resume     = (int) $form->setting( 'save_resume', 0 );

		$style = sprintf(
			' style="--phf-accent:%1$s;--phf-radius:%2$spx;--phf-font-size:%3$spx;--phf-btn-text:%4$s;--phf-form-bg:%5$s;--phf-text:%6$s;--phf-border:%7$s;--phf-border-w:%8$spx;"',
			esc_attr( $accent ? $accent : '#b56d18' ),
			max( 0, min( 32, $radius ) ),
			max( 12, min( 22, $fsize ) ),
			esc_attr( $btn_text ? $btn_text : '#ffffff' ),
			esc_attr( $form_bg ? $form_bg : '#ffffff' ),
			esc_attr( $text_color ? $text_color : '#0f172a' ),
			esc_attr( $border_c ? $border_c : '#e2e8f0' ),
			$border_w
		);

		ob_start();
		?>
		<form class="phemightforms-form phf-btn-<?php echo esc_attr( $btn_style ); ?><?php echo $multipage ? ' is-multipage' : ''; ?>" method="post"<?php echo $enctype . $style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> data-form-id="<?php echo esc_attr( $form->id ); ?>" data-pages="<?php echo esc_attr( count( $pages ) ); ?>" data-save-resume="<?php echo esc_attr( $resume ); ?>" role="form" aria-label="<?php echo esc_attr( $form->title ); ?>">
			<?php if ( ! $hide_title && $form->title ) : ?>
				<h2 class="phemightforms-form-title"><?php echo esc_html( $form->title ); ?></h2>
			<?php endif; ?>
			<div class="phemightforms-alert" role="alert" aria-live="polite" hidden></div>

			<?php if ( $multipage ) : ?>
				<div class="phemightforms-progress" aria-hidden="true">
					<div class="phemightforms-progress-bar" style="width:<?php echo esc_attr( round( 100 / count( $pages ) ) ); ?>%"></div>
					<span class="phemightforms-progress-text"></span>
				</div>
			<?php endif; ?>

			<?php foreach ( $pages as $page_num => $page_fields ) : ?>
				<div class="phemightforms-page<?php echo 0 === $page_num ? ' is-active' : ''; ?>" data-page="<?php echo esc_attr( $page_num ); ?>"<?php echo 0 === $page_num ? '' : ' hidden'; ?>>
					<?php foreach ( $page_fields as $pair ) : ?>
						<?php echo $this->render_field( $pair[1], $pair[0] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>

			<div class="phemightforms-honeypot" aria-hidden="true">
				<label><?php esc_html_e( 'Leave this field empty', 'phemightforms' ); ?>
					<input type="text" name="phemightforms_hp" tabindex="-1" autocomplete="off" value="">
				</label>
			</div>

			<input type="hidden" name="phemightforms_form_id" value="<?php echo esc_attr( $form->id ); ?>">
			<input type="hidden" name="phemightforms_nonce" value="<?php echo esc_attr( $nonce ); ?>">

			<?php echo Captcha::widget(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in widget(). ?>

			<div class="phemightforms-actions">
				<?php if ( $multipage ) : ?>
					<button type="button" class="phemightforms-prev" hidden><?php esc_html_e( 'Previous', 'phemightforms' ); ?></button>
					<button type="button" class="phemightforms-next"><?php esc_html_e( 'Next', 'phemightforms' ); ?></button>
				<?php endif; ?>
				<button type="submit" class="phemightforms-submit"<?php echo $multipage ? ' hidden' : ''; ?>>
					<?php echo esc_html( $form->setting( 'submit_text', __( 'Submit', 'phemightforms' ) ) ); ?>
				</button>
				<?php if ( $resume ) : ?>
					<button type="button" class="phemightforms-save-resume"><?php esc_html_e( 'Save and continue later', 'phemightforms' ); ?></button>
				<?php endif; ?>
			</div>
			<div class="phemightforms-resume-link" hidden></div>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Whether the form contains a file-upload field.
	 *
	 * @param array $fields Fields.
	 * @return bool
	 */
	private function has_file_field( array $fields ) {
		foreach ( $fields as $field ) {
			if ( isset( $field['type'] ) && 'file' === $field['type'] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Build the conditional-logic data attribute for a field wrapper.
	 *
	 * @param array $field Field config.
	 * @return string
	 */
	private function conditional_attr( array $field ) {
		if ( empty( $field['conditional']['enabled'] ) || empty( $field['conditional']['rules'] ) ) {
			return '';
		}

		$payload = wp_json_encode(
			[
				'action' => isset( $field['conditional']['action'] ) ? $field['conditional']['action'] : 'show',
				'logic'  => isset( $field['conditional']['logic'] ) ? $field['conditional']['logic'] : 'and',
				'rules'  => $field['conditional']['rules'],
			]
		);

		return " data-conditional='" . esc_attr( $payload ) . "'";
	}

	/**
	 * Render a single field row.
	 *
	 * @param array $field Field configuration.
	 * @param int   $index Position in the config array (used only as a fallback id).
	 * @return string
	 */
	private function render_field( array $field, $index ) {
		$type = isset( $field['type'] ) ? $field['type'] : 'text';
		$fid  = isset( $field['id'] ) && $field['id'] ? (int) $field['id'] : ( $index + 1 );

		// Display-only fields.
		if ( 'section' === $type ) {
			return sprintf(
				'<div class="phemightforms-field phemightforms-section" data-field-id="%1$d"%2$s><h3>%3$s</h3>%4$s</div>',
				$fid,
				$this->conditional_attr( $field ),
				esc_html( isset( $field['label'] ) ? $field['label'] : '' ),
				! empty( $field['description'] ) ? '<p>' . esc_html( $field['description'] ) . '</p>' : ''
			);
		}

		if ( 'html' === $type ) {
			$content = isset( $field['html_content'] ) ? $field['html_content'] : '';
			return sprintf(
				'<div class="phemightforms-field phemightforms-html" data-field-id="%1$d"%2$s>%3$s</div>',
				$fid,
				$this->conditional_attr( $field ),
				wp_kses_post( $content )
			);
		}

		if ( 'hidden' === $type ) {
			return sprintf(
				'<input type="hidden" name="field_%1$d" value="%2$s">',
				$fid,
				esc_attr( isset( $field['default_value'] ) ? $field['default_value'] : '' )
			);
		}

		$label    = isset( $field['label'] ) ? $field['label'] : '';
		$required = ! empty( $field['required'] );
		$place    = isset( $field['placeholder'] ) ? $field['placeholder'] : '';
		$desc     = isset( $field['description'] ) ? $field['description'] : '';
		$name     = 'field_' . $fid;
		$dom_id   = 'phf-' . $fid;
		$choices  = isset( $field['choices'] ) && is_array( $field['choices'] ) ? $field['choices'] : [];
		$req_attr = $required ? 'required aria-required="true"' : '';
		$req_mark = $required ? ' <span class="phemightforms-required" aria-hidden="true">*</span>' : '';
		$registry = phemightforms()->fields;
		$size     = isset( $field['size'] ) && 'half' === $field['size'] ? ' phf-field-half' : '';
		$label_pos = isset( $field['label_position'] ) ? $field['label_position'] : '';

		ob_start();
		printf(
			'<div class="phemightforms-field phemightforms-field-%1$s%4$s phf-label-%5$s" data-field-id="%2$d"%3$s>',
			esc_attr( $type ),
			$fid, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- integer.
			$this->conditional_attr( $field ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally.
			esc_attr( $size ),
			esc_attr( $label_pos ? $label_pos : 'top' )
		);

		$hide_label = 'hidden' === $label_pos || 'payment_total' === $type;

		if ( ! $hide_label && '' !== $label ) {
			if ( in_array( $type, [ 'checkbox', 'radio', 'name', 'address', 'image_choice' ], true ) ) {
				echo '<span class="phemightforms-label">' . esc_html( $label ) . wp_kses_post( $req_mark ) . '</span>';
			} else {
				echo '<label class="phemightforms-label" for="' . esc_attr( $dom_id ) . '">' . esc_html( $label ) . wp_kses_post( $req_mark ) . '</label>';
			}
		}

		if ( $registry->is_composite( $type ) ) {
			echo $this->render_composite( $type, $name, $req_attr, $registry->composite_parts( $type ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo $this->render_simple( $type, $name, $dom_id, $place, $req_attr, $choices, $field ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( '' !== $desc ) {
			echo '<span class="phemightforms-description">' . esc_html( $desc ) . '</span>';
		}

		echo '</div>';

		return ob_get_clean();
	}

	/**
	 * Render a composite field (name, address) as several labelled sub-inputs.
	 *
	 * @param string $type     Field type.
	 * @param string $name     Base input name.
	 * @param string $req_attr Required attribute string.
	 * @param array  $parts    Sub-field keys.
	 * @return string
	 */
	private function render_composite( $type, $name, $req_attr, array $parts ) {
		$labels = [
			'first'   => __( 'First', 'phemightforms' ),
			'last'    => __( 'Last', 'phemightforms' ),
			'line1'   => __( 'Address Line 1', 'phemightforms' ),
			'line2'   => __( 'Address Line 2', 'phemightforms' ),
			'city'    => __( 'City', 'phemightforms' ),
			'state'   => __( 'State / Province', 'phemightforms' ),
			'zip'     => __( 'ZIP / Postal Code', 'phemightforms' ),
			'country' => __( 'Country', 'phemightforms' ),
		];

		$out = '<div class="phemightforms-composite phemightforms-composite-' . esc_attr( $type ) . '">';

		foreach ( $parts as $part ) {
			$sub_label = isset( $labels[ $part ] ) ? $labels[ $part ] : ucfirst( $part );
			// "line2" is optional even when the field is required.
			$sub_req = ( 'line2' === $part ) ? '' : $req_attr;
			$out    .= '<span class="phemightforms-sub phemightforms-sub-' . esc_attr( $part ) . '">';
			$out    .= sprintf(
				'<input type="text" name="%1$s" placeholder="%2$s" %3$s>',
				esc_attr( $name . '_' . $part ),
				esc_attr( $sub_label ),
				esc_attr( $sub_req )
			);
			$out    .= '</span>';
		}

		$out .= '</div>';

		return $out;
	}

	/**
	 * Render a simple (single-input) field.
	 *
	 * @param string $type     Field type.
	 * @param string $name     Input name.
	 * @param string $dom_id   Input DOM id.
	 * @param string $place    Placeholder.
	 * @param string $req_attr Required attribute string.
	 * @param array  $choices  Choice list.
	 * @param array  $field    Full field config (for type-specific extras).
	 * @return string
	 */
	private function render_simple( $type, $name, $dom_id, $place, $req_attr, array $choices, array $field = [] ) {
		switch ( $type ) {
			case 'consent':
				$consent_text = isset( $field['consent_text'] ) && '' !== $field['consent_text']
					? $field['consent_text']
					: __( 'I consent to having this website store my submitted information.', 'phemightforms' );
				return sprintf(
					'<label class="phemightforms-consent"><input type="checkbox" id="%1$s" name="%2$s" value="1" %3$s> <span>%4$s</span></label>',
					esc_attr( $dom_id ),
					esc_attr( $name ),
					esc_attr( $req_attr ),
					esc_html( $consent_text )
				);

			case 'signature':
				return sprintf(
					'<div class="phemightforms-signature">' .
					'<canvas class="phemightforms-sig-pad" width="400" height="150" aria-label="%1$s"></canvas>' .
					'<button type="button" class="phemightforms-sig-clear">%2$s</button>' .
					'<input type="hidden" name="%3$s" class="phemightforms-sig-input" value="" %4$s>' .
					'</div>',
					esc_attr__( 'Signature pad', 'phemightforms' ),
					esc_html__( 'Clear', 'phemightforms' ),
					esc_attr( $name ),
					esc_attr( $req_attr )
				);

			case 'repeater':
				$sub  = isset( $field['sub_label'] ) ? $field['sub_label'] : $place;
				$out  = '<div class="phemightforms-repeater">';
				$out .= '<div class="phemightforms-repeater-rows">';
				$out .= sprintf(
					'<div class="phemightforms-repeater-row"><input type="text" name="%1$s[]" placeholder="%2$s" %3$s><button type="button" class="phemightforms-repeater-remove" aria-label="%4$s">&times;</button></div>',
					esc_attr( $name ),
					esc_attr( $sub ),
					esc_attr( $req_attr ),
					esc_attr__( 'Remove', 'phemightforms' )
				);
				$out .= '</div>';
				$out .= '<button type="button" class="phemightforms-repeater-add">+ ' . esc_html__( 'Add another', 'phemightforms' ) . '</button>';
				$out .= '</div>';
				return $out;

			case 'textarea':
				return sprintf(
					'<textarea id="%1$s" name="%2$s" placeholder="%3$s" rows="5" %4$s></textarea>',
					esc_attr( $dom_id ),
					esc_attr( $name ),
					esc_attr( $place ),
					esc_attr( $req_attr )
				);

			case 'file':
				return sprintf(
					'<input type="file" id="%1$s" name="%2$s" %3$s>',
					esc_attr( $dom_id ),
					esc_attr( $name ),
					esc_attr( $req_attr )
				);

			case 'select':
				$out  = '<select id="' . esc_attr( $dom_id ) . '" name="' . esc_attr( $name ) . '" ' . esc_attr( $req_attr ) . '>';
				$out .= '<option value="">' . esc_html( $place ? $place : __( 'Select an option', 'phemightforms' ) ) . '</option>';
				foreach ( $choices as $choice ) {
					$out .= '<option value="' . esc_attr( $choice ) . '">' . esc_html( $choice ) . '</option>';
				}
				$out .= '</select>';
				return $out;

			case 'radio':
			case 'checkbox':
				$input_type = 'radio' === $type ? 'radio' : 'checkbox';
				$field_name = 'checkbox' === $type ? $name . '[]' : $name;
				$out        = '<div class="phemightforms-choices">';
				foreach ( $choices as $c_index => $choice ) {
					$choice_id = $dom_id . '-' . $c_index;
					$out      .= sprintf(
						'<label class="phemightforms-choice"><input type="%1$s" id="%2$s" name="%3$s" value="%4$s"> %5$s</label>',
						esc_attr( $input_type ),
						esc_attr( $choice_id ),
						esc_attr( $field_name ),
						esc_attr( $choice ),
						esc_html( $choice )
					);
				}
				$out .= '</div>';
				return $out;

			case 'image_choice':
				$out = '<div class="phemightforms-image-choices">';
				foreach ( $choices as $c_index => $choice ) {
					$parts    = array_pad( explode( '|', $choice, 2 ), 2, '' );
					$label    = trim( $parts[0] );
					$img      = trim( $parts[1] );
					$choice_id = $dom_id . '-' . $c_index;
					$out     .= '<label class="phemightforms-image-choice">';
					$out     .= sprintf( '<input type="radio" id="%1$s" name="%2$s" value="%3$s">', esc_attr( $choice_id ), esc_attr( $name ), esc_attr( $label ) );
					if ( $img ) {
						$out .= '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( $label ) . '">';
					}
					$out .= '<span>' . esc_html( $label ) . '</span></label>';
				}
				$out .= '</div>';
				return $out;

			case 'rating':
				$max = isset( $field['rating_max'] ) ? absint( $field['rating_max'] ) : 5;
				$max = max( 3, min( 10, $max ) );
				$out = '<div class="phemightforms-rating" role="radiogroup" aria-label="' . esc_attr__( 'Rating', 'phemightforms' ) . '">';
				for ( $i = 1; $i <= $max; $i++ ) {
					$out .= sprintf(
						'<label class="phemightforms-rating-star"><input type="radio" name="%1$s" value="%2$d" %3$s><span aria-hidden="true">★</span></label>',
						esc_attr( $name ),
						$i,
						esc_attr( $req_attr )
					);
				}
				$out .= '</div>';
				return $out;

			case 'country':
				$out  = '<select id="' . esc_attr( $dom_id ) . '" name="' . esc_attr( $name ) . '" ' . esc_attr( $req_attr ) . '>';
				$out .= '<option value="">' . esc_html__( 'Select country', 'phemightforms' ) . '</option>';
				foreach ( Countries::list() as $code => $country_label ) {
					$out .= '<option value="' . esc_attr( $code ) . '">' . esc_html( $country_label ) . '</option>';
				}
				$out .= '</select>';
				return $out;

			case 'payment_single':
				$price = Payments::to_amount( isset( $field['price'] ) ? $field['price'] : 0 );
				if ( ! empty( $field['user_price'] ) ) {
					return sprintf(
						'<div class="phemightforms-user-price"><span class="phemightforms-currency">%1$s</span><input type="number" id="%2$s" name="%3$s" min="0" step="0.01" value="%4$s" class="phemightforms-price-input" data-user-price="1" %5$s></div>',
						esc_html( Payments::symbol() ),
						esc_attr( $dom_id ),
						esc_attr( $name ),
						esc_attr( $price > 0 ? $price : '' ),
						esc_attr( $req_attr )
					);
				}
				return sprintf(
					'<div class="phemightforms-price" data-price="%1$s">%2$s<input type="hidden" name="%3$s" value="%4$s"></div>',
					esc_attr( $price ),
					esc_html( Payments::format( $price ) ),
					esc_attr( $name ),
					esc_attr( $price )
				);

			case 'payment_multiple':
				$out = '<div class="phemightforms-choices phemightforms-priced-choices">';
				foreach ( $choices as $c_index => $choice ) {
					list( $item_label, $item_price ) = Payments::parse_choice( $choice );
					$choice_id                       = $dom_id . '-' . $c_index;
					$out                            .= sprintf(
						'<label class="phemightforms-choice"><input type="radio" id="%1$s" name="%2$s" value="%3$s" data-price="%4$s" %5$s> %6$s <span class="phemightforms-choice-price">%7$s</span></label>',
						esc_attr( $choice_id ),
						esc_attr( $name ),
						esc_attr( $item_label ),
						esc_attr( $item_price ),
						esc_attr( $req_attr ),
						esc_html( $item_label ),
						esc_html( Payments::format( $item_price ) )
					);
				}
				$out .= '</div>';
				return $out;

			case 'payment_select':
				$out  = '<select id="' . esc_attr( $dom_id ) . '" name="' . esc_attr( $name ) . '" class="phemightforms-priced-select" ' . esc_attr( $req_attr ) . '>';
				$out .= '<option value="" data-price="0">' . esc_html( $place ? $place : __( 'Select an item', 'phemightforms' ) ) . '</option>';
				foreach ( $choices as $choice ) {
					list( $item_label, $item_price ) = Payments::parse_choice( $choice );
					$out                            .= sprintf(
						'<option value="%1$s" data-price="%2$s">%3$s · %4$s</option>',
						esc_attr( $item_label ),
						esc_attr( $item_price ),
						esc_html( $item_label ),
						esc_html( Payments::format( $item_price ) )
					);
				}
				$out .= '</select>';
				return $out;

			case 'payment_quantity':
				return sprintf(
					'<input type="number" id="%1$s" name="%2$s" value="1" min="1" max="999" step="1" class="phemightforms-quantity" %3$s>',
					esc_attr( $dom_id ),
					esc_attr( $name ),
					esc_attr( $req_attr )
				);

			case 'payment_coupon':
				return sprintf(
					'<div class="phemightforms-coupon"><input type="text" id="%1$s" name="%2$s" placeholder="%3$s" class="phemightforms-coupon-input" autocomplete="off"><button type="button" class="phemightforms-coupon-apply">%4$s</button><span class="phemightforms-coupon-msg" aria-live="polite"></span></div>',
					esc_attr( $dom_id ),
					esc_attr( $name ),
					esc_attr( $place ? $place : __( 'Enter coupon code', 'phemightforms' ) ),
					esc_html__( 'Apply', 'phemightforms' )
				);

			case 'payment_total':
				return sprintf(
					'<div class="phemightforms-total"><span class="phemightforms-total-label">%1$s</span><strong class="phemightforms-total-amount" data-total="0">%2$s</strong></div>',
					esc_html__( 'Total', 'phemightforms' ),
					esc_html( Payments::format( 0 ) )
				);

			default:
				$input_type = in_array( $type, [ 'email', 'number', 'url', 'date', 'time' ], true ) ? $type : ( 'phone' === $type ? 'tel' : 'text' );
				return sprintf(
					'<input type="%1$s" id="%2$s" name="%3$s" placeholder="%4$s" %5$s>',
					esc_attr( $input_type ),
					esc_attr( $dom_id ),
					esc_attr( $name ),
					esc_attr( $place ),
					esc_attr( $req_attr )
				);
		}
	}
}
