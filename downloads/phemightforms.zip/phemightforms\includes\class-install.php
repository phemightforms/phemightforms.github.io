<?php
/**
 * Activation and deactivation routines.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates the database schema and default options.
 */
class Install {

	/**
	 * Current schema version. Bump to trigger a table upgrade.
	 */
	const DB_VERSION = '2.1.0';

	/**
	 * Return the fully-prefixed entries table name.
	 *
	 * @return string
	 */
	public static function entries_table() {
		global $wpdb;

		return $wpdb->prefix . 'phemightforms_entries';
	}

	/**
	 * Run on activation.
	 */
	public static function activate() {
		self::create_tables();

		if ( false === get_option( 'phemightforms_settings' ) ) {
			add_option(
				'phemightforms_settings',
				[
					'from_name'     => get_bloginfo( 'name' ),
					'from_email'    => get_option( 'admin_email' ),
					'honeypot'      => 1,
					'store_entries' => 1,
				]
			);
		}

		update_option( 'phemightforms_db_version', self::DB_VERSION );

		if ( false === get_option( 'phemightforms_onboarding_done' ) ) {
			add_option( 'phemightforms_onboarding_done', 0 );
		}

		if ( ! wp_next_scheduled( Export::CRON_HOOK ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', Export::CRON_HOOK );
		}

		flush_rewrite_rules();
	}

	/**
	 * Run on deactivation.
	 */
	public static function deactivate() {
		$timestamp = wp_next_scheduled( Export::CRON_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, Export::CRON_HOOK );
		}

		flush_rewrite_rules();
	}

	/**
	 * Upgrade schema when the plugin version changes.
	 */
	public static function maybe_upgrade() {
		$installed = get_option( 'phemightforms_db_version', '0' );

		if ( version_compare( $installed, self::DB_VERSION, '>=' ) ) {
			return;
		}

		self::create_tables();

		if ( version_compare( $installed, '2.1.0', '<' ) ) {
			global $wpdb;
			$partial = $wpdb->prefix . 'phemightforms_partial';
			$wpdb->query( "DROP TABLE IF EXISTS {$partial}" ); // phpcs:ignore WordPress.DB
		}

		update_option( 'phemightforms_db_version', self::DB_VERSION );
	}

	/**
	 * Create or upgrade database tables.
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$entries         = self::entries_table();

		$sql_entries = "CREATE TABLE {$entries} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT(20) UNSIGNED NOT NULL,
			fields LONGTEXT NOT NULL,
			ip_address VARCHAR(100) DEFAULT '' NOT NULL,
			user_agent VARCHAR(255) DEFAULT '' NOT NULL,
			status VARCHAR(20) DEFAULT 'unread' NOT NULL,
			notes LONGTEXT NULL,
			tags VARCHAR(500) DEFAULT '' NOT NULL,
			created_at DATETIME DEFAULT '0000-00-00 00:00:00' NOT NULL,
			PRIMARY KEY  (id),
			KEY form_id (form_id),
			KEY status (status)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql_entries );
	}
}
