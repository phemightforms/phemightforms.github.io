<?php
/**
 * Dashboard overview screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Form;
use PhemightForms\Install;
use PhemightForms\Analytics;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shows plugin-wide stats, an activity chart, and quick actions.
 */
class Dashboard {

	/**
	 * Render the dashboard.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		global $wpdb;

		$table = Install::entries_table();
		$forms = Form::all();

		$total_entries = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB
		$week_entries  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) ) ) ); // phpcs:ignore WordPress.DB
		$today_entries = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", gmdate( 'Y-m-d 00:00:00' ) ) ); // phpcs:ignore WordPress.DB
		$unread        = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status != 'read'" ); // phpcs:ignore WordPress.DB

		$series = self::daily_series( 14 );
		$max    = max( array_merge( [ 1 ], array_values( $series ) ) );
		$totals = Analytics::site_totals();

		$recent = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 6" ); // phpcs:ignore WordPress.DB

		$onboarding = ! get_option( 'phemightforms_onboarding_done', 0 );

		$forms_url   = add_query_arg( [ 'page' => Admin::SLUG_FORMS ], admin_url( 'admin.php' ) );
		$new_url     = add_query_arg(
			[
				'page'   => Admin::SLUG_FORMS,
				'action' => 'new',
			],
			admin_url( 'admin.php' )
		);
		$entries_url = add_query_arg( [ 'page' => Admin::SLUG . '-entries' ], admin_url( 'admin.php' ) );
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'dashboard' ); ?>

			<div class="phf-page-body">
				<?php if ( $onboarding && ! $forms ) : ?>
					<div class="phf-onboarding">
						<h2><?php esc_html_e( 'Welcome! Let\'s create your first form', 'phemightforms' ); ?></h2>
						<ol>
							<li><?php esc_html_e( 'Click Create a Form and pick a template', 'phemightforms' ); ?></li>
							<li><?php esc_html_e( 'Drag fields onto the canvas and save', 'phemightforms' ); ?></li>
							<li><?php esc_html_e( 'Copy the shortcode onto any page', 'phemightforms' ); ?></li>
						</ol>
						<a href="<?php echo esc_url( $new_url ); ?>" class="phf-btn phf-btn-primary phf-btn-lg"><?php esc_html_e( 'Start onboarding', 'phemightforms' ); ?></a>
					</div>
				<?php endif; ?>

				<div class="phf-welcome">
					<div>
						<h2><?php esc_html_e( 'Welcome to PhemightForms', 'phemightforms' ); ?></h2>
						<p><?php esc_html_e( 'Build beautiful forms with drag & drop, collect entries, and track results, all from this dashboard.', 'phemightforms' ); ?></p>
					</div>
					<a href="<?php echo esc_url( $new_url ); ?>" class="phf-btn phf-btn-primary phf-btn-lg">
						<span class="dashicons dashicons-plus-alt2"></span>
						<?php esc_html_e( 'Create a Form', 'phemightforms' ); ?>
					</a>
				</div>

				<div class="phf-stat-grid">
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-amber"><span class="dashicons dashicons-feedback"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo esc_html( number_format_i18n( count( $forms ) ) ); ?></span>
							<span class="phf-stat-label"><?php esc_html_e( 'Forms', 'phemightforms' ); ?></span>
						</div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-blue"><span class="dashicons dashicons-email-alt"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo esc_html( number_format_i18n( $total_entries ) ); ?></span>
							<span class="phf-stat-label"><?php esc_html_e( 'Total Entries', 'phemightforms' ); ?></span>
						</div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-green"><span class="dashicons dashicons-chart-line"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo esc_html( number_format_i18n( $week_entries ) ); ?></span>
							<span class="phf-stat-label"><?php esc_html_e( 'Last 7 Days', 'phemightforms' ); ?></span>
						</div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-purple"><span class="dashicons dashicons-marker"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo esc_html( number_format_i18n( $unread ) ); ?></span>
							<span class="phf-stat-label"><?php esc_html_e( 'Unread Entries', 'phemightforms' ); ?></span>
						</div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-blue"><span class="dashicons dashicons-visibility"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo esc_html( number_format_i18n( $totals['views'] ) ); ?></span>
							<span class="phf-stat-label"><?php esc_html_e( 'Form Views', 'phemightforms' ); ?></span>
						</div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-green"><span class="dashicons dashicons-chart-pie"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo esc_html( $totals['rate'] ); ?>%</span>
							<span class="phf-stat-label"><?php esc_html_e( 'Conversion Rate', 'phemightforms' ); ?></span>
						</div>
					</div>
				</div>

				<div class="phf-dash-columns">
					<div class="phf-card-panel">
						<div class="phf-panel-head">
							<h3><?php esc_html_e( 'Entries in the last 14 days', 'phemightforms' ); ?></h3>
							<span class="phf-muted">
								<?php
								/* translators: %s: number of entries today. */
								printf( esc_html__( '%s today', 'phemightforms' ), esc_html( number_format_i18n( $today_entries ) ) );
								?>
							</span>
						</div>
						<div class="phf-chart" role="img" aria-label="<?php esc_attr_e( 'Daily entries chart', 'phemightforms' ); ?>">
							<?php foreach ( $series as $day => $count ) : ?>
								<div class="phf-chart-col" title="<?php echo esc_attr( $day . ': ' . $count ); ?>">
									<span class="phf-chart-bar" style="height:<?php echo esc_attr( max( 4, round( ( $count / $max ) * 100 ) ) ); ?>%"></span>
									<span class="phf-chart-day"><?php echo esc_html( mysql2date( 'j', $day . ' 00:00:00' ) ); ?></span>
								</div>
							<?php endforeach; ?>
						</div>
					</div>

					<div class="phf-card-panel">
						<div class="phf-panel-head">
							<h3><?php esc_html_e( 'Recent Entries', 'phemightforms' ); ?></h3>
							<a href="<?php echo esc_url( $entries_url ); ?>" class="phf-link"><?php esc_html_e( 'View all', 'phemightforms' ); ?></a>
						</div>
						<?php if ( ! $recent ) : ?>
							<p class="phf-muted phf-pad"><?php esc_html_e( 'No entries yet. Publish a form on a page to start collecting submissions.', 'phemightforms' ); ?></p>
						<?php else : ?>
							<ul class="phf-recent-list">
								<?php foreach ( $recent as $row ) : ?>
									<?php
									$form     = new Form( $row->form_id );
									$data     = json_decode( $row->fields, true );
									$preview  = ( is_array( $data ) && $data ) ? $data[0]['value'] : '';
									$view_url = add_query_arg(
										[
											'page'  => Admin::SLUG . '-entries',
											'entry' => $row->id,
										],
										admin_url( 'admin.php' )
									);
									?>
									<li>
										<a href="<?php echo esc_url( $view_url ); ?>">
											<span class="phf-recent-form">
												<?php echo esc_html( $form->exists() ? $form->title : __( '(deleted form)', 'phemightforms' ) ); ?>
												<?php if ( 'read' !== $row->status ) : ?>
													<span class="phf-badge phf-badge-new"><?php esc_html_e( 'New', 'phemightforms' ); ?></span>
												<?php endif; ?>
											</span>
											<span class="phf-recent-preview"><?php echo esc_html( wp_trim_words( (string) $preview, 8 ) ); ?></span>
											<span class="phf-recent-date"><?php echo esc_html( human_time_diff( strtotime( $row->created_at ), time() ) . ' ' . __( 'ago', 'phemightforms' ) ); ?></span>
										</a>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>

				<div class="phf-card-panel">
					<div class="phf-panel-head">
						<h3><?php esc_html_e( 'Your Forms', 'phemightforms' ); ?></h3>
						<a href="<?php echo esc_url( $forms_url ); ?>" class="phf-link"><?php esc_html_e( 'Manage forms', 'phemightforms' ); ?></a>
					</div>
					<?php if ( ! $forms ) : ?>
						<div class="phf-empty-state">
							<span class="dashicons dashicons-feedback"></span>
							<p><?php esc_html_e( 'You have not created any forms yet.', 'phemightforms' ); ?></p>
							<a href="<?php echo esc_url( $new_url ); ?>" class="phf-btn phf-btn-primary"><?php esc_html_e( 'Create Your First Form', 'phemightforms' ); ?></a>
						</div>
					<?php else : ?>
						<div class="phf-form-grid">
							<?php foreach ( array_slice( $forms, 0, 6 ) as $post ) : ?>
								<?php
								$form     = new Form( $post->ID );
								$count    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE form_id = %d", $post->ID ) ); // phpcs:ignore WordPress.DB
								$edit_url = add_query_arg(
									[
										'page'   => Admin::SLUG_FORMS,
										'action' => 'edit',
										'form'   => $post->ID,
									],
									admin_url( 'admin.php' )
								);
								?>
								<a class="phf-form-tile" href="<?php echo esc_url( $edit_url ); ?>">
									<span class="phf-form-tile-name"><?php echo esc_html( $post->post_title ); ?></span>
									<span class="phf-form-tile-meta">
										<?php
										/* translators: 1: field count, 2: entry count. */
										printf( esc_html__( '%1$d fields · %2$d entries', 'phemightforms' ), count( $form->get_fields() ), (int) $count );
										?>
									</span>
								</a>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Count entries per day for the last N days.
	 *
	 * @param int $days Number of days.
	 * @return array Map of Y-m-d => count.
	 */
	private static function daily_series( $days ) {
		global $wpdb;

		$table  = Install::entries_table();
		$since  = gmdate( 'Y-m-d 00:00:00', strtotime( '-' . ( $days - 1 ) . ' days' ) );
		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT created_at FROM {$table} WHERE created_at >= %s", $since ) ); // phpcs:ignore WordPress.DB
		$series = [];

		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$series[ gmdate( 'Y-m-d', strtotime( '-' . $i . ' days' ) ) ] = 0;
		}

		foreach ( $rows as $row ) {
			$day = substr( $row->created_at, 0, 10 );
			if ( isset( $series[ $day ] ) ) {
				$series[ $day ]++;
			}
		}

		return $series;
	}
}
