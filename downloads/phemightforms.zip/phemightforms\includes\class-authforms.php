<?php
/**
 * Front-end login / registration shortcodes.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers [phemightforms_login] and [phemightforms_register].
 */
class AuthForms {

	const OPTION_KEY = 'phemightforms_auth';

	/**
	 * Hook shortcodes and auth handlers.
	 */
	public function __construct() {
		add_shortcode( 'phemightforms_login', [ $this, 'shortcode_login' ] );
		add_shortcode( 'phemightforms_register', [ $this, 'shortcode_register' ] );
		add_action( 'init', [ $this, 'maybe_handle_post' ] );
	}

	/**
	 * Read auth settings.
	 *
	 * @return array
	 */
	public static function settings() {
		$defaults = [
			'login_enabled'    => 1,
			'register_enabled' => 1,
		];
		$data = get_option( self::OPTION_KEY, [] );

		return wp_parse_args( is_array( $data ) ? $data : [], $defaults );
	}

	/**
	 * Persist auth settings.
	 *
	 * @param array $data Settings.
	 */
	public static function save_settings( array $data ) {
		$current = self::settings();
		update_option(
			self::OPTION_KEY,
			[
				'login_enabled'    => ! empty( $data['login_enabled'] ) ? 1 : 0,
				'register_enabled' => ! empty( $data['register_enabled'] ) ? 1 : 0,
			],
			false
		);
		unset( $current );
	}

	/**
	 * Process login / register POSTs from shortcode forms.
	 */
	public function maybe_handle_post() {
		if ( empty( $_POST['phf_auth_action'] ) ) {
			return;
		}

		$action = sanitize_key( wp_unslash( $_POST['phf_auth_action'] ) );

		if ( 'login' === $action ) {
			$this->handle_login();
		} elseif ( 'register' === $action ) {
			$this->handle_register();
		}
	}

	/**
	 * Login shortcode output.
	 *
	 * @return string
	 */
	public function shortcode_login() {
		$settings = self::settings();

		if ( empty( $settings['login_enabled'] ) ) {
			return '<p class="phf-auth-disabled">' . esc_html__( 'The login shortcode is disabled in PhemightForms settings.', 'phemightforms' ) . '</p>';
		}

		if ( is_user_logged_in() ) {
			return '<p class="phf-auth-note">' . esc_html__( 'You are already logged in.', 'phemightforms' ) . '</p>';
		}

		$error = isset( $_GET['phf_auth_error'] ) ? sanitize_text_field( wp_unslash( $_GET['phf_auth_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		ob_start();
		?>
		<div class="phf-auth-form phf-auth-login">
			<?php if ( $error ) : ?>
				<p class="phf-auth-error"><?php echo esc_html( $error ); ?></p>
			<?php endif; ?>
			<form method="post">
				<?php wp_nonce_field( 'phemightforms_auth_login' ); ?>
				<input type="hidden" name="phf_auth_action" value="login">
				<p>
					<label for="phf-auth-log"><?php esc_html_e( 'Username or email', 'phemightforms' ); ?></label>
					<input type="text" id="phf-auth-log" name="log" required autocomplete="username">
				</p>
				<p>
					<label for="phf-auth-pwd"><?php esc_html_e( 'Password', 'phemightforms' ); ?></label>
					<input type="password" id="phf-auth-pwd" name="pwd" required autocomplete="current-password">
				</p>
				<p>
					<label><input type="checkbox" name="rememberme" value="forever"> <?php esc_html_e( 'Remember me', 'phemightforms' ); ?></label>
				</p>
				<p><button type="submit" class="phf-auth-submit"><?php esc_html_e( 'Log in', 'phemightforms' ); ?></button></p>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Registration shortcode output.
	 *
	 * @return string
	 */
	public function shortcode_register() {
		$settings = self::settings();

		if ( empty( $settings['register_enabled'] ) ) {
			return '<p class="phf-auth-disabled">' . esc_html__( 'The registration shortcode is disabled in PhemightForms settings.', 'phemightforms' ) . '</p>';
		}

		if ( ! get_option( 'users_can_register' ) ) {
			return '<p class="phf-auth-disabled">' . esc_html__( 'User registration is disabled in WordPress settings.', 'phemightforms' ) . '</p>';
		}

		if ( is_user_logged_in() ) {
			return '<p class="phf-auth-note">' . esc_html__( 'You are already logged in.', 'phemightforms' ) . '</p>';
		}

		$error   = isset( $_GET['phf_auth_error'] ) ? sanitize_text_field( wp_unslash( $_GET['phf_auth_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$success = isset( $_GET['phf_auth_registered'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		ob_start();
		?>
		<div class="phf-auth-form phf-auth-register">
			<?php if ( $success ) : ?>
				<p class="phf-auth-success"><?php esc_html_e( 'Account created. You can log in now.', 'phemightforms' ); ?></p>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<p class="phf-auth-error"><?php echo esc_html( $error ); ?></p>
			<?php endif; ?>
			<form method="post">
				<?php wp_nonce_field( 'phemightforms_auth_register' ); ?>
				<input type="hidden" name="phf_auth_action" value="register">
				<p>
					<label for="phf-auth-user"><?php esc_html_e( 'Username', 'phemightforms' ); ?></label>
					<input type="text" id="phf-auth-user" name="user_login" required autocomplete="username">
				</p>
				<p>
					<label for="phf-auth-email"><?php esc_html_e( 'Email', 'phemightforms' ); ?></label>
					<input type="email" id="phf-auth-email" name="user_email" required autocomplete="email">
				</p>
				<p>
					<label for="phf-auth-pass1"><?php esc_html_e( 'Password', 'phemightforms' ); ?></label>
					<input type="password" id="phf-auth-pass1" name="user_pass" required autocomplete="new-password" minlength="6">
				</p>
				<p><button type="submit" class="phf-auth-submit"><?php esc_html_e( 'Register', 'phemightforms' ); ?></button></p>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Handle front-end login.
	 */
	private function handle_login() {
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'phemightforms_auth_login' ) ) {
			return;
		}

		$creds = [
			'user_login'    => isset( $_POST['log'] ) ? sanitize_text_field( wp_unslash( $_POST['log'] ) ) : '',
			'user_password' => isset( $_POST['pwd'] ) ? (string) wp_unslash( $_POST['pwd'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'remember'      => ! empty( $_POST['rememberme'] ),
		];

		$user = wp_signon( $creds, is_ssl() );

		if ( is_wp_error( $user ) ) {
			wp_safe_redirect( add_query_arg( 'phf_auth_error', rawurlencode( $user->get_error_message() ), wp_get_referer() ? wp_get_referer() : home_url() ) );
			exit;
		}

		wp_safe_redirect( apply_filters( 'phemightforms_login_redirect', admin_url(), $user ) );
		exit;
	}

	/**
	 * Handle front-end registration.
	 */
	private function handle_register() {
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'phemightforms_auth_register' ) ) {
			return;
		}

		$redirect = wp_get_referer() ? wp_get_referer() : home_url();

		if ( ! get_option( 'users_can_register' ) ) {
			wp_safe_redirect( add_query_arg( 'phf_auth_error', rawurlencode( __( 'Registration is disabled.', 'phemightforms' ) ), $redirect ) );
			exit;
		}

		$login = isset( $_POST['user_login'] ) ? sanitize_user( wp_unslash( $_POST['user_login'] ), true ) : '';
		$email = isset( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '';
		$pass  = isset( $_POST['user_pass'] ) ? (string) wp_unslash( $_POST['user_pass'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		$user_id = wp_create_user( $login, $pass, $email );

		if ( is_wp_error( $user_id ) ) {
			wp_safe_redirect( add_query_arg( 'phf_auth_error', rawurlencode( $user_id->get_error_message() ), $redirect ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'phf_auth_registered', '1', $redirect ) );
		exit;
	}

	/**
	 * Ensure starter login/register Form posts exist; return their IDs.
	 *
	 * @return array{login:int,register:int}
	 */
	public static function ensure_starter_forms() {
		$ids = [
			'login'    => (int) get_option( 'phemightforms_auth_login_form', 0 ),
			'register' => (int) get_option( 'phemightforms_auth_register_form', 0 ),
		];

		if ( $ids['login'] && ( new Form( $ids['login'] ) )->exists() && $ids['register'] && ( new Form( $ids['register'] ) )->exists() ) {
			return $ids;
		}

		if ( ! $ids['login'] || ! ( new Form( $ids['login'] ) )->exists() ) {
			$config = Form::default_config();
			$config['fields'] = [
				[
					'id'          => 1,
					'type'        => 'text',
					'label'       => __( 'Username or email', 'phemightforms' ),
					'required'    => 1,
					'placeholder' => '',
				],
				[
					'id'          => 2,
					'type'        => 'text',
					'label'       => __( 'Password', 'phemightforms' ),
					'required'    => 1,
					'placeholder' => '',
				],
			];
			$config['_next_id'] = 3;
			$config['settings']['submit_text']  = __( 'Log in', 'phemightforms' );
			$config['settings']['confirmation'] = __( 'Welcome back!', 'phemightforms' );

			$ids['login'] = Form::save( __( 'Login Form (Starter)', 'phemightforms' ), $config, 0 );
			update_option( 'phemightforms_auth_login_form', $ids['login'], false );
		}

		if ( ! $ids['register'] || ! ( new Form( $ids['register'] ) )->exists() ) {
			$config = Form::default_config();
			$config['fields'] = [
				[
					'id'       => 1,
					'type'     => 'text',
					'label'    => __( 'Username', 'phemightforms' ),
					'required' => 1,
				],
				[
					'id'       => 2,
					'type'     => 'email',
					'label'    => __( 'Email', 'phemightforms' ),
					'required' => 1,
				],
				[
					'id'       => 3,
					'type'     => 'text',
					'label'    => __( 'Password', 'phemightforms' ),
					'required' => 1,
				],
			];
			$config['_next_id'] = 4;
			$config['settings']['submit_text']  = __( 'Register', 'phemightforms' );
			$config['settings']['confirmation'] = __( 'Account created. You can log in now.', 'phemightforms' );

			$ids['register'] = Form::save( __( 'Registration Form (Starter)', 'phemightforms' ), $config, 0 );
			update_option( 'phemightforms_auth_register_form', $ids['register'], false );
		}

		return $ids;
	}
}
