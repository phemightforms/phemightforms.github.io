<?php
/**
 * Privacy Compliance admin screen: GDPR settings, data audit, and
 * personal data request tools.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Install;
use PhemightForms\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and saves the Privacy Compliance page.
 */
class PrivacyPage {

	/**
	 * Hook the save and action handlers.
	 */
	public function __construct() {
		add_action( 'admin_post_phemightforms_save_privacy', [ $this, 'handle_save' ] );
		add_action( 'admin_post_phemightforms_privacy_action', [ $this, 'handle_action' ] );
	}

	/**
	 * Handle GDPR JSON export before any page output (privacy page form).
	 */
	public static function maybe_export() {
		GDPR::maybe_export();
	}

	/**
	 * Persist the privacy settings.
	 */
	public function handle_save() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_privacy' );

		$settings = get_option( 'phemightforms_settings', [] );

		$settings['privacy_disable_ip']   = ! empty( $_POST['privacy_disable_ip'] ) ? 1 : 0;
		$settings['privacy_anonymize_ip'] = ! empty( $_POST['privacy_anonymize_ip'] ) ? 1 : 0;
		$settings['privacy_disable_ua']   = ! empty( $_POST['privacy_disable_ua'] ) ? 1 : 0;
		$settings['store_entries']        = ! empty( $_POST['store_entries'] ) ? 1 : 0;
		$settings['entry_retention_days'] = isset( $_POST['entry_retention_days'] ) ? absint( $_POST['entry_retention_days'] ) : 0;

		update_option( 'phemightforms_settings', $settings );

		wp_safe_redirect(
			add_query_arg(
				[
					'page'  => Admin::SLUG . '-privacy',
					'saved' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * One-off maintenance actions: anonymize existing data or purge old entries.
	 */
	public function handle_action() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_privacy_action' );

		global $wpdb;

		$table  = Install::entries_table();
		$action = isset( $_POST['privacy_action'] ) ? sanitize_key( wp_unslash( $_POST['privacy_action'] ) ) : '';
		$done   = '';

		if ( 'anonymize' === $action ) {
			$wpdb->query( "UPDATE {$table} SET ip_address = '', user_agent = ''" ); // phpcs:ignore WordPress.DB
			$done = 'anonymized';
		} elseif ( 'purge_old' === $action ) {
			$days = (int) Plugin::get_option( 'entry_retention_days', 0 );

			if ( $days > 0 ) {
				$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB
				$done = 'purged';
			} else {
				$done = 'noretention';
			}
		}

		wp_safe_redirect(
			add_query_arg(
				[
					'page' => Admin::SLUG . '-privacy',
					'done' => $done,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render the Privacy Compliance page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		global $wpdb;

		$table    = Install::entries_table();
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB
		$with_ip  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE ip_address <> ''" ); // phpcs:ignore WordPress.DB
		$oldest   = $wpdb->get_var( "SELECT MIN(created_at) FROM {$table}" ); // phpcs:ignore WordPress.DB
		$settings = get_option( 'phemightforms_settings', [] );
		$get      = static function ( $key, $default = '' ) use ( $settings ) {
			return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
		};

		$retention = (int) $get( 'entry_retention_days', 0 );
		$done      = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// GDPR export/delete tool messages (form posts back to this page).
		$tool_message = '';
		if ( isset( $_POST['phf_gdpr_action'] ) && check_admin_referer( 'phemightforms_gdpr' ) ) {
			$email  = isset( $_POST['phf_gdpr_email'] ) ? sanitize_email( wp_unslash( $_POST['phf_gdpr_email'] ) ) : '';
			$action = sanitize_key( wp_unslash( $_POST['phf_gdpr_action'] ) );

			if ( ! is_email( $email ) ) {
				$tool_message = 'error:' . __( 'Please enter a valid email address.', 'phemightforms' );
			} elseif ( 'delete' === $action ) {
				$count        = self::delete_by_email( $email );
				$tool_message = 'success:' . sprintf(
					/* translators: %d: number of entries removed. */
					__( 'Removed %d entries containing that email.', 'phemightforms' ),
					$count
				);
			}
		}
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'privacy' ); ?>

			<div class="phf-page-body phf-privacy-page">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Privacy Compliance', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'GDPR and CCPA tools: control what personal data your forms store, honor data requests, and clean up old submissions automatically.', 'phemightforms' ); ?></p>
					</div>
				</div>

				<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Privacy settings saved.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<?php if ( 'anonymized' === $done ) : ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'IP addresses and browser details were removed from all stored entries.', 'phemightforms' ); ?></div>
				<?php elseif ( 'purged' === $done ) : ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Entries older than the retention window were deleted.', 'phemightforms' ); ?></div>
				<?php elseif ( 'noretention' === $done ) : ?>
					<div class="phf-notice phf-notice-error"><span class="dashicons dashicons-warning"></span> <?php esc_html_e( 'Set a retention period (days) and save first, then run the cleanup.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<?php if ( $tool_message ) : ?>
					<?php list( $type, $text ) = array_pad( explode( ':', $tool_message, 2 ), 2, '' ); ?>
					<div class="phf-notice phf-notice-<?php echo 'error' === $type ? 'error' : 'success'; ?>"><?php echo esc_html( $text ); ?></div>
				<?php endif; ?>

				<div class="phf-stat-grid">
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-blue"><span class="dashicons dashicons-database"></span></span>
						<div><span class="phf-stat-number"><?php echo esc_html( number_format_i18n( $total ) ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Stored Entries', 'phemightforms' ); ?></span></div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-amber"><span class="dashicons dashicons-location"></span></span>
						<div><span class="phf-stat-number"><?php echo esc_html( number_format_i18n( $with_ip ) ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Entries With IP Address', 'phemightforms' ); ?></span></div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-green"><span class="dashicons dashicons-shield-alt"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo $retention > 0 ? esc_html( sprintf( /* translators: %d: days */ __( '%d days', 'phemightforms' ), $retention ) ) : esc_html__( 'Off', 'phemightforms' ); ?></span>
							<span class="phf-stat-label"><?php esc_html_e( 'Auto Delete Retention', 'phemightforms' ); ?></span>
						</div>
					</div>
					<div class="phf-stat-card">
						<span class="phf-stat-icon phf-tint-gold"><span class="dashicons dashicons-calendar-alt"></span></span>
						<div>
							<span class="phf-stat-number"><?php echo $oldest ? esc_html( mysql2date( get_option( 'date_format' ), $oldest ) ) : esc_html__( 'None', 'phemightforms' ); ?></span>
							<span class="phf-stat-label"><?php esc_html_e( 'Oldest Entry', 'phemightforms' ); ?></span>
						</div>
					</div>
				</div>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'phemightforms_privacy' ); ?>
					<input type="hidden" name="action" value="phemightforms_save_privacy">

					<div class="phf-card-panel phf-settings-card">
						<div class="phf-panel-head">
							<h3><span class="dashicons dashicons-privacy"></span> <?php esc_html_e( 'Data Minimization', 'phemightforms' ); ?></h3>
							<span class="phf-muted"><?php esc_html_e( 'Collect only what you need. These settings apply to every new submission.', 'phemightforms' ); ?></span>
						</div>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label><?php esc_html_e( 'Store submissions', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Keep a copy of each submission in the Entries screen. Turn off to only send email notifications.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control">
								<label class="phf-toggle"><input type="checkbox" name="store_entries" value="1" <?php checked( $get( 'store_entries', 1 ) ); ?>><span class="phf-toggle-track"></span></label>
							</div>
						</div>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label><?php esc_html_e( 'Don\'t store IP addresses', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'New entries are saved without the visitor\'s IP address.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control">
								<label class="phf-toggle"><input type="checkbox" name="privacy_disable_ip" value="1" <?php checked( $get( 'privacy_disable_ip', 0 ) ); ?>><span class="phf-toggle-track"></span></label>
							</div>
						</div>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label><?php esc_html_e( 'Anonymize IP addresses', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Mask the last part of the IP (e.g. 192.168.1.0) so it can\'t identify a person. Ignored when IP storage is off.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control">
								<label class="phf-toggle"><input type="checkbox" name="privacy_anonymize_ip" value="1" <?php checked( $get( 'privacy_anonymize_ip', 0 ) ); ?>><span class="phf-toggle-track"></span></label>
							</div>
						</div>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label><?php esc_html_e( 'Don\'t store browser details', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'New entries are saved without the visitor\'s browser user agent string.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control">
								<label class="phf-toggle"><input type="checkbox" name="privacy_disable_ua" value="1" <?php checked( $get( 'privacy_disable_ua', 0 ) ); ?>><span class="phf-toggle-track"></span></label>
							</div>
						</div>
					</div>

					<div class="phf-card-panel phf-settings-card">
						<div class="phf-panel-head">
							<h3><span class="dashicons dashicons-backup"></span> <?php esc_html_e( 'Data Retention', 'phemightforms' ); ?></h3>
							<span class="phf-muted"><?php esc_html_e( 'Automatically delete old submissions on a daily schedule.', 'phemightforms' ); ?></span>
						</div>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-privacy-retention"><?php esc_html_e( 'Delete entries after (days)', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Entries older than this are removed automatically. Set to 0 to keep entries forever.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control">
								<input type="number" id="phf-privacy-retention" name="entry_retention_days" min="0" value="<?php echo esc_attr( $retention ); ?>">
							</div>
						</div>
					</div>

					<div class="phf-settings-actions">
						<button type="submit" class="phf-btn phf-btn-primary phf-btn-lg"><?php esc_html_e( 'Save Privacy Settings', 'phemightforms' ); ?></button>
					</div>
				</form>

				<div class="phf-card-panel phf-settings-card">
					<div class="phf-panel-head">
						<h3><span class="dashicons dashicons-id-alt"></span> <?php esc_html_e( 'Right to Access & Right to Erasure', 'phemightforms' ); ?></h3>
						<span class="phf-muted"><?php esc_html_e( 'Handle "send me my data" and "delete my data" requests: find every entry containing an email address, then export it as JSON or erase it.', 'phemightforms' ); ?></span>
					</div>
					<form method="post">
						<?php wp_nonce_field( 'phemightforms_gdpr' ); ?>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-gdpr-email"><?php esc_html_e( 'Requester\'s email address', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Searches every stored entry across all forms.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-control phf-privacy-request">
								<input type="email" id="phf-gdpr-email" name="phf_gdpr_email" placeholder="person@example.com" required>
								<button type="submit" name="phf_gdpr_action" value="export" class="phf-btn phf-btn-ghost"><span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Export (JSON)', 'phemightforms' ); ?></button>
								<button type="submit" name="phf_gdpr_action" value="delete" class="phf-btn phf-btn-ghost phf-btn-danger" onclick="return confirm('<?php echo esc_js( __( 'Permanently delete all entries containing this email?', 'phemightforms' ) ); ?>');"><span class="dashicons dashicons-trash"></span> <?php esc_html_e( 'Erase', 'phemightforms' ); ?></button>
							</div>
						</div>
					</form>
					<div class="phf-card-body phf-card-body-divider">
						<p class="phf-privacy-wp-tools">
						<?php
						printf(
							/* translators: 1: export tool link, 2: erase tool link */
							esc_html__( 'PhemightForms entries are also included in WordPress\' own %1$s and %2$s tools.', 'phemightforms' ),
							'<a href="' . esc_url( admin_url( 'export-personal-data.php' ) ) . '">' . esc_html__( 'Export Personal Data', 'phemightforms' ) . '</a>',
							'<a href="' . esc_url( admin_url( 'erase-personal-data.php' ) ) . '">' . esc_html__( 'Erase Personal Data', 'phemightforms' ) . '</a>'
						);
						?>
						</p>
					</div>
				</div>

				<div class="phf-card-panel phf-settings-card">
					<div class="phf-panel-head">
						<h3><span class="dashicons dashicons-admin-tools"></span> <?php esc_html_e( 'Cleanup Tools', 'phemightforms' ); ?></h3>
						<span class="phf-muted"><?php esc_html_e( 'One click maintenance for data you already collected.', 'phemightforms' ); ?></span>
					</div>
					<div class="phf-setting-row">
						<div class="phf-setting-label">
							<label><?php esc_html_e( 'Anonymize existing entries', 'phemightforms' ); ?></label>
							<p><?php esc_html_e( 'Remove the stored IP address and browser details from every entry already in the database. Form answers are kept.', 'phemightforms' ); ?></p>
						</div>
						<div class="phf-setting-control">
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'phemightforms_privacy_action' ); ?>
								<input type="hidden" name="action" value="phemightforms_privacy_action">
								<input type="hidden" name="privacy_action" value="anonymize">
								<button type="submit" class="phf-btn phf-btn-ghost" onclick="return confirm('<?php echo esc_js( __( 'Remove IP addresses and browser details from all stored entries?', 'phemightforms' ) ); ?>');"><span class="dashicons dashicons-hidden"></span> <?php esc_html_e( 'Anonymize All Entries', 'phemightforms' ); ?></button>
							</form>
						</div>
					</div>
					<div class="phf-setting-row">
						<div class="phf-setting-label">
							<label><?php esc_html_e( 'Purge old entries now', 'phemightforms' ); ?></label>
							<p><?php esc_html_e( 'Immediately delete every entry older than the retention window above, without waiting for the daily schedule.', 'phemightforms' ); ?></p>
						</div>
						<div class="phf-setting-control">
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'phemightforms_privacy_action' ); ?>
								<input type="hidden" name="action" value="phemightforms_privacy_action">
								<input type="hidden" name="privacy_action" value="purge_old">
								<button type="submit" class="phf-btn phf-btn-ghost phf-btn-danger" onclick="return confirm('<?php echo esc_js( __( 'Delete all entries older than the retention window?', 'phemightforms' ) ); ?>');"><span class="dashicons dashicons-trash"></span> <?php esc_html_e( 'Run Cleanup Now', 'phemightforms' ); ?></button>
							</form>
						</div>
					</div>
				</div>

				<div class="phf-card-panel phf-settings-card">
					<div class="phf-panel-head">
						<h3><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Consent Checklist', 'phemightforms' ); ?></h3>
						<span class="phf-muted"><?php esc_html_e( 'Recommended steps for GDPR friendly forms.', 'phemightforms' ); ?></span>
					</div>
					<div class="phf-card-body">
						<ul class="phf-privacy-checklist">
						<li><span class="dashicons dashicons-editor-help"></span><span><?php esc_html_e( 'Add a GDPR Agreement (consent) field from the builder to any form that collects personal data.', 'phemightforms' ); ?></span></li>
						<li><span class="dashicons dashicons-editor-help"></span><span><?php esc_html_e( 'Link your privacy policy near the submit button so visitors know how their data is used.', 'phemightforms' ); ?></span></li>
						<li><span class="dashicons dashicons-editor-help"></span><span><?php esc_html_e( 'Turn on IP anonymization or disable IP storage unless you need it for spam prevention.', 'phemightforms' ); ?></span></li>
						<li><span class="dashicons dashicons-editor-help"></span><span><?php esc_html_e( 'Set a retention window so old submissions are cleaned up automatically.', 'phemightforms' ); ?></span></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Delete entries containing the given email.
	 *
	 * @param string $email Email to match.
	 * @return int Number deleted.
	 */
	private static function delete_by_email( $email ) {
		global $wpdb;

		$table = Install::entries_table();
		$like  = '%' . $wpdb->esc_like( $email ) . '%';
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id FROM {$table} WHERE fields LIKE %s", $like ) ); // phpcs:ignore WordPress.DB
		$count = 0;

		foreach ( $rows as $row ) {
			$wpdb->delete( $table, [ 'id' => $row->id ], [ '%d' ] ); // phpcs:ignore WordPress.DB
			$count++;
		}

		return $count;
	}
}
