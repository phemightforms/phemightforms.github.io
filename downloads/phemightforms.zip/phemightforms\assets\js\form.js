/**
 * PhemightForms front-end runtime.
 *
 * Enhances every .phemightforms-form with:
 *  - AJAX submission with inline validation,
 *  - conditional logic (show/hide fields based on other answers),
 *  - multi-page navigation with a progress bar.
 */
( function () {
	'use strict';

	var data = window.PhemightFormsData || {};
	var i18n = data.i18n || {};

	/* --------------------------------------------------------------------- */
	/* Value reading                                                         */
	/* --------------------------------------------------------------------- */

	function fieldElById( form, id ) {
		return form.querySelector( '.phemightforms-field[data-field-id="' + id + '"]' );
	}

	function valueOf( fieldEl ) {
		if ( ! fieldEl ) {
			return '';
		}

		var radios = fieldEl.querySelectorAll( 'input[type="radio"]' );
		if ( radios.length ) {
			var checked = fieldEl.querySelector( 'input[type="radio"]:checked' );
			return checked ? checked.value : '';
		}

		var checks = fieldEl.querySelectorAll( 'input[type="checkbox"]' );
		if ( checks.length ) {
			var vals = [];
			checks.forEach( function ( c ) {
				if ( c.checked ) {
					vals.push( c.value );
				}
			} );
			return vals.join( ', ' );
		}

		var select = fieldEl.querySelector( 'select' );
		if ( select ) {
			return select.value;
		}

		// Text / textarea / composite: join all inputs.
		var inputs = fieldEl.querySelectorAll( 'input, textarea' );
		var parts = [];
		inputs.forEach( function ( el ) {
			if ( el.value && el.type !== 'file' ) {
				parts.push( el.value );
			}
		} );
		return parts.join( ', ' );
	}

	/* --------------------------------------------------------------------- */
	/* Conditional logic                                                     */
	/* --------------------------------------------------------------------- */

	function evalRule( form, rule ) {
		var target = valueOf( fieldElById( form, rule.field ) );
		var value = rule.value || '';

		switch ( rule.operator ) {
			case 'is':
				return target === value;
			case 'is_not':
				return target !== value;
			case 'contains':
				return value !== '' && target.toLowerCase().indexOf( value.toLowerCase() ) !== -1;
			case 'empty':
				return target.trim() === '';
			case 'not_empty':
				return target.trim() !== '';
			default:
				return false;
		}
	}

	function isVisibleByLogic( form, cond ) {
		if ( ! cond || ! cond.rules || ! cond.rules.length ) {
			return true;
		}

		var results = cond.rules.map( function ( rule ) {
			return evalRule( form, rule );
		} );

		var matched = cond.logic === 'or'
			? results.indexOf( true ) !== -1
			: results.indexOf( false ) === -1;

		return cond.action === 'hide' ? ! matched : matched;
	}

	function applyLogic( form ) {
		form.querySelectorAll( '[data-conditional]' ).forEach( function ( fieldEl ) {
			var cond;
			try {
				cond = JSON.parse( fieldEl.getAttribute( 'data-conditional' ) );
			} catch ( e ) {
				return;
			}

			var visible = isVisibleByLogic( form, cond );
			fieldEl.classList.toggle( 'phf-logic-hidden', ! visible );

			// Disable inputs in hidden fields so they are excluded from submission.
			fieldEl.querySelectorAll( 'input, select, textarea' ).forEach( function ( el ) {
				el.disabled = ! visible;
			} );
		} );
	}

	/* --------------------------------------------------------------------- */
	/* Multi-page navigation                                                 */
	/* --------------------------------------------------------------------- */

	function pages( form ) {
		return Array.prototype.slice.call( form.querySelectorAll( '.phemightforms-page' ) );
	}

	function currentPageIndex( form ) {
		var all = pages( form );
		for ( var i = 0; i < all.length; i++ ) {
			if ( all[ i ].classList.contains( 'is-active' ) ) {
				return i;
			}
		}
		return 0;
	}

	function showPage( form, index ) {
		var all = pages( form );
		all.forEach( function ( page, i ) {
			var active = i === index;
			page.classList.toggle( 'is-active', active );
			page.hidden = ! active;
		} );

		var prev = form.querySelector( '.phemightforms-prev' );
		var next = form.querySelector( '.phemightforms-next' );
		var submit = form.querySelector( '.phemightforms-submit' );

		if ( prev ) {
			prev.hidden = index === 0;
		}
		if ( next ) {
			next.hidden = index >= all.length - 1;
		}
		if ( submit ) {
			submit.hidden = index < all.length - 1;
		}

		updateProgress( form, index, all.length );
	}

	function updateProgress( form, index, total ) {
		var bar = form.querySelector( '.phemightforms-progress-bar' );
		var text = form.querySelector( '.phemightforms-progress-text' );
		if ( bar ) {
			bar.style.width = Math.round( ( ( index + 1 ) / total ) * 100 ) + '%';
		}
		if ( text ) {
			text.textContent = ( i18n.step || 'Step' ) + ' ' + ( index + 1 ) + ' ' + ( i18n.of || 'of' ) + ' ' + total;
		}
	}

	/* --------------------------------------------------------------------- */
	/* Validation (JS-driven, so hidden pages never block)                   */
	/* --------------------------------------------------------------------- */

	function clearErrors( scope ) {
		scope.querySelectorAll( '.phemightforms-field-error' ).forEach( function ( el ) {
			el.remove();
		} );
		scope.querySelectorAll( '.has-error' ).forEach( function ( el ) {
			el.classList.remove( 'has-error' );
		} );
	}

	function validateScope( scope ) {
		var ok = true;
		var firstInvalid = null;

		scope.querySelectorAll( '.phemightforms-field' ).forEach( function ( fieldEl ) {
			if ( fieldEl.classList.contains( 'phf-logic-hidden' ) ) {
				return;
			}
			fieldEl.querySelectorAll( 'input, select, textarea' ).forEach( function ( el ) {
				if ( el.disabled || el.type === 'hidden' ) {
					return;
				}
				if ( ! el.checkValidity() ) {
					ok = false;
					if ( ! fieldEl.classList.contains( 'has-error' ) ) {
						fieldEl.classList.add( 'has-error' );
						var msg = document.createElement( 'span' );
						msg.className = 'phemightforms-field-error';
						msg.textContent = el.validationMessage;
						fieldEl.appendChild( msg );
					}
					if ( ! firstInvalid ) {
						firstInvalid = el;
					}
				}
			} );
		} );

		return { ok: ok, firstInvalid: firstInvalid };
	}

	/* --------------------------------------------------------------------- */
	/* Server-side error display                                             */
	/* --------------------------------------------------------------------- */

	function showFieldErrors( form, errors ) {
		Object.keys( errors ).forEach( function ( key ) {
			var input = form.querySelector( '[name="' + key + '"], [name="' + key + '[]"], [name^="' + key + '_"]' );
			if ( ! input ) {
				return;
			}
			var wrapper = input.closest( '.phemightforms-field' );
			if ( ! wrapper || wrapper.classList.contains( 'has-error' ) ) {
				return;
			}
			wrapper.classList.add( 'has-error' );
			var msg = document.createElement( 'span' );
			msg.className = 'phemightforms-field-error';
			msg.textContent = errors[ key ];
			wrapper.appendChild( msg );
		} );
	}

	function setAlert( form, message, type ) {
		var alert = form.querySelector( '.phemightforms-alert' );
		if ( ! alert ) {
			return;
		}
		alert.textContent = message;
		alert.className = 'phemightforms-alert phemightforms-alert-' + type;
		alert.hidden = false;
	}

	/* --------------------------------------------------------------------- */
	/* Submission                                                            */
	/* --------------------------------------------------------------------- */

	function submitForm( form ) {
		clearErrors( form );

		var check = validateScope( form );
		if ( ! check.ok ) {
			if ( check.firstInvalid ) {
				var page = check.firstInvalid.closest( '.phemightforms-page' );
				if ( page ) {
					showPage( form, pages( form ).indexOf( page ) );
				}
				check.firstInvalid.focus();
			}
			return;
		}

		var button = form.querySelector( '.phemightforms-submit' );
		if ( button ) {
			button.disabled = true;
			button.classList.add( 'is-loading' );
		}

		var payload = new FormData( form );
		payload.append( 'action', 'phemightforms_submit' );

		fetch( data.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: payload,
		} )
			.then( function ( response ) {
				return response.json().then( function ( json ) {
					return { ok: response.ok, json: json };
				} );
			} )
			.then( function ( result ) {
				var body = result.json && result.json.data ? result.json.data : {};

				if ( result.json && result.json.success ) {
					if ( body.redirect ) {
						window.location.href = body.redirect;
						return;
					}
					var wrapperChildren = form.querySelectorAll( '.phemightforms-page, .phemightforms-actions, .phemightforms-progress' );
					wrapperChildren.forEach( function ( el ) {
						el.style.display = 'none';
					} );
					setAlert( form, body.message || 'Thank you!', 'success' );
					form.reset();
				} else {
					if ( body.errors ) {
						showFieldErrors( form, body.errors );
					}
					setAlert( form, body.message || 'Something went wrong.', 'error' );
				}
			} )
			.catch( function () {
				setAlert( form, 'Network error. Please try again.', 'error' );
			} )
			.finally( function () {
				if ( button ) {
					button.disabled = false;
					button.classList.remove( 'is-loading' );
				}
			} );
	}

	/* --------------------------------------------------------------------- */
	/* Wiring                                                                */
	/* --------------------------------------------------------------------- */

	/* --------------------------------------------------------------------- */
	/* Signature pad                                                         */
	/* --------------------------------------------------------------------- */

	function initSignature( wrap ) {
		var canvas = wrap.querySelector( '.phemightforms-sig-pad' );
		var input = wrap.querySelector( '.phemightforms-sig-input' );
		var clear = wrap.querySelector( '.phemightforms-sig-clear' );
		if ( ! canvas || ! input ) {
			return;
		}

		var ctx = canvas.getContext( '2d' );
		var drawing = false;

		ctx.strokeStyle = '#1d2327';
		ctx.lineWidth = 2;
		ctx.lineCap = 'round';

		function pos( e ) {
			var rect = canvas.getBoundingClientRect();
			var point = e.touches ? e.touches[ 0 ] : e;
			return { x: point.clientX - rect.left, y: point.clientY - rect.top };
		}

		function start( e ) {
			drawing = true;
			var p = pos( e );
			ctx.beginPath();
			ctx.moveTo( p.x, p.y );
			e.preventDefault();
		}

		function move( e ) {
			if ( ! drawing ) {
				return;
			}
			var p = pos( e );
			ctx.lineTo( p.x, p.y );
			ctx.stroke();
			input.value = canvas.toDataURL( 'image/png' );
			e.preventDefault();
		}

		function end() {
			drawing = false;
		}

		canvas.addEventListener( 'mousedown', start );
		canvas.addEventListener( 'mousemove', move );
		document.addEventListener( 'mouseup', end );
		canvas.addEventListener( 'touchstart', start );
		canvas.addEventListener( 'touchmove', move );
		canvas.addEventListener( 'touchend', end );

		if ( clear ) {
			clear.addEventListener( 'click', function () {
				ctx.clearRect( 0, 0, canvas.width, canvas.height );
				input.value = '';
			} );
		}
	}

	/* --------------------------------------------------------------------- */
	/* Repeater                                                              */
	/* --------------------------------------------------------------------- */

	function initRepeater( wrap ) {
		var rows = wrap.querySelector( '.phemightforms-repeater-rows' );
		var addBtn = wrap.querySelector( '.phemightforms-repeater-add' );
		if ( ! rows || ! addBtn ) {
			return;
		}

		addBtn.addEventListener( 'click', function () {
			var first = rows.querySelector( '.phemightforms-repeater-row' );
			if ( ! first ) {
				return;
			}
			var clone = first.cloneNode( true );
			clone.querySelectorAll( 'input' ).forEach( function ( el ) {
				el.value = '';
				el.removeAttribute( 'required' );
			} );
			rows.appendChild( clone );
		} );

		wrap.addEventListener( 'click', function ( e ) {
			if ( e.target.classList.contains( 'phemightforms-repeater-remove' ) ) {
				var allRows = rows.querySelectorAll( '.phemightforms-repeater-row' );
				if ( allRows.length > 1 ) {
					e.target.closest( '.phemightforms-repeater-row' ).remove();
				}
			}
		} );
	}

	/* --------------------------------------------------------------------- */
	/* Payments: live totals and coupons                                     */
	/* --------------------------------------------------------------------- */

	function money( amount ) {
		var symbol = data.currency || '$';
		return symbol + ( isNaN( amount ) ? '0.00' : Number( amount ).toFixed( 2 ) );
	}

	function isFieldActive( el ) {
		var wrap = el.closest( '.phemightforms-field' );
		return ! wrap || ! wrap.classList.contains( 'phf-logic-hidden' );
	}

	function computeTotal( form ) {
		var totalEl = form.querySelector( '.phemightforms-total-amount' );
		var subtotal = 0;
		var qtyInput = form.querySelector( '.phemightforms-quantity' );
		var quantity = 1;

		if ( qtyInput && isFieldActive( qtyInput ) ) {
			quantity = Math.max( 1, parseInt( qtyInput.value, 10 ) || 1 );
		}

		form.querySelectorAll( '.phemightforms-price[data-price]' ).forEach( function ( el ) {
			if ( isFieldActive( el ) ) {
				subtotal += parseFloat( el.getAttribute( 'data-price' ) ) || 0;
			}
		} );

		form.querySelectorAll( 'input[data-user-price]' ).forEach( function ( el ) {
			if ( isFieldActive( el ) ) {
				subtotal += Math.max( 0, parseFloat( el.value ) || 0 );
			}
		} );

		form.querySelectorAll( '.phemightforms-priced-choices input[type="radio"]:checked' ).forEach( function ( el ) {
			if ( isFieldActive( el ) ) {
				subtotal += parseFloat( el.getAttribute( 'data-price' ) ) || 0;
			}
		} );

		form.querySelectorAll( '.phemightforms-priced-select' ).forEach( function ( sel ) {
			if ( ! isFieldActive( sel ) ) {
				return;
			}
			var opt = sel.options[ sel.selectedIndex ];
			if ( opt ) {
				subtotal += parseFloat( opt.getAttribute( 'data-price' ) ) || 0;
			}
		} );

		subtotal = subtotal * quantity;

		var coupon = form._phfCoupon;
		var total = subtotal;

		if ( coupon ) {
			var discount = coupon.type === 'percent'
				? subtotal * Math.min( 100, coupon.amount ) / 100
				: Math.min( subtotal, coupon.amount );
			total = Math.max( 0, subtotal - discount );
		}

		if ( totalEl ) {
			totalEl.textContent = money( total );
			totalEl.setAttribute( 'data-total', total.toFixed( 2 ) );
		}
	}

	function initPayments( form ) {
		var hasPayment = form.querySelector( '.phemightforms-total-amount, .phemightforms-price, .phemightforms-priced-choices, .phemightforms-priced-select, input[data-user-price]' );
		if ( ! hasPayment ) {
			return;
		}

		form.addEventListener( 'input', function () {
			computeTotal( form );
		} );
		form.addEventListener( 'change', function () {
			computeTotal( form );
		} );

		var applyBtn = form.querySelector( '.phemightforms-coupon-apply' );
		if ( applyBtn ) {
			applyBtn.addEventListener( 'click', function () {
				var input = form.querySelector( '.phemightforms-coupon-input' );
				var msg = form.querySelector( '.phemightforms-coupon-msg' );
				var code = input ? input.value.trim() : '';

				if ( ! code ) {
					return;
				}

				var body = new FormData();
				body.append( 'action', 'phemightforms_apply_coupon' );
				body.append( 'code', code );

				fetch( data.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
					.then( function ( r ) {
						return r.json();
					} )
					.then( function ( json ) {
						if ( json.success ) {
							form._phfCoupon = json.data;
							if ( msg ) {
								msg.textContent = ( i18n.couponApplied || 'Coupon applied:' ) + ' ' + json.data.label;
								msg.className = 'phemightforms-coupon-msg is-valid';
							}
						} else {
							form._phfCoupon = null;
							if ( msg ) {
								msg.textContent = ( json.data && json.data.message ) || i18n.couponInvalid || 'Invalid coupon.';
								msg.className = 'phemightforms-coupon-msg is-invalid';
							}
						}
						computeTotal( form );
					} )
					.catch( function () {} );
			} );
		}

		computeTotal( form );
	}

	/* --------------------------------------------------------------------- */
	/* Save & Resume                                                         */
	/* --------------------------------------------------------------------- */

	function collectData( form ) {
		var out = {};
		var els = form.querySelectorAll( 'input, select, textarea' );
		els.forEach( function ( el ) {
			if ( ! el.name || el.type === 'file' || el.name.indexOf( 'phemightforms_' ) === 0 ) {
				return;
			}
			if ( ( el.type === 'checkbox' || el.type === 'radio' ) && ! el.checked ) {
				return;
			}
			if ( el.name.slice( -2 ) === '[]' ) {
				out[ el.name ] = out[ el.name ] || [];
				out[ el.name ].push( el.value );
			} else {
				out[ el.name ] = el.value;
			}
		} );
		return out;
	}

	function initSaveResume( form ) {
		var btn = form.querySelector( '.phemightforms-save-resume' );
		if ( btn ) {
			btn.addEventListener( 'click', function () {
				var body = new FormData();
				body.append( 'action', 'phemightforms_save_partial' );
				body.append( 'form_id', form.getAttribute( 'data-form-id' ) );
				var nonceEl = form.querySelector( '[name="phemightforms_nonce"]' );
				body.append( 'nonce', nonceEl ? nonceEl.value : '' );
				body.append( 'data', JSON.stringify( collectData( form ) ) );

				fetch( data.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
					.then( function ( r ) {
						return r.json();
					} )
					.then( function ( json ) {
						var box = form.querySelector( '.phemightforms-resume-link' );
						if ( json.success && box ) {
							box.hidden = false;
							box.innerHTML = '';
							var p = document.createElement( 'p' );
							p.textContent = 'Your progress is saved. Return anytime with this link:';
							var a = document.createElement( 'a' );
							a.href = json.data.url;
							a.textContent = json.data.url;
							box.appendChild( p );
							box.appendChild( a );
						}
					} )
					.catch( function () {} );
			} );
		}

		// Resume if a token is present in the URL.
		var match = window.location.search.match( /[?&]phf_resume=([^&]+)/ );
		if ( match ) {
			fetch( data.ajaxUrl + '?action=phemightforms_get_partial&token=' + encodeURIComponent( match[ 1 ] ), { credentials: 'same-origin' } )
				.then( function ( r ) {
					return r.json();
				} )
				.then( function ( json ) {
					if ( json.success && parseInt( json.data.form_id, 10 ) === parseInt( form.getAttribute( 'data-form-id' ), 10 ) ) {
						populate( form, json.data.fields );
						applyLogic( form );
					}
				} )
				.catch( function () {} );
		}
	}

	function populate( form, fields ) {
		Object.keys( fields ).forEach( function ( name ) {
			var value = fields[ name ];
			var els = form.querySelectorAll( '[name="' + name + '"]' );
			if ( ! els.length ) {
				return;
			}
			els.forEach( function ( el ) {
				if ( el.type === 'checkbox' || el.type === 'radio' ) {
					var vals = Array.isArray( value ) ? value : [ value ];
					el.checked = vals.indexOf( el.value ) !== -1;
				} else {
					el.value = Array.isArray( value ) ? value[ 0 ] : value;
				}
			} );
		} );
	}

	function initForm( form ) {
		form.setAttribute( 'novalidate', 'novalidate' );

		form.querySelectorAll( '.phemightforms-signature' ).forEach( initSignature );
		form.querySelectorAll( '.phemightforms-repeater' ).forEach( initRepeater );
		initPayments( form );

		if ( form.getAttribute( 'data-save-resume' ) === '1' ) {
			initSaveResume( form );
		}

		applyLogic( form );

		form.addEventListener( 'input', function () {
			applyLogic( form );
		} );
		form.addEventListener( 'change', function () {
			applyLogic( form );
		} );

		var next = form.querySelector( '.phemightforms-next' );
		var prev = form.querySelector( '.phemightforms-prev' );

		if ( next ) {
			next.addEventListener( 'click', function () {
				var idx = currentPageIndex( form );
				var activePage = pages( form )[ idx ];
				clearErrors( activePage );
				var check = validateScope( activePage );
				if ( ! check.ok ) {
					if ( check.firstInvalid ) {
						check.firstInvalid.focus();
					}
					return;
				}
				showPage( form, idx + 1 );
			} );
		}

		if ( prev ) {
			prev.addEventListener( 'click', function () {
				showPage( form, Math.max( 0, currentPageIndex( form ) - 1 ) );
			} );
		}

		if ( pages( form ).length > 1 ) {
			showPage( form, 0 );
		}

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			submitForm( form );
		} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '.phemightforms-form' ).forEach( initForm );

		document.querySelectorAll( '.phemightforms-embed' ).forEach( function ( wrap ) {
			var trigger = wrap.querySelector( '.phemightforms-embed-trigger' );
			var panel = wrap.querySelector( '.phemightforms-embed-panel' );
			if ( ! trigger || ! panel ) {
				return;
			}
			trigger.addEventListener( 'click', function () {
				panel.hidden = ! panel.hidden;
				if ( ! panel.hidden ) {
					panel.querySelectorAll( '.phemightforms-form' ).forEach( initForm );
				}
			} );
		} );
	} );
} )();
