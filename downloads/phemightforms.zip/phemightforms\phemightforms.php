<?php
/**
 * Plugin Name:       PhemightForms
 * Plugin URI:        https://phemightforms.github.io/
 * Description:       Drag and drop WordPress form builder by Phemight Technologies. Create contact forms, payment forms, payment links, invoices, surveys, quizzes, and lead capture forms without writing code. Includes conditional logic, multi page forms, addons, CAPTCHA protection, payment gateways, SMTP email, webhooks, and GDPR tools.
 * Version:           2.10.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Phemight Technologies
 * Author URI:        https://phemighttechnologies.com.ng/index.html
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       phemightforms
 * Domain Path:       /languages
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PHEMIGHTFORMS_VERSION', '2.10.0' );
define( 'PHEMIGHTFORMS_FILE', __FILE__ );
define( 'PHEMIGHTFORMS_DIR', plugin_dir_path( __FILE__ ) );
define( 'PHEMIGHTFORMS_URL', plugin_dir_url( __FILE__ ) );
define( 'PHEMIGHTFORMS_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Simple PSR-4 style autoloader for the PhemightForms namespace.
 *
 * Maps PhemightForms\Sub\ClassName to includes/sub/class-classname.php.
 */
spl_autoload_register(
	static function ( $class ) {
		$prefix = __NAMESPACE__ . '\\';

		if ( strpos( $class, $prefix ) !== 0 ) {
			return;
		}

		$relative = substr( $class, strlen( $prefix ) );
		$parts    = explode( '\\', $relative );
		$class_nm = array_pop( $parts );

		$path = PHEMIGHTFORMS_DIR . 'includes/';

		if ( $parts ) {
			$path .= strtolower( implode( '/', $parts ) ) . '/';
		}

		$file = $path . 'class-' . strtolower( str_replace( '_', '-', $class_nm ) ) . '.php';

		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

register_activation_hook( __FILE__, [ Install::class, 'activate' ] );
register_deactivation_hook( __FILE__, [ Install::class, 'deactivate' ] );

/**
 * Boot the plugin once all plugins are loaded.
 *
 * @return Plugin
 */
function phemightforms() {
	return Plugin::instance();
}

add_action( 'plugins_loaded', __NAMESPACE__ . '\\phemightforms' );
