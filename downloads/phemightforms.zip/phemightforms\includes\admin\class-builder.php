<?php
/**
 * Form builder admin screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Form;
use PhemightForms\Landing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lists forms and renders the field builder.
 */
class Builder {

	/**
	 * Handle redirecting/downloading actions before any admin output is sent.
	 */
	public function __construct() {
		add_action( 'admin_init', [ self::class, 'handle_actions' ] );
	}

	/**
	 * Process actions that end in a redirect or file download. These must run
	 * on admin_init, before the admin header is output, or the redirect fails.
	 */
	public static function handle_actions() {
		$page = isset( $_REQUEST['page'] ) ? sanitize_key( wp_unslash( $_REQUEST['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( Admin::SLUG_FORMS !== $page ) {
			return;
		}

		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! in_array( $action, [ 'save', 'delete', 'create', 'duplicate', 'star', 'export', 'import' ], true ) ) {
			return;
		}

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'phemightforms' ) );
		}

		if ( 'save' === $action ) {
			self::handle_save();
		}

		if ( 'delete' === $action ) {
			self::handle_delete();
		}

		if ( 'create' === $action ) {
			self::handle_create_from_template();
		}

		if ( 'duplicate' === $action ) {
			self::handle_duplicate();
		}

		if ( 'star' === $action ) {
			self::handle_star();
		}

		if ( 'export' === $action ) {
			self::handle_export();
		}

		if ( 'import' === $action ) {
			self::handle_import();
		}
	}

	/**
	 * Route the page to list, edit, or save.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'phemightforms' ) );
		}

		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'new' === $action ) {
			TemplatesPage::render_page();
			return;
		}

		if ( 'edit' === $action ) {
			self::render_editor();
			return;
		}

		if ( 'preview' === $action ) {
			self::render_preview();
			return;
		}

		self::render_list();
	}

	/**
	 * Create a form from a template and redirect to the editor.
	 */
	private static function handle_create_from_template() {
		$slug = isset( $_GET['template'] ) ? sanitize_key( wp_unslash( $_GET['template'] ) ) : 'blank';

		check_admin_referer( 'phemightforms_create_' . $slug );

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$config = \PhemightForms\Templates::build_config( $slug );

		if ( null === $config ) {
			$config = Form::default_config();
		}

		$form_id = Form::save( \PhemightForms\Templates::title( $slug ), $config, 0 );

		wp_safe_redirect(
			add_query_arg(
				[
					'page'   => Admin::SLUG_FORMS,
					'action' => 'edit',
					'form'   => $form_id,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Show the list of existing forms.
	 */
	private static function render_list() {
		$forms    = Form::all();
		$new_url  = add_query_arg(
			[
				'page'   => Admin::SLUG_FORMS,
				'action' => 'new',
			],
			admin_url( 'admin.php' )
		);
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'forms' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Forms', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'Create, edit, and embed your forms.', 'phemightforms' ); ?></p>
					</div>
					<div class="phf-filter-bar">
						<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin.php?page=' . Admin::SLUG_FORMS . '&action=import' ) ); ?>">
							<?php wp_nonce_field( 'phemightforms_import' ); ?>
							<input type="file" name="phf_import_file" accept="application/json,.json" required>
							<button type="submit" class="phf-btn phf-btn-ghost"><?php esc_html_e( 'Import JSON', 'phemightforms' ); ?></button>
						</form>
						<a href="<?php echo esc_url( $new_url ); ?>" class="phf-btn phf-btn-primary">
							<span class="dashicons dashicons-plus-alt2"></span>
							<?php esc_html_e( 'Add New', 'phemightforms' ); ?>
						</a>
					</div>
				</div>

				<?php if ( isset( $_GET['created'] ) || isset( $_GET['updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Form saved.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<?php if ( ! $forms ) : ?>
					<div class="phf-card-panel">
						<div class="phf-empty-state">
							<span class="dashicons dashicons-feedback"></span>
							<p><?php esc_html_e( 'No forms yet. Create your first form.', 'phemightforms' ); ?></p>
							<a href="<?php echo esc_url( $new_url ); ?>" class="phf-btn phf-btn-primary"><?php esc_html_e( 'Create Your First Form', 'phemightforms' ); ?></a>
						</div>
					</div>
				<?php else : ?>
					<div class="phf-card-panel phf-table-panel">
						<table class="phf-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Title', 'phemightforms' ); ?></th>
									<th><?php esc_html_e( 'Shortcode', 'phemightforms' ); ?></th>
									<th class="phf-col-narrow"><?php esc_html_e( 'Fields', 'phemightforms' ); ?></th>
									<th class="phf-col-actions"><?php esc_html_e( 'Actions', 'phemightforms' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $forms as $post ) : ?>
									<?php
									$form     = new Form( $post->ID );
									$edit_url = add_query_arg(
										[
											'page'   => Admin::SLUG_FORMS,
											'action' => 'edit',
											'form'   => $post->ID,
										],
										admin_url( 'admin.php' )
									);
									$del_url  = wp_nonce_url(
										add_query_arg(
											[
												'page'   => Admin::SLUG_FORMS,
												'action' => 'delete',
												'form'   => $post->ID,
											],
											admin_url( 'admin.php' )
										),
										'phemightforms_delete_' . $post->ID
									);
									$star_url = wp_nonce_url(
										add_query_arg(
											[
												'page'   => Admin::SLUG_FORMS,
												'action' => 'star',
												'form'   => $post->ID,
											],
											admin_url( 'admin.php' )
										),
										'phemightforms_star_' . $post->ID
									);
									$dup_url  = wp_nonce_url(
										add_query_arg(
											[
												'page'   => Admin::SLUG_FORMS,
												'action' => 'duplicate',
												'form'   => $post->ID,
											],
											admin_url( 'admin.php' )
										),
										'phemightforms_duplicate_' . $post->ID
									);
									$prev_url = add_query_arg(
										[
											'page'   => Admin::SLUG_FORMS,
											'action' => 'preview',
											'form'   => $post->ID,
										],
										admin_url( 'admin.php' )
									);
									$exp_url  = wp_nonce_url(
										add_query_arg(
											[
												'page'   => Admin::SLUG_FORMS,
												'action' => 'export',
												'form'   => $post->ID,
											],
											admin_url( 'admin.php' )
										),
										'phemightforms_export_' . $post->ID
									);
									$starred  = ( new Form( $post->ID ) )->is_starred();
									?>
									<tr>
										<td data-label="<?php esc_attr_e( 'Title', 'phemightforms' ); ?>">
											<?php if ( $starred ) : ?><span class="dashicons dashicons-star-filled phf-star-icon" title="<?php esc_attr_e( 'Starred', 'phemightforms' ); ?>"></span><?php endif; ?>
											<a class="phf-row-title" href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $post->post_title ); ?></a>
										</td>
										<td data-label="<?php esc_attr_e( 'Shortcode', 'phemightforms' ); ?>"><code class="phf-shortcode">[phemightform id="<?php echo esc_attr( $post->ID ); ?>"]</code></td>
										<td data-label="<?php esc_attr_e( 'Fields', 'phemightforms' ); ?>"><span class="phf-badge"><?php echo esc_html( count( $form->get_fields() ) ); ?></span></td>
										<td class="phf-row-actions">
											<a href="<?php echo esc_url( $edit_url ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-edit"></span><?php esc_html_e( 'Edit', 'phemightforms' ); ?></a>
											<a href="<?php echo esc_url( $prev_url ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm" target="_blank" rel="noopener"><span class="dashicons dashicons-visibility"></span><?php esc_html_e( 'Preview', 'phemightforms' ); ?></a>
											<a href="<?php echo esc_url( $dup_url ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-admin-page"></span><?php esc_html_e( 'Duplicate', 'phemightforms' ); ?></a>
											<a href="<?php echo esc_url( $exp_url ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-download"></span><?php esc_html_e( 'Export', 'phemightforms' ); ?></a>
											<a href="<?php echo esc_url( $star_url ); ?>" class="phf-btn phf-btn-ghost phf-btn-sm"><span class="dashicons dashicons-star-empty"></span></a>
											<a href="<?php echo esc_url( $del_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this form?', 'phemightforms' ) ); ?>');" class="phf-btn phf-btn-ghost phf-btn-sm phf-btn-danger"><span class="dashicons dashicons-trash"></span><?php esc_html_e( 'Delete', 'phemightforms' ); ?></a>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the field editor for a new or existing form.
	 */
	private static function render_editor() {
		$form_id  = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$form     = new Form( $form_id );
		$config   = wp_json_encode( $form->config );
		$title    = $form->exists() ? $form->title : __( 'New Form', 'phemightforms' );
		$registry = \PhemightForms\phemightforms()->fields;
		$groups   = $registry->groups();
		$types    = $registry->all();

		$list_url    = add_query_arg( [ 'page' => Admin::SLUG_FORMS ], admin_url( 'admin.php' ) );
		$preview_url = $form_id ? add_query_arg(
			[
				'page'   => Admin::SLUG_FORMS,
				'action' => 'preview',
				'form'   => $form_id,
			],
			admin_url( 'admin.php' )
		) : '';
		$saved_flag  = isset( $_GET['updated'] ) || isset( $_GET['created'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap phemightforms-wrap phemightforms-builder">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=' . Admin::SLUG_FORMS ) ); ?>" id="phemightforms-builder-form" class="phf-builder-app">
				<?php wp_nonce_field( 'phemightforms_save' ); ?>
				<input type="hidden" name="action" value="save">
				<input type="hidden" name="form" value="<?php echo esc_attr( $form_id ); ?>">
				<input type="hidden" name="config" id="phemightforms-config" value="<?php echo esc_attr( $config ); ?>">

				<header class="phf-builder-topbar">
					<div class="phf-builder-brand">
						<img src="<?php echo esc_url( PHEMIGHTFORMS_URL . 'assets/images/icon-topbar.png' ); ?>" alt="PhemightForms">
					</div>
					<div class="phf-builder-name">
						<span class="phf-builder-name-label"><?php esc_html_e( 'Now editing', 'phemightforms' ); ?></span>
						<input type="text" name="title" class="phemightforms-title-input" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php esc_attr_e( 'Form title', 'phemightforms' ); ?>">
					</div>
					<?php if ( $saved_flag ) : ?>
						<span class="phf-save-badge"><span class="dashicons dashicons-yes"></span><?php esc_html_e( 'Saved', 'phemightforms' ); ?></span>
					<?php endif; ?>
					<div class="phf-builder-actions">
						<?php if ( $form_id ) : ?>
							<details class="phf-embed-dd">
								<summary><span class="dashicons dashicons-editor-code"></span><?php esc_html_e( 'Embed', 'phemightforms' ); ?></summary>
								<div class="phf-embed-pop">
									<p><?php esc_html_e( 'Copy this shortcode into any page or post to display your form:', 'phemightforms' ); ?></p>
									<code>[phemightform id="<?php echo esc_attr( $form_id ); ?>"]</code>
								</div>
							</details>
							<a href="<?php echo esc_url( $preview_url ); ?>" class="phf-tb-btn" target="_blank" rel="noopener"><span class="dashicons dashicons-visibility"></span><?php esc_html_e( 'Preview', 'phemightforms' ); ?></a>
						<?php endif; ?>
						<button type="submit" class="phf-tb-save"><span class="dashicons dashicons-saved"></span><?php esc_html_e( 'Save', 'phemightforms' ); ?></button>
						<a href="<?php echo esc_url( $list_url ); ?>" class="phf-tb-exit" title="<?php esc_attr_e( 'Exit builder', 'phemightforms' ); ?>"><span class="dashicons dashicons-no-alt"></span></a>
					</div>
				</header>

				<div class="phf-builder-main">
					<aside class="phf-builder-panel">
						<div class="phf-builder-tabs">
							<button type="button" class="phf-tab is-active" data-tab="fields"><span class="dashicons dashicons-plus-alt"></span><span><?php esc_html_e( 'Add Fields', 'phemightforms' ); ?></span></button>
							<button type="button" class="phf-tab" data-tab="options"><span class="dashicons dashicons-admin-generic"></span><span><?php esc_html_e( 'Field Options', 'phemightforms' ); ?></span></button>
							<button type="button" class="phf-tab" data-tab="settings"><span class="dashicons dashicons-admin-settings"></span><span><?php esc_html_e( 'Settings', 'phemightforms' ); ?></span></button>
						</div>

						<div class="phf-builder-panels">
							<div class="phf-tab-panel" data-panel="fields">
								<?php foreach ( $groups as $group_key => $group_label ) : ?>
									<h3 class="phf-group-title"><?php echo esc_html( $group_label ); ?></h3>
									<div class="phemightforms-field-buttons">
										<?php
										foreach ( $types as $type => $def ) :
											if ( ( isset( $def['group'] ) ? $def['group'] : 'standard' ) !== $group_key ) {
												continue;
											}
											?>
											<button type="button" class="phemightforms-add-field" data-type="<?php echo esc_attr( $type ); ?>" draggable="true">
												<span class="dashicons <?php echo esc_attr( isset( $def['icon'] ) ? $def['icon'] : 'dashicons-plus' ); ?>"></span>
												<?php echo esc_html( $def['label'] ); ?>
											</button>
										<?php endforeach; ?>
									</div>
								<?php endforeach; ?>
							</div>

							<div class="phf-tab-panel phf-panel-options" data-panel="options" hidden>
								<div class="phf-options-empty"><?php esc_html_e( 'Select a field on the form to edit its options.', 'phemightforms' ); ?></div>
								<div class="phf-options-panel" id="phemightforms-options" hidden></div>
							</div>

							<div class="phf-tab-panel phf-panel-settings" data-panel="settings" hidden>
								<h3 class="phf-group-title"><?php esc_html_e( 'General', 'phemightforms' ); ?></h3>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Submit button text', 'phemightforms' ); ?></label>
									<input type="text" data-setting="submit_text" class="widefat">
								</div>
								<div class="phf-opt-row">
									<label class="phf-inline"><input type="checkbox" data-setting="is_quiz" value="1"> <?php esc_html_e( 'This is a quiz (score answers)', 'phemightforms' ); ?></label>
								</div>
								<div class="phf-opt-row">
									<label class="phf-inline"><input type="checkbox" data-setting="save_resume" value="1"> <?php esc_html_e( 'Allow Save & Resume', 'phemightforms' ); ?></label>
								</div>

								<h3 class="phf-group-title"><?php esc_html_e( 'Form Style', 'phemightforms' ); ?></h3>
								<div class="phf-style-grid">
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Accent color', 'phemightforms' ); ?></label>
										<input type="color" data-setting="accent_color" value="#b56d18">
									</div>
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Button text color', 'phemightforms' ); ?></label>
										<input type="color" data-setting="button_text_color" value="#ffffff">
									</div>
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Background color', 'phemightforms' ); ?></label>
										<input type="color" data-setting="form_bg_color" value="#ffffff">
									</div>
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Text color', 'phemightforms' ); ?></label>
										<input type="color" data-setting="text_color" value="#0f172a">
									</div>
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Border color', 'phemightforms' ); ?></label>
										<input type="color" data-setting="border_color" value="#e2e8f0">
									</div>
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Border width (px)', 'phemightforms' ); ?></label>
										<input type="number" data-setting="border_width" min="0" max="8" step="1" value="1">
									</div>
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Corner radius (px)', 'phemightforms' ); ?></label>
										<input type="number" data-setting="border_radius" min="0" max="32" step="1" value="12">
									</div>
									<div class="phf-opt-row">
										<label><?php esc_html_e( 'Font size (px)', 'phemightforms' ); ?></label>
										<input type="number" data-setting="font_size" min="12" max="22" step="1" value="16">
									</div>
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Button style', 'phemightforms' ); ?></label>
									<select data-setting="button_style" class="widefat">
										<option value="solid"><?php esc_html_e( 'Solid (filled)', 'phemightforms' ); ?></option>
										<option value="outline"><?php esc_html_e( 'Outline', 'phemightforms' ); ?></option>
									</select>
								</div>
								<h3 class="phf-group-title"><?php esc_html_e( 'Payments', 'phemightforms' ); ?></h3>
								<div class="phf-opt-row">
									<label class="phf-inline"><input type="checkbox" data-setting="payments_enabled" value="1"> <?php esc_html_e( 'Enable payments on this form', 'phemightforms' ); ?></label>
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Payment method', 'phemightforms' ); ?></label>
									<select data-setting="payment_method" class="widefat">
										<?php
										$providers = \PhemightForms\Payments::enabled_providers();
										if ( ! $providers ) {
											$providers = [ 'offline' => __( 'Offline / Manual', 'phemightforms' ) ];
										}
										foreach ( $providers as $prov_slug => $prov_label ) :
											?>
											<option value="<?php echo esc_attr( $prov_slug ); ?>"><?php echo esc_html( $prov_label ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<p class="description phf-payments-hint">
									<?php
									printf(
										/* translators: %s: Payments settings page link */
										esc_html__( 'Add payment fields from the Payment Fields group, then configure providers on the %s page.', 'phemightforms' ),
										'<a href="' . esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-payments' ], admin_url( 'admin.php' ) ) ) . '" target="_blank">' . esc_html__( 'Payments', 'phemightforms' ) . '</a>'
									);
									?>
								</p>

								<h3 class="phf-group-title"><?php esc_html_e( 'Notifications', 'phemightforms' ); ?></h3>
								<div class="phf-opt-row">
									<label class="phf-inline"><input type="checkbox" data-setting="notify_enabled" value="1"> <?php esc_html_e( 'Send email notification', 'phemightforms' ); ?></label>
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Notify email', 'phemightforms' ); ?></label>
									<input type="email" data-setting="notify_to" class="widefat">
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Email subject', 'phemightforms' ); ?></label>
									<input type="text" data-setting="notify_subject" class="widefat">
								</div>

								<h3 class="phf-group-title"><?php esc_html_e( 'Confirmations', 'phemightforms' ); ?></h3>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'After submit', 'phemightforms' ); ?></label>
									<select data-setting="confirmation_type" class="widefat">
										<option value="message"><?php esc_html_e( 'Show a message', 'phemightforms' ); ?></option>
										<option value="redirect"><?php esc_html_e( 'Redirect to a URL', 'phemightforms' ); ?></option>
										<option value="page"><?php esc_html_e( 'Redirect to a page', 'phemightforms' ); ?></option>
									</select>
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Confirmation message', 'phemightforms' ); ?></label>
									<textarea data-setting="confirmation" class="widefat" rows="3"></textarea>
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Redirect URL', 'phemightforms' ); ?></label>
									<input type="url" data-setting="confirmation_redirect" class="widefat" placeholder="https://">
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Redirect page', 'phemightforms' ); ?></label>
									<select data-setting="confirmation_page" class="widefat">
										<option value="0"><?php esc_html_e( 'Select a page', 'phemightforms' ); ?></option>
										<?php foreach ( get_pages() as $page ) : ?>
											<option value="<?php echo esc_attr( $page->ID ); ?>"><?php echo esc_html( $page->post_title ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>

								<h3 class="phf-group-title"><?php esc_html_e( 'Webhooks', 'phemightforms' ); ?></h3>
								<div class="phf-opt-row">
									<label class="phf-inline"><input type="checkbox" data-setting="webhook_enabled" value="1"> <?php esc_html_e( 'Send to webhook on submit', 'phemightforms' ); ?></label>
								</div>
								<div class="phf-opt-row">
									<label><?php esc_html_e( 'Webhook URL', 'phemightforms' ); ?></label>
									<input type="url" data-setting="webhook_url" class="widefat" placeholder="https://">
								</div>
							</div>
						</div>
					</aside>

					<div class="phf-builder-stage">
						<div class="phf-stage-inner">
							<p class="phf-canvas-help"><?php esc_html_e( 'Drag a field from the left onto the form, or click it. Click a field to edit its options. Drag the handle to reorder.', 'phemightforms' ); ?></p>
							<div class="phf-stage-form">
								<div id="phemightforms-canvas" class="phemightforms-canvas"></div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * Validate and persist the submitted form.
	 */
	private static function handle_save() {
		check_admin_referer( 'phemightforms_save' );

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$form_id = isset( $_POST['form'] ) ? absint( wp_unslash( $_POST['form'] ) ) : 0;
		$title   = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : __( 'Untitled Form', 'phemightforms' );
		$raw     = isset( $_POST['config'] ) ? wp_unslash( $_POST['config'] ) : '{}'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON decoded and sanitized below.
		$config  = self::sanitize_config( json_decode( $raw, true ) );

		$saved = Form::save( $title, $config, $form_id );

		if ( $saved ) {
			update_option( 'phemightforms_onboarding_done', 1 );
		}

		$redirect = add_query_arg(
			[
				'page'   => Admin::SLUG_FORMS,
				'action' => 'edit',
				'form'   => $saved,
				$form_id ? 'updated' : 'created' => 1,
			],
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Delete a form after verifying the nonce.
	 */
	private static function handle_delete() {
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;

		check_admin_referer( 'phemightforms_delete_' . $form_id );

		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		Form::delete( $form_id );

		wp_safe_redirect( add_query_arg( [ 'page' => Admin::SLUG_FORMS ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Clean an untrusted config array before saving.
	 *
	 * @param mixed $config Decoded JSON.
	 * @return array
	 */
	private static function sanitize_config( $config ) {
		$clean = Form::default_config();

		if ( ! is_array( $config ) ) {
			return $clean;
		}

		$fields    = ( isset( $config['fields'] ) && is_array( $config['fields'] ) ) ? $config['fields'] : [];
		$registry  = \PhemightForms\phemightforms()->fields;
		$clean_fld = [];
		$max_id    = 0;

		foreach ( $fields as $field ) {
			$type = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text';

			if ( ! $registry->exists( $type ) ) {
				continue;
			}

			$id     = isset( $field['id'] ) ? absint( $field['id'] ) : 0;
			$max_id = max( $max_id, $id );

			$entry = [
				'id'          => $id,
				'type'        => $type,
				'label'       => isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : '',
				'placeholder' => isset( $field['placeholder'] ) ? sanitize_text_field( $field['placeholder'] ) : '',
				'description' => isset( $field['description'] ) ? sanitize_text_field( $field['description'] ) : '',
				'required'    => ! empty( $field['required'] ) ? 1 : 0,
			];

			if ( $registry->has_choices( $type ) && isset( $field['choices'] ) && is_array( $field['choices'] ) ) {
				$entry['choices'] = array_values( array_filter( array_map( 'sanitize_text_field', $field['choices'] ) ) );

				if ( isset( $field['correct'] ) && '' !== $field['correct'] ) {
					$entry['correct'] = sanitize_text_field( $field['correct'] );
				}
			}

			if ( 'repeater' === $type && isset( $field['sub_label'] ) ) {
				$entry['sub_label'] = sanitize_text_field( $field['sub_label'] );
			}

			if ( 'consent' === $type ) {
				$entry['consent_text'] = isset( $field['consent_text'] ) ? sanitize_text_field( $field['consent_text'] ) : '';
			}

			if ( 'hidden' === $type ) {
				$entry['default_value'] = isset( $field['default_value'] ) ? sanitize_text_field( $field['default_value'] ) : '';
			}

			if ( 'html' === $type && isset( $field['html_content'] ) ) {
				$entry['html_content'] = wp_kses_post( $field['html_content'] );
			}

			if ( isset( $field['size'] ) && in_array( $field['size'], [ 'full', 'half' ], true ) ) {
				$entry['size'] = $field['size'];
			}

			if ( isset( $field['label_position'] ) && in_array( $field['label_position'], [ 'top', 'left', 'hidden' ], true ) ) {
				$entry['label_position'] = $field['label_position'];
			}

			if ( 'rating' === $type && isset( $field['rating_max'] ) ) {
				$entry['rating_max'] = max( 3, min( 10, absint( $field['rating_max'] ) ) );
			}

			if ( 'payment_single' === $type ) {
				$entry['price']      = \PhemightForms\Payments::to_amount( isset( $field['price'] ) ? $field['price'] : 0 );
				$entry['user_price'] = ! empty( $field['user_price'] ) ? 1 : 0;
			}

			if ( $registry->supports_logic( $type ) && ! empty( $field['conditional'] ) && is_array( $field['conditional'] ) ) {
				$entry['conditional'] = self::sanitize_conditional( $field['conditional'] );
			}

			$clean_fld[] = $entry;
		}

		// Assign IDs to any field that arrived without one.
		foreach ( $clean_fld as &$fld ) {
			if ( empty( $fld['id'] ) ) {
				$fld['id'] = ++$max_id;
			}
		}
		unset( $fld );

		$clean['fields']   = $clean_fld;
		$clean['_next_id'] = $max_id + 1;

		$settings = ( isset( $config['settings'] ) && is_array( $config['settings'] ) ) ? $config['settings'] : [];

		$conf_type = isset( $settings['confirmation_type'] ) ? sanitize_key( $settings['confirmation_type'] ) : 'message';
		if ( ! in_array( $conf_type, [ 'message', 'redirect', 'page' ], true ) ) {
			$conf_type = 'message';
		}

		$webhook_format = isset( $settings['webhook_format'] ) ? sanitize_key( $settings['webhook_format'] ) : 'generic';
		if ( ! in_array( $webhook_format, [ 'generic', 'slack', 'discord', 'telegram' ], true ) ) {
			$webhook_format = 'generic';
		}

		$embed_mode = isset( $settings['embed_mode'] ) ? sanitize_key( $settings['embed_mode'] ) : 'inline';
		if ( ! in_array( $embed_mode, [ 'inline', 'popup', 'slide' ], true ) ) {
			$embed_mode = 'inline';
		}

		$defaults = Form::default_config()['settings'];

		$clean['settings'] = wp_parse_args(
			[
				'submit_text'           => isset( $settings['submit_text'] ) ? sanitize_text_field( $settings['submit_text'] ) : $defaults['submit_text'],
				'confirmation'          => isset( $settings['confirmation'] ) ? sanitize_textarea_field( $settings['confirmation'] ) : $defaults['confirmation'],
				'confirmation_type'     => $conf_type,
				'confirmation_redirect' => isset( $settings['confirmation_redirect'] ) ? esc_url_raw( $settings['confirmation_redirect'] ) : '',
				'confirmation_page'     => isset( $settings['confirmation_page'] ) ? absint( $settings['confirmation_page'] ) : 0,
				'notify_enabled'        => ! empty( $settings['notify_enabled'] ) ? 1 : 0,
				'notify_to'             => isset( $settings['notify_to'] ) ? sanitize_email( $settings['notify_to'] ) : get_option( 'admin_email' ),
				'notify_subject'        => isset( $settings['notify_subject'] ) ? sanitize_text_field( $settings['notify_subject'] ) : $defaults['notify_subject'],
				'notify_routes'         => self::sanitize_routes( isset( $settings['notify_routes'] ) ? $settings['notify_routes'] : [] ),
				'confirm_rules'         => self::sanitize_confirm_rules( isset( $settings['confirm_rules'] ) ? $settings['confirm_rules'] : [] ),
				'is_quiz'               => ! empty( $settings['is_quiz'] ) ? 1 : 0,
				'webhook_enabled'       => ! empty( $settings['webhook_enabled'] ) ? 1 : 0,
				'webhook_url'           => isset( $settings['webhook_url'] ) ? esc_url_raw( $settings['webhook_url'] ) : '',
				'webhook_format'        => $webhook_format,
				'save_resume'           => ! empty( $settings['save_resume'] ) ? 1 : 0,
				'mailchimp_enabled'     => ! empty( $settings['mailchimp_enabled'] ) ? 1 : 0,
				'mailchimp_list'        => isset( $settings['mailchimp_list'] ) ? sanitize_text_field( $settings['mailchimp_list'] ) : '',
				'sheets_url'            => isset( $settings['sheets_url'] ) ? esc_url_raw( $settings['sheets_url'] ) : '',
				'landing_page'          => ! empty( $settings['landing_page'] ) ? 1 : 0,
				'payments_enabled'      => ! empty( $settings['payments_enabled'] ) ? 1 : 0,
				'payment_method'        => isset( $settings['payment_method'] ) && isset( \PhemightForms\Payments::providers()[ $settings['payment_method'] ] ) ? $settings['payment_method'] : 'offline',
				'accent_color'          => isset( $settings['accent_color'] ) ? sanitize_hex_color( $settings['accent_color'] ) : '#b56d18',
				'button_text_color'     => isset( $settings['button_text_color'] ) ? sanitize_hex_color( $settings['button_text_color'] ) : '#ffffff',
				'form_bg_color'         => isset( $settings['form_bg_color'] ) ? sanitize_hex_color( $settings['form_bg_color'] ) : '#ffffff',
				'text_color'            => isset( $settings['text_color'] ) ? sanitize_hex_color( $settings['text_color'] ) : '#0f172a',
				'border_color'          => isset( $settings['border_color'] ) ? sanitize_hex_color( $settings['border_color'] ) : '#e2e8f0',
				'border_width'          => isset( $settings['border_width'] ) ? min( 8, absint( $settings['border_width'] ) ) : 1,
				'button_style'          => isset( $settings['button_style'] ) ? sanitize_key( $settings['button_style'] ) : 'solid',
				'border_radius'         => isset( $settings['border_radius'] ) ? min( 32, absint( $settings['border_radius'] ) ) : 12,
				'font_size'             => isset( $settings['font_size'] ) ? absint( $settings['font_size'] ) : 16,
				'label_position'        => isset( $settings['label_position'] ) ? sanitize_key( $settings['label_position'] ) : 'top',
				'embed_mode'            => $embed_mode,
				'embed_button_text'     => isset( $settings['embed_button_text'] ) ? sanitize_text_field( $settings['embed_button_text'] ) : $defaults['embed_button_text'],
			],
			$defaults
		);

		return $clean;
	}

	/**
	 * Sanitize notification routing rules.
	 *
	 * @param mixed $routes Raw routes.
	 * @return array
	 */
	private static function sanitize_routes( $routes ) {
		if ( ! is_array( $routes ) ) {
			return [];
		}

		$clean = [];
		foreach ( $routes as $route ) {
			if ( empty( $route['field'] ) || empty( $route['email'] ) ) {
				continue;
			}
			$clean[] = [
				'field' => absint( $route['field'] ),
				'value' => isset( $route['value'] ) ? sanitize_text_field( $route['value'] ) : '',
				'email' => sanitize_email( $route['email'] ),
			];
		}
		return $clean;
	}

	/**
	 * Sanitize conditional confirmation rules.
	 *
	 * @param mixed $rules Raw rules.
	 * @return array
	 */
	private static function sanitize_confirm_rules( $rules ) {
		if ( ! is_array( $rules ) ) {
			return [];
		}

		$clean = [];
		foreach ( $rules as $rule ) {
			if ( empty( $rule['field'] ) || empty( $rule['message'] ) ) {
				continue;
			}
			$clean[] = [
				'field'   => absint( $rule['field'] ),
				'value'   => isset( $rule['value'] ) ? sanitize_text_field( $rule['value'] ) : '',
				'message' => sanitize_textarea_field( $rule['message'] ),
			];
		}
		return $clean;
	}

	/**
	 * Sanitize a field's conditional-logic configuration.
	 *
	 * @param array $conditional Raw conditional config.
	 * @return array
	 */
	private static function sanitize_conditional( array $conditional ) {
		$action = isset( $conditional['action'] ) && 'hide' === $conditional['action'] ? 'hide' : 'show';
		$logic  = isset( $conditional['logic'] ) && 'or' === $conditional['logic'] ? 'or' : 'and';
		$rules  = [];

		if ( ! empty( $conditional['rules'] ) && is_array( $conditional['rules'] ) ) {
			foreach ( $conditional['rules'] as $rule ) {
				if ( ! isset( $rule['field'] ) || '' === $rule['field'] ) {
					continue;
				}

				$operator = isset( $rule['operator'] ) ? sanitize_key( $rule['operator'] ) : 'is';

				if ( ! in_array( $operator, [ 'is', 'is_not', 'empty', 'not_empty', 'contains' ], true ) ) {
					$operator = 'is';
				}

				$rules[] = [
					'field'    => (int) $rule['field'],
					'operator' => $operator,
					'value'    => isset( $rule['value'] ) ? sanitize_text_field( $rule['value'] ) : '',
				];
			}
		}

		return [
			'enabled' => ! empty( $conditional['enabled'] ) ? 1 : 0,
			'action'  => $action,
			'logic'   => $logic,
			'rules'   => $rules,
		];
	}

	/**
	 * Duplicate a form.
	 */
	private static function handle_duplicate() {
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		check_admin_referer( 'phemightforms_duplicate_' . $form_id );

		$form = new Form( $form_id );
		$new  = $form->duplicate();

		wp_safe_redirect(
			add_query_arg(
				[
					'page'    => Admin::SLUG_FORMS,
					'action'  => 'edit',
					'form'    => $new,
					'created' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Toggle starred state.
	 */
	private static function handle_star() {
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		check_admin_referer( 'phemightforms_star_' . $form_id );

		$form = new Form( $form_id );
		if ( $form->exists() ) {
			$form->set_starred( ! $form->is_starred() );
		}

		wp_safe_redirect( add_query_arg( [ 'page' => Admin::SLUG_FORMS ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Download form JSON export.
	 */
	private static function handle_export() {
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		check_admin_referer( 'phemightforms_export_' . $form_id );

		$form = new Form( $form_id );
		if ( ! $form->exists() ) {
			wp_die( esc_html__( 'Form not found.', 'phemightforms' ) );
		}

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="phemightform-' . $form_id . '.json"' );
		echo $form->export_json(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Import a form from uploaded JSON.
	 */
	private static function handle_import() {
		check_admin_referer( 'phemightforms_import' );

		if ( empty( $_FILES['phf_import_file']['tmp_name'] ) ) {
			wp_die( esc_html__( 'No file uploaded.', 'phemightforms' ) );
		}

		$raw  = file_get_contents( $_FILES['phf_import_file']['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$data = json_decode( $raw, true );

		if ( ! is_array( $data ) || empty( $data['config'] ) ) {
			wp_die( esc_html__( 'Invalid form JSON file.', 'phemightforms' ) );
		}

		$title  = isset( $data['title'] ) ? sanitize_text_field( $data['title'] ) : __( 'Imported Form', 'phemightforms' );
		$config = self::sanitize_config( $data['config'] );
		$id     = Form::save( $title, $config, 0 );

		wp_safe_redirect(
			add_query_arg(
				[
					'page'    => Admin::SLUG_FORMS,
					'action'  => 'edit',
					'form'    => $id,
					'created' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render a front-end preview in a minimal admin frame.
	 */
	private static function render_preview() {
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0;
		$form    = new Form( $form_id );

		if ( ! $form->exists() ) {
			wp_die( esc_html__( 'Form not found.', 'phemightforms' ) );
		}

		$frontend = new \PhemightForms\Frontend();
		wp_enqueue_style( 'phemightforms' );
		wp_enqueue_script( 'phemightforms' );
		\PhemightForms\Captcha::enqueue();
		wp_add_inline_style(
			'phemightforms',
			'body{margin:0;padding:2rem;background:#faf6ee;} .phf-preview-bar{background:#2e1f0b;color:#ffd66b;padding:.75rem 1.25rem;font-family:sans-serif;font-size:.875rem;margin:-2rem -2rem 2rem;}'
		);
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php echo esc_html( $form->title ); ?> · <?php esc_html_e( 'Preview', 'phemightforms' ); ?></title>
			<?php wp_head(); ?>
		</head>
		<body>
			<div class="phf-preview-bar"><?php esc_html_e( 'Preview mode: submissions will be saved normally.', 'phemightforms' ); ?></div>
			<?php echo $frontend->render( $form ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php wp_footer(); ?>
		</body>
		</html>
		<?php
		exit;
	}
}
