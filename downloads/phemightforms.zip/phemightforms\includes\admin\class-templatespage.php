<?php
/**
 * Form Templates gallery admin screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the searchable, categorised template gallery.
 */
class TemplatesPage {

	/**
	 * Build a miniature, non-interactive preview of a template's form,
	 * WPForms-style, from its field definitions.
	 *
	 * @param array $fields Template field definitions.
	 * @return string
	 */
	private static function preview_html( array $fields ) {
		if ( ! $fields ) {
			return '<div class="phf-mini-blank"><span class="dashicons dashicons-plus-alt2"></span></div>';
		}

		$out   = '<div class="phf-mini-form">';
		$shown = 0;

		foreach ( $fields as $field ) {
			if ( $shown >= 4 ) {
				break;
			}

			$type  = isset( $field['type'] ) ? $field['type'] : 'text';
			$label = isset( $field['label'] ) ? $field['label'] : '';

			// Layout-only fields don't help the preview.
			if ( in_array( $type, [ 'section', 'pagebreak', 'html', 'hidden' ], true ) ) {
				continue;
			}

			$out .= '<div class="phf-mini-field">';

			if ( '' !== $label ) {
				$out .= '<span class="phf-mini-label">' . esc_html( $label ) . '</span>';
			}

			switch ( $type ) {
				case 'name':
				case 'address':
					$out .= '<span class="phf-mini-row"><span class="phf-mini-input"></span><span class="phf-mini-input"></span></span>';
					break;

				case 'textarea':
					$out .= '<span class="phf-mini-input phf-mini-area"></span>';
					break;

				case 'radio':
				case 'checkbox':
				case 'image_choice':
				case 'payment_multiple':
					$dot  = 'checkbox' === $type ? 'phf-mini-square' : 'phf-mini-dot';
					$out .= '<span class="phf-mini-choices">';
					for ( $i = 0; $i < 2; $i++ ) {
						$out .= '<span class="phf-mini-choice"><span class="' . esc_attr( $dot ) . '"></span><span class="phf-mini-bar"></span></span>';
					}
					$out .= '</span>';
					break;

				case 'select':
				case 'country':
				case 'payment_select':
					$out .= '<span class="phf-mini-input phf-mini-select"><span class="phf-mini-caret"></span></span>';
					break;

				case 'consent':
					$out .= '<span class="phf-mini-choice"><span class="phf-mini-square"></span><span class="phf-mini-bar phf-mini-bar-long"></span></span>';
					break;

				case 'rating':
					$out .= '<span class="phf-mini-stars">★★★★★</span>';
					break;

				case 'signature':
					$out .= '<span class="phf-mini-input phf-mini-area phf-mini-sig">✎</span>';
					break;

				case 'payment_single':
				case 'payment_total':
					$out .= '<span class="phf-mini-price">' . esc_html( \PhemightForms\Payments::symbol() ) . '</span>';
					break;

				case 'payment_coupon':
					$out .= '<span class="phf-mini-row"><span class="phf-mini-input"></span><span class="phf-mini-btn phf-mini-btn-sm"></span></span>';
					break;

				default:
					$out .= '<span class="phf-mini-input"></span>';
			}

			$out .= '</div>';
			$shown++;
		}

		$out .= '<span class="phf-mini-btn"></span>';
		$out .= '</div>';

		return $out;
	}

	/**
	 * Render the gallery.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$templates  = Templates::all();
		$categories = Templates::categories();
		$counts     = [];

		foreach ( $templates as $template ) {
			$cat            = isset( $template['category'] ) ? $template['category'] : 'business';
			$counts[ $cat ] = isset( $counts[ $cat ] ) ? $counts[ $cat ] + 1 : 1;
		}
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'templates' ); ?>

			<div class="phf-page-body">
				<div class="phf-tpl-hero">
					<h2><?php esc_html_e( 'Get a Head Start With Our Premade Form Templates', 'phemightforms' ); ?></h2>
					<p><?php esc_html_e( 'Choose a template to speed up the process of creating your form. You can also start with a blank form or create your own.', 'phemightforms' ); ?></p>
					<div class="phf-tpl-search">
						<span class="dashicons dashicons-search"></span>
						<input type="search" id="phf-tpl-search" placeholder="<?php esc_attr_e( 'Search templates...', 'phemightforms' ); ?>">
					</div>
				</div>

				<div class="phf-tpl-layout">
					<aside class="phf-tpl-sidebar">
						<button type="button" class="phf-tpl-cat is-active" data-cat="all">
							<?php esc_html_e( 'All Templates', 'phemightforms' ); ?>
							<span class="phf-tpl-count"><?php echo esc_html( count( $templates ) ); ?></span>
						</button>
						<?php foreach ( $categories as $slug => $label ) : ?>
							<?php if ( empty( $counts[ $slug ] ) ) { continue; } ?>
							<button type="button" class="phf-tpl-cat" data-cat="<?php echo esc_attr( $slug ); ?>">
								<?php echo esc_html( $label ); ?>
								<span class="phf-tpl-count"><?php echo esc_html( $counts[ $slug ] ); ?></span>
							</button>
						<?php endforeach; ?>
					</aside>

					<div class="phf-tpl-main">
						<div class="phf-tpl-grid" id="phf-tpl-grid">
							<?php foreach ( $templates as $slug => $template ) : ?>
								<?php
								$create_url = wp_nonce_url(
									add_query_arg(
										[
											'page'     => Admin::SLUG_FORMS,
											'action'   => 'create',
											'template' => $slug,
										],
										admin_url( 'admin.php' )
									),
									'phemightforms_create_' . $slug
								);
								$cat        = isset( $template['category'] ) ? $template['category'] : 'business';
								$cat_label  = isset( $categories[ $cat ] ) ? $categories[ $cat ] : '';
								$is_blank   = 'blank' === $slug;
								?>
								<div class="phf-tpl-card<?php echo $is_blank ? ' phf-tpl-card-blank' : ''; ?>" data-cat="<?php echo esc_attr( $cat ); ?>" data-search="<?php echo esc_attr( strtolower( $template['name'] . ' ' . $template['description'] . ' ' . $cat_label ) ); ?>">
									<div class="phf-tpl-preview" aria-hidden="true">
										<?php echo self::preview_html( $template['fields'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?>
										<?php if ( ! $is_blank ) : ?>
											<span class="phf-tpl-tag"><?php echo esc_html( $cat_label ); ?></span>
										<?php endif; ?>
									</div>
									<h3><?php echo esc_html( $template['name'] ); ?></h3>
									<p><?php echo esc_html( $template['description'] ); ?></p>
									<div class="phf-tpl-card-actions">
										<a href="<?php echo esc_url( $create_url ); ?>" class="phf-btn phf-btn-primary phf-btn-sm">
											<?php echo $is_blank ? esc_html__( 'Create Blank Form', 'phemightforms' ) : esc_html__( 'Create Form', 'phemightforms' ); ?>
										</a>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
						<div class="phf-tpl-none" id="phf-tpl-none" hidden>
							<span class="dashicons dashicons-search"></span>
							<p><?php esc_html_e( 'No templates match your search. Try a different keyword or start with a blank form.', 'phemightforms' ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php ob_start(); ?>
			( function () {
				var search = document.getElementById( 'phf-tpl-search' );
				var grid = document.getElementById( 'phf-tpl-grid' );
				var none = document.getElementById( 'phf-tpl-none' );
				var cats = document.querySelectorAll( '.phf-tpl-cat' );
				var activeCat = 'all';

				function apply() {
					var term = ( search.value || '' ).toLowerCase().trim();
					var visible = 0;

					grid.querySelectorAll( '.phf-tpl-card' ).forEach( function ( card ) {
						var matchCat = activeCat === 'all' || card.getAttribute( 'data-cat' ) === activeCat;
						var matchTerm = ! term || card.getAttribute( 'data-search' ).indexOf( term ) !== -1;
						var show = matchCat && matchTerm;
						card.style.display = show ? '' : 'none';
						if ( show ) {
							visible++;
						}
					} );

					none.hidden = visible > 0;
				}

				cats.forEach( function ( btn ) {
					btn.addEventListener( 'click', function () {
						cats.forEach( function ( b ) {
							b.classList.remove( 'is-active' );
						} );
						btn.classList.add( 'is-active' );
						activeCat = btn.getAttribute( 'data-cat' );
						apply();
					} );
				} );

				if ( search ) {
					search.addEventListener( 'input', apply );
				}
			} )();
		<?php wp_add_inline_script( 'phemightforms-admin', ob_get_clean() ); ?>
		<?php
	}
}
