/**
 * PhemightForms Gutenberg block.
 *
 * A simple block that lets the editor pick a form to embed.
 */
( function ( blocks, element, components, blockEditor, i18n ) {
	'use strict';

	var el = element.createElement;
	var __ = i18n.__;
	var SelectControl = components.SelectControl;
	var Placeholder = components.Placeholder;
	var useBlockProps = blockEditor.useBlockProps;

	var forms = ( window.PhemightFormsBlock && window.PhemightFormsBlock.forms ) || [];

	var options = [ { value: 0, label: __( 'Select a form…', 'phemightforms' ) } ].concat(
		forms.map( function ( f ) {
			return { value: f.value, label: f.label };
		} )
	);

	blocks.registerBlockType( 'phemightforms/form', {
		title: __( 'PhemightForms', 'phemightforms' ),
		icon: 'feedback',
		category: 'widgets',
		attributes: {
			formId: { type: 'number', default: 0 },
		},

		edit: function ( props ) {
			var blockProps = useBlockProps();

			return el(
				'div',
				blockProps,
				el(
					Placeholder,
					{
						icon: 'feedback',
						label: __( 'PhemightForms', 'phemightforms' ),
						instructions: __( 'Choose a form to display.', 'phemightforms' ),
					},
					el( SelectControl, {
						value: props.attributes.formId,
						options: options,
						onChange: function ( value ) {
							props.setAttributes( { formId: parseInt( value, 10 ) || 0 } );
						},
					} )
				)
			);
		},

		save: function () {
			// Rendered server-side via render_callback.
			return null;
		},
	} );
} )(
	window.wp.blocks,
	window.wp.element,
	window.wp.components,
	window.wp.blockEditor,
	window.wp.i18n
);
