<?php
/**
 * SMTP configuration screen.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Mail;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dedicated SMTP settings page and test email handler.
 */
class SMTP {

	/**
	 * Register the test-email handler.
	 */
	public function __construct() {
		add_action( 'admin_post_phemightforms_smtp_test', [ $this, 'handle_smtp_test' ] );
	}

	/**
	 * Send a test email after saving SMTP settings.
	 */
	public function handle_smtp_test() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_smtp_test' );

		$to     = isset( $_POST['test_email'] ) ? sanitize_email( wp_unslash( $_POST['test_email'] ) ) : get_option( 'admin_email' );
		$result = Mail::send_test( $to );

		wp_safe_redirect(
			add_query_arg(
				[
					'page'      => Admin::SLUG . '-smtp',
					'smtp_test' => is_wp_error( $result ) ? 'fail' : 'ok',
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render the SMTP settings page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$settings = get_option( 'phemightforms_settings', [] );
		$get      = static function ( $key, $default = '' ) use ( $settings ) {
			return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
		};
		$mailer   = $get( 'smtp_mailer', '' );
		if ( ! in_array( $mailer, [ 'default', 'smtp' ], true ) ) {
			$mailer = $get( 'smtp_enabled', 0 ) ? 'smtp' : 'default';
		}
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'smtp' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'SMTP', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'Configure outgoing mail for form notification emails.', 'phemightforms' ); ?></p>
					</div>
				</div>

				<?php if ( isset( $_GET['smtp_test'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-<?php echo 'ok' === $_GET['smtp_test'] ? 'success' : 'error'; ?>">
						<?php echo 'ok' === $_GET['smtp_test'] ? esc_html__( 'Test email sent successfully.', 'phemightforms' ) : esc_html__( 'Test email failed. Check your mail settings.', 'phemightforms' ); ?>
					</div>
				<?php endif; ?>

				<form method="post" action="options.php">
					<?php settings_fields( 'phemightforms_settings_group' ); ?>
					<input type="hidden" name="_wp_http_referer" value="<?php echo esc_url( add_query_arg( [ 'page' => Admin::SLUG . '-smtp' ], admin_url( 'admin.php' ) ) ); ?>">

					<div class="phf-card-panel phf-settings-card">
						<div class="phf-panel-head">
							<h3><?php esc_html_e( 'Mail Configuration', 'phemightforms' ); ?></h3>
							<span class="phf-muted"><?php esc_html_e( 'Choose how form notification emails are delivered.', 'phemightforms' ); ?></span>
						</div>

						<div class="phf-setting-row phf-setting-row-stack">
							<div class="phf-setting-label">
								<span class="phf-setting-title"><?php esc_html_e( 'Mailer', 'phemightforms' ); ?></span>
								<p><?php esc_html_e( 'Default (none) uses PHP mail automatically through WordPress. No SMTP setup required.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-field">
								<div class="phf-radio-pills phf-mailer-pills" role="radiogroup" aria-label="<?php esc_attr_e( 'Mailer', 'phemightforms' ); ?>">
									<label class="phf-pill">
										<input type="radio" name="phemightforms_settings[smtp_mailer]" value="default" <?php checked( $mailer, 'default' ); ?>>
										<span><?php esc_html_e( 'Default (none)', 'phemightforms' ); ?></span>
									</label>
									<label class="phf-pill">
										<input type="radio" name="phemightforms_settings[smtp_mailer]" value="smtp" <?php checked( $mailer, 'smtp' ); ?>>
										<span><?php esc_html_e( 'Custom SMTP', 'phemightforms' ); ?></span>
									</label>
								</div>
							</div>
						</div>

						<div id="phf-smtp-custom-fields" class="phf-smtp-custom-fields"<?php echo 'smtp' === $mailer ? '' : ' hidden'; ?>>
						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-smtp-host"><?php esc_html_e( 'SMTP Host', 'phemightforms' ); ?></label>
							</div>
							<div class="phf-setting-field">
								<input type="text" id="phf-smtp-host" name="phemightforms_settings[smtp_host]" value="<?php echo esc_attr( $get( 'smtp_host', '' ) ); ?>" placeholder="smtp.example.com">
							</div>
						</div>

						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-smtp-enc"><?php esc_html_e( 'Encryption', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'TLS is recommended for most servers.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-field">
								<div class="phf-radio-pills">
									<label class="phf-pill"><input type="radio" name="phemightforms_settings[smtp_encryption]" value="none" <?php checked( $get( 'smtp_encryption', 'tls' ), 'none' ); ?>><span><?php esc_html_e( 'None', 'phemightforms' ); ?></span></label>
									<label class="phf-pill"><input type="radio" name="phemightforms_settings[smtp_encryption]" value="ssl" <?php checked( $get( 'smtp_encryption', 'tls' ), 'ssl' ); ?>><span>SSL</span></label>
									<label class="phf-pill"><input type="radio" name="phemightforms_settings[smtp_encryption]" value="tls" <?php checked( $get( 'smtp_encryption', 'tls' ), 'tls' ); ?>><span>TLS</span></label>
								</div>
							</div>
						</div>

						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-smtp-port"><?php esc_html_e( 'SMTP Port', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( '587 for TLS, 465 for SSL, 25 for none.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-field">
								<input type="number" id="phf-smtp-port" class="phf-input-sm" name="phemightforms_settings[smtp_port]" value="<?php echo esc_attr( $get( 'smtp_port', 587 ) ); ?>">
							</div>
						</div>

						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label><?php esc_html_e( 'Authentication', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Most SMTP servers require a username and password.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-field">
								<input type="hidden" name="phemightforms_settings[smtp_auth]" value="0">
								<label class="phf-toggle">
									<input type="checkbox" name="phemightforms_settings[smtp_auth]" value="1" <?php checked( $get( 'smtp_auth', 1 ), 1 ); ?>>
									<span class="phf-toggle-track"></span>
								</label>
							</div>
						</div>

						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-smtp-user"><?php esc_html_e( 'SMTP Username', 'phemightforms' ); ?></label>
							</div>
							<div class="phf-setting-field">
								<input type="text" id="phf-smtp-user" name="phemightforms_settings[smtp_user]" value="<?php echo esc_attr( $get( 'smtp_user', '' ) ); ?>" autocomplete="off">
							</div>
						</div>

						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-smtp-pass"><?php esc_html_e( 'SMTP Password', 'phemightforms' ); ?></label>
								<p><?php esc_html_e( 'Stored securely. Leave blank to keep the current password.', 'phemightforms' ); ?></p>
							</div>
							<div class="phf-setting-field">
								<input type="password" id="phf-smtp-pass" name="phemightforms_settings[smtp_pass]" value="" placeholder="••••••••" autocomplete="new-password">
							</div>
						</div>
						</div>
					</div>

					<div class="phf-card-panel phf-settings-card">
						<div class="phf-panel-head">
							<h3><?php esc_html_e( 'Sender Details', 'phemightforms' ); ?></h3>
							<span class="phf-muted"><?php esc_html_e( 'Who your notification emails appear to come from.', 'phemightforms' ); ?></span>
						</div>

						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-smtp-from-email"><?php esc_html_e( 'From Email', 'phemightforms' ); ?></label>
							</div>
							<div class="phf-setting-field">
								<input type="email" id="phf-smtp-from-email" name="phemightforms_settings[smtp_from_email]" value="<?php echo esc_attr( $get( 'smtp_from_email', '' ) ); ?>" placeholder="no-reply@yourdomain.com">
							</div>
						</div>

						<div class="phf-setting-row">
							<div class="phf-setting-label">
								<label for="phf-smtp-from-name"><?php esc_html_e( 'From Name', 'phemightforms' ); ?></label>
							</div>
							<div class="phf-setting-field">
								<input type="text" id="phf-smtp-from-name" name="phemightforms_settings[smtp_from_name]" value="<?php echo esc_attr( $get( 'smtp_from_name', '' ) ); ?>" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
							</div>
						</div>
					</div>

					<div class="phf-settings-actions">
						<button type="submit" class="phf-btn phf-btn-primary phf-btn-lg"><?php esc_html_e( 'Save Settings', 'phemightforms' ); ?></button>
					</div>
				</form>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="phf-card-panel phf-settings-card">
					<?php wp_nonce_field( 'phemightforms_smtp_test' ); ?>
					<input type="hidden" name="action" value="phemightforms_smtp_test">
					<div class="phf-panel-head">
						<h3><?php esc_html_e( 'Send a Test Email', 'phemightforms' ); ?></h3>
						<span class="phf-muted"><?php esc_html_e( 'Save your settings first, then confirm delivery works.', 'phemightforms' ); ?></span>
					</div>
					<div class="phf-setting-row">
						<div class="phf-setting-label">
							<label for="phf-smtp-test"><?php esc_html_e( 'Send To', 'phemightforms' ); ?></label>
						</div>
						<div class="phf-setting-field phf-setting-inline">
							<input type="email" id="phf-smtp-test" name="test_email" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" required>
							<button type="submit" class="phf-btn phf-btn-primary"><span class="dashicons dashicons-email-alt"></span><?php esc_html_e( 'Send Test', 'phemightforms' ); ?></button>
						</div>
					</div>
				</form>

				<?php ob_start(); ?>
					( function () {
						var mailers = document.querySelectorAll( 'input[name="phemightforms_settings[smtp_mailer]"]' );
						var fields = document.getElementById( 'phf-smtp-custom-fields' );
						if ( ! mailers.length || ! fields ) {
							return;
						}
						function toggleSmtpFields() {
							var selected = 'smtp';
							mailers.forEach( function ( input ) {
								if ( input.checked ) {
									selected = input.value;
								}
							} );
							fields.hidden = selected !== 'smtp';
						}
						mailers.forEach( function ( input ) {
							input.addEventListener( 'change', toggleSmtpFields );
						} );
						toggleSmtpFields();
					} )();
				<?php wp_add_inline_script( 'phemightforms-admin', ob_get_clean() ); ?>
			</div>
		</div>
		<?php
	}
}
