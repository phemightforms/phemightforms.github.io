<?php
/**
 * Main plugin orchestrator.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Wires together every component of the plugin.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Field registry.
	 *
	 * @var Fields
	 */
	public $fields;

	/**
	 * Return the shared instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}

		return self::$instance;
	}

	/**
	 * Initialise components.
	 */
	private function boot() {
		Install::maybe_upgrade();

		$this->fields = new Fields();

		add_action( 'init', [ Form::class, 'register_post_type' ] );

		new Mail();
		new Landing();
		new Frontend();
		new Submission();
		new Block();
		new Export();
		new SaveResume();
		new Payments();
		new Privacy();
		new Invoices();
		new AuthForms();

		if ( is_admin() ) {
			new Admin\Admin();
			new Admin\Builder();
			new Admin\Entries();
			new Admin\Settings();
			new Admin\SMTP();
			new Admin\Reports();
			new Admin\PaymentsPage();
			new Admin\InvoicesPage();
			new Admin\PrivacyPage();
			new Admin\CaptchaPage();
			new Admin\BackupPage();
			new Admin\AuthFormsPage();
		}
	}

	/**
	 * Read a plugin option with a default.
	 *
	 * @param string $key     Option key inside the settings array.
	 * @param mixed  $default Fallback value.
	 * @return mixed
	 */
	public static function get_option( $key, $default = '' ) {
		$options = get_option( 'phemightforms_settings', [] );

		return isset( $options[ $key ] ) ? $options[ $key ] : $default;
	}
}
