<?php
/**
 * Payments admin screen: transactions, providers, and coupons.
 *
 * @package PhemightForms
 */

namespace PhemightForms\Admin;

use PhemightForms\Payments;
use PhemightForms\Form;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and saves the Payments page.
 */
class PaymentsPage {

	/**
	 * Secret-type option keys: a blank submission keeps the stored value.
	 *
	 * @var string[]
	 */
	const SECRET_KEYS = [
		'stripe_secret',
		'paystack_secret',
		'flutterwave_secret',
		'razorpay_secret',
		'mollie_key',
		'square_token',
		'coinbase_key',
		'nowpayments_key',
	];

	/**
	 * Toggle option keys.
	 *
	 * @var string[]
	 */
	const TOGGLE_KEYS = [
		'stripe_enabled',
		'paypal_enabled',
		'paypal_sandbox',
		'paystack_enabled',
		'flutterwave_enabled',
		'razorpay_enabled',
		'mollie_enabled',
		'square_enabled',
		'coinbase_enabled',
		'nowpayments_enabled',
		'cryptowallet_enabled',
		'offline_enabled',
	];

	/**
	 * Plain text option keys.
	 *
	 * @var string[]
	 */
	const TEXT_KEYS = [
		'stripe_publishable',
		'razorpay_key_id',
		'square_location',
	];

	/**
	 * Textarea option keys.
	 *
	 * @var string[]
	 */
	const TEXTAREA_KEYS = [
		'cryptowallet_addresses',
		'cryptowallet_note',
		'offline_instructions',
	];

	/**
	 * Hook the save handler.
	 */
	public function __construct() {
		add_action( 'admin_post_phemightforms_save_payments', [ $this, 'handle_save' ] );
	}

	/**
	 * Persist provider settings or coupons, depending on the active tab.
	 */
	public function handle_save() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		check_admin_referer( 'phemightforms_payments' );

		$settings = Payments::settings();
		$tab      = isset( $_POST['active_tab'] ) ? sanitize_key( wp_unslash( $_POST['active_tab'] ) ) : 'providers';

		if ( 'coupons' === $tab ) {
			$settings['coupons'] = self::read_coupons();
		} else {
			$currency = isset( $_POST['currency'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['currency'] ) ) ) : 'USD';

			$settings['currency'] = isset( Payments::currencies()[ $currency ] ) ? $currency : 'USD';

			foreach ( self::TOGGLE_KEYS as $key ) {
				$settings[ $key ] = ! empty( $_POST[ $key ] ) ? 1 : 0;
			}

			foreach ( self::TEXT_KEYS as $key ) {
				$settings[ $key ] = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
			}

			foreach ( self::TEXTAREA_KEYS as $key ) {
				$settings[ $key ] = isset( $_POST[ $key ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : '';
			}

			$settings['paypal_email'] = isset( $_POST['paypal_email'] ) ? sanitize_email( wp_unslash( $_POST['paypal_email'] ) ) : '';

			foreach ( self::SECRET_KEYS as $key ) {
				$value = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';

				if ( '' !== $value ) {
					$settings[ $key ] = $value;
				}
			}
		}

		update_option( Payments::OPTION, $settings );

		wp_safe_redirect(
			add_query_arg(
				[
					'page'  => Admin::SLUG . '-payments',
					'tab'   => $tab,
					'saved' => 1,
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Read the coupon rows out of the request.
	 *
	 * @return array
	 */
	private static function read_coupons() {
		$coupons = [];

		if ( ! isset( $_POST['coupon_code'] ) || ! is_array( $_POST['coupon_code'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return $coupons;
		}

		$codes   = array_map( 'sanitize_text_field', wp_unslash( $_POST['coupon_code'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput,WordPress.Security.NonceVerification.Missing
		$types   = isset( $_POST['coupon_type'] ) ? array_map( 'sanitize_key', wp_unslash( (array) $_POST['coupon_type'] ) ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput,WordPress.Security.NonceVerification.Missing
		$amounts = isset( $_POST['coupon_amount'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['coupon_amount'] ) ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput,WordPress.Security.NonceVerification.Missing

		foreach ( $codes as $i => $code ) {
			$code = trim( $code );

			if ( '' === $code ) {
				continue;
			}

			$coupons[] = [
				'code'   => $code,
				'type'   => isset( $types[ $i ] ) && 'fixed' === $types[ $i ] ? 'fixed' : 'percent',
				'amount' => Payments::to_amount( isset( $amounts[ $i ] ) ? $amounts[ $i ] : 0 ),
			];
		}

		return $coupons;
	}

	/**
	 * Render the Payments page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Permission denied.', 'phemightforms' ) );
		}

		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! in_array( $tab, [ 'overview', 'providers', 'coupons' ], true ) ) {
			$tab = 'overview';
		}

		$settings = Payments::settings();
		$base_url = add_query_arg( [ 'page' => Admin::SLUG . '-payments' ], admin_url( 'admin.php' ) );
		?>
		<div class="wrap phemightforms-wrap phf-page">
			<?php Admin::header( 'payments' ); ?>

			<div class="phf-page-body">
				<div class="phf-page-title">
					<div>
						<h2><?php esc_html_e( 'Payments', 'phemightforms' ); ?></h2>
						<p class="phf-muted"><?php esc_html_e( 'Accept cards, mobile money, and crypto on your forms. Enable the payment methods you want, then add payment fields to any form in the builder.', 'phemightforms' ); ?></p>
					</div>
				</div>

				<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="phf-notice phf-notice-success"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Payment settings saved.', 'phemightforms' ); ?></div>
				<?php endif; ?>

				<div class="phf-subnav">
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'overview', $base_url ) ); ?>" class="phf-subnav-item<?php echo 'overview' === $tab ? ' is-active' : ''; ?>"><span class="dashicons dashicons-chart-area"></span> <?php esc_html_e( 'Overview', 'phemightforms' ); ?></a>
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'providers', $base_url ) ); ?>" class="phf-subnav-item<?php echo 'providers' === $tab ? ' is-active' : ''; ?>"><span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e( 'Payment Methods', 'phemightforms' ); ?></a>
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'coupons', $base_url ) ); ?>" class="phf-subnav-item<?php echo 'coupons' === $tab ? ' is-active' : ''; ?>"><span class="dashicons dashicons-tickets-alt"></span> <?php esc_html_e( 'Coupons', 'phemightforms' ); ?></a>
				</div>

				<?php
				if ( 'overview' === $tab ) {
					self::render_overview();
				} elseif ( 'providers' === $tab ) {
					self::render_providers( $settings );
				} else {
					self::render_coupons( $settings );
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Transactions list plus revenue stat cards.
	 */
	private static function render_overview() {
		$transactions = Payments::transactions();
		$paid_total   = 0;
		$pending      = 0;

		foreach ( $transactions as $txn ) {
			if ( 'paid' === $txn['status'] ) {
				$paid_total += (float) $txn['amount'];
			} else {
				$pending++;
			}
		}
		?>
		<div class="phf-stat-grid">
			<div class="phf-stat-card">
				<span class="phf-stat-icon phf-tint-green"><span class="dashicons dashicons-money-alt"></span></span>
				<div><span class="phf-stat-number"><?php echo esc_html( Payments::format( $paid_total ) ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Total Collected', 'phemightforms' ); ?></span></div>
			</div>
			<div class="phf-stat-card">
				<span class="phf-stat-icon phf-tint-blue"><span class="dashicons dashicons-cart"></span></span>
				<div><span class="phf-stat-number"><?php echo esc_html( count( $transactions ) ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Transactions', 'phemightforms' ); ?></span></div>
			</div>
			<div class="phf-stat-card">
				<span class="phf-stat-icon phf-tint-amber"><span class="dashicons dashicons-clock"></span></span>
				<div><span class="phf-stat-number"><?php echo esc_html( $pending ); ?></span><span class="phf-stat-label"><?php esc_html_e( 'Pending', 'phemightforms' ); ?></span></div>
			</div>
		</div>

		<div class="phf-card-panel phf-table-panel">
			<div class="phf-panel-head">
				<h3><?php esc_html_e( 'Recent Transactions', 'phemightforms' ); ?></h3>
			</div>
			<?php if ( ! $transactions ) : ?>
				<div class="phf-empty-state">
					<span class="dashicons dashicons-money-alt"></span>
					<p><?php esc_html_e( 'No transactions yet. Add payment fields to a form, enable a payment method, and payments will show up here.', 'phemightforms' ); ?></p>
				</div>
			<?php else : ?>
				<table class="phf-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Date', 'phemightforms' ); ?></th>
							<th><?php esc_html_e( 'Form', 'phemightforms' ); ?></th>
							<th><?php esc_html_e( 'Amount', 'phemightforms' ); ?></th>
							<th><?php esc_html_e( 'Method', 'phemightforms' ); ?></th>
							<th><?php esc_html_e( 'Coupon', 'phemightforms' ); ?></th>
							<th><?php esc_html_e( 'Status', 'phemightforms' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( array_slice( $transactions, 0, 50 ) as $txn ) : ?>
							<?php
							$form      = new Form( (int) $txn['form_id'] );
							$providers = Payments::providers();
							$method    = isset( $providers[ $txn['method'] ] ) ? $providers[ $txn['method'] ] : ucfirst( $txn['method'] );
							?>
							<tr>
								<td data-label="<?php esc_attr_e( 'Date', 'phemightforms' ); ?>"><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $txn['date'] ) ); ?></td>
								<td data-label="<?php esc_attr_e( 'Form', 'phemightforms' ); ?>"><?php echo esc_html( $form->exists() ? $form->title : '#' . (int) $txn['form_id'] ); ?></td>
								<td data-label="<?php esc_attr_e( 'Amount', 'phemightforms' ); ?>"><strong><?php echo esc_html( Payments::format( $txn['amount'] ) ); ?></strong></td>
								<td data-label="<?php esc_attr_e( 'Method', 'phemightforms' ); ?>"><?php echo esc_html( $method ); ?></td>
								<td data-label="<?php esc_attr_e( 'Coupon', 'phemightforms' ); ?>"><?php echo esc_html( $txn['coupon'] ? $txn['coupon'] : __( 'None', 'phemightforms' ) ); ?></td>
								<td data-label="<?php esc_attr_e( 'Status', 'phemightforms' ); ?>">
									<span class="phf-badge <?php echo 'paid' === $txn['status'] ? 'phf-badge-success' : 'phf-badge-warning'; ?>"><?php echo esc_html( ucfirst( $txn['status'] ) ); ?></span>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Output one settings row inside a provider card.
	 *
	 * @param string $type  Control type: toggle|text|password|email|textarea.
	 * @param string $name  Option key / input name.
	 * @param string $label Row label.
	 * @param string $value Current value.
	 * @param string $ph    Placeholder.
	 * @param string $hint  Optional helper text.
	 */
	private static function row( $type, $name, $label, $value = '', $ph = '', $hint = '' ) {
		?>
		<div class="phf-setting-row">
			<div class="phf-setting-label">
				<label for="phf-<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
				<?php if ( $hint ) : ?><p><?php echo esc_html( $hint ); ?></p><?php endif; ?>
			</div>
			<div class="phf-setting-control">
				<?php if ( 'toggle' === $type ) : ?>
					<label class="phf-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $value ); ?>><span class="phf-toggle-track"></span></label>
				<?php elseif ( 'textarea' === $type ) : ?>
					<textarea id="phf-<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="3" placeholder="<?php echo esc_attr( $ph ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
				<?php elseif ( 'password' === $type ) : ?>
					<input type="password" id="phf-<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" value="" placeholder="<?php echo esc_attr( $value ? '••••••••' : $ph ); ?>" autocomplete="new-password">
				<?php else : ?>
					<input type="<?php echo esc_attr( $type ); ?>" id="phf-<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" placeholder="<?php echo esc_attr( $ph ); ?>">
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Open a provider card.
	 *
	 * @param string $logo_class CSS class for the logo chip.
	 * @param string $logo_text  Letter(s) or icon markup inside the chip.
	 * @param string $title      Provider name.
	 * @param string $desc       One-line description.
	 * @param bool   $active     Whether the provider is enabled and ready.
	 */
	private static function card_open( $logo_class, $logo_text, $title, $desc, $active = false ) {
		?>
		<div class="phf-card-panel phf-settings-card phf-provider-card">
			<div class="phf-panel-head phf-provider-head">
				<h3>
					<span class="phf-provider-logo <?php echo esc_attr( $logo_class ); ?>"><?php echo $logo_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup. ?></span>
					<?php echo esc_html( $title ); ?>
					<?php if ( $active ) : ?>
						<span class="phf-badge phf-badge-success"><?php esc_html_e( 'Active', 'phemightforms' ); ?></span>
					<?php endif; ?>
				</h3>
				<span class="phf-muted"><?php echo esc_html( $desc ); ?></span>
			</div>
		<?php
	}

	/**
	 * Providers tab.
	 *
	 * @param array $settings Payment settings.
	 */
	private static function render_providers( array $settings ) {
		$enabled = Payments::enabled_providers();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'phemightforms_payments' ); ?>
			<input type="hidden" name="action" value="phemightforms_save_payments">
			<input type="hidden" name="active_tab" value="providers">

			<div class="phf-card-panel phf-settings-card">
				<div class="phf-panel-head">
					<h3><?php esc_html_e( 'General', 'phemightforms' ); ?></h3>
				</div>
				<div class="phf-setting-row">
					<div class="phf-setting-label">
						<label for="phf-currency"><?php esc_html_e( 'Currency', 'phemightforms' ); ?></label>
						<p><?php esc_html_e( 'Used for all payment forms and totals.', 'phemightforms' ); ?></p>
					</div>
					<div class="phf-setting-control">
						<select id="phf-currency" name="currency">
							<?php foreach ( Payments::currencies() as $code => $symbol ) : ?>
								<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $settings['currency'], $code ); ?>><?php echo esc_html( $code . ' (' . $symbol . ')' ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<h3 class="phf-provider-section"><span class="dashicons dashicons-admin-site-alt3"></span> <?php esc_html_e( 'Cards & Wallets', 'phemightforms' ); ?></h3>

			<?php self::card_open( 'phf-logo-stripe', 'S', __( 'Stripe', 'phemightforms' ), __( 'Cards, Apple Pay, and Google Pay via Stripe Checkout. Worldwide.', 'phemightforms' ), isset( $enabled['stripe'] ) ); ?>
				<?php self::row( 'toggle', 'stripe_enabled', __( 'Enable Stripe', 'phemightforms' ), $settings['stripe_enabled'] ); ?>
				<?php self::row( 'text', 'stripe_publishable', __( 'Publishable Key', 'phemightforms' ), $settings['stripe_publishable'], 'pk_live_...' ); ?>
				<?php self::row( 'password', 'stripe_secret', __( 'Secret Key', 'phemightforms' ), $settings['stripe_secret'], 'sk_live_...', __( 'Stored securely. Leave blank to keep the current key.', 'phemightforms' ) ); ?>
			</div>

			<?php self::card_open( 'phf-logo-paypal', 'P', __( 'PayPal', 'phemightforms' ), __( 'Send customers to PayPal checkout. Only your PayPal email is needed.', 'phemightforms' ), isset( $enabled['paypal'] ) ); ?>
				<?php self::row( 'toggle', 'paypal_enabled', __( 'Enable PayPal', 'phemightforms' ), $settings['paypal_enabled'] ); ?>
				<?php self::row( 'email', 'paypal_email', __( 'PayPal Email', 'phemightforms' ), $settings['paypal_email'], 'you@business.com' ); ?>
				<?php self::row( 'toggle', 'paypal_sandbox', __( 'Sandbox Mode', 'phemightforms' ), $settings['paypal_sandbox'], '', __( 'Use PayPal sandbox for testing. Turn off for real payments.', 'phemightforms' ) ); ?>
			</div>

			<?php self::card_open( 'phf-logo-square', '▢', __( 'Square', 'phemightforms' ), __( 'Square hosted checkout links for cards and digital wallets.', 'phemightforms' ), isset( $enabled['square'] ) ); ?>
				<?php self::row( 'toggle', 'square_enabled', __( 'Enable Square', 'phemightforms' ), $settings['square_enabled'] ); ?>
				<?php self::row( 'password', 'square_token', __( 'Access Token', 'phemightforms' ), $settings['square_token'], 'EAAA...', __( 'Stored securely. Leave blank to keep the current token.', 'phemightforms' ) ); ?>
				<?php self::row( 'text', 'square_location', __( 'Location ID', 'phemightforms' ), $settings['square_location'], 'L1234...' ); ?>
			</div>

			<?php self::card_open( 'phf-logo-mollie', 'M', __( 'Mollie', 'phemightforms' ), __( 'iDEAL, Bancontact, SEPA, cards, and more. Popular in Europe.', 'phemightforms' ), isset( $enabled['mollie'] ) ); ?>
				<?php self::row( 'toggle', 'mollie_enabled', __( 'Enable Mollie', 'phemightforms' ), $settings['mollie_enabled'] ); ?>
				<?php self::row( 'password', 'mollie_key', __( 'API Key', 'phemightforms' ), $settings['mollie_key'], 'live_...', __( 'Stored securely. Leave blank to keep the current key.', 'phemightforms' ) ); ?>
			</div>

			<h3 class="phf-provider-section"><span class="dashicons dashicons-admin-site"></span> <?php esc_html_e( 'Africa & Asia', 'phemightforms' ); ?></h3>

			<?php self::card_open( 'phf-logo-paystack', 'PS', __( 'Paystack', 'phemightforms' ), __( 'Cards, bank transfer, USSD, and mobile money. Popular in Nigeria, Ghana, and Kenya.', 'phemightforms' ), isset( $enabled['paystack'] ) ); ?>
				<?php self::row( 'toggle', 'paystack_enabled', __( 'Enable Paystack', 'phemightforms' ), $settings['paystack_enabled'] ); ?>
				<?php self::row( 'password', 'paystack_secret', __( 'Secret Key', 'phemightforms' ), $settings['paystack_secret'], 'sk_live_...', __( 'Stored securely. Leave blank to keep the current key.', 'phemightforms' ) ); ?>
			</div>

			<?php self::card_open( 'phf-logo-flutterwave', 'F', __( 'Flutterwave', 'phemightforms' ), __( 'Cards, mobile money, and bank payments across Africa.', 'phemightforms' ), isset( $enabled['flutterwave'] ) ); ?>
				<?php self::row( 'toggle', 'flutterwave_enabled', __( 'Enable Flutterwave', 'phemightforms' ), $settings['flutterwave_enabled'] ); ?>
				<?php self::row( 'password', 'flutterwave_secret', __( 'Secret Key', 'phemightforms' ), $settings['flutterwave_secret'], 'FLWSECK-...', __( 'Stored securely. Leave blank to keep the current key.', 'phemightforms' ) ); ?>
			</div>

			<?php self::card_open( 'phf-logo-razorpay', 'R', __( 'Razorpay', 'phemightforms' ), __( 'Cards, UPI, netbanking, and wallets. Popular in India.', 'phemightforms' ), isset( $enabled['razorpay'] ) ); ?>
				<?php self::row( 'toggle', 'razorpay_enabled', __( 'Enable Razorpay', 'phemightforms' ), $settings['razorpay_enabled'] ); ?>
				<?php self::row( 'text', 'razorpay_key_id', __( 'Key ID', 'phemightforms' ), $settings['razorpay_key_id'], 'rzp_live_...' ); ?>
				<?php self::row( 'password', 'razorpay_secret', __( 'Key Secret', 'phemightforms' ), $settings['razorpay_secret'], '', __( 'Stored securely. Leave blank to keep the current secret.', 'phemightforms' ) ); ?>
			</div>

			<h3 class="phf-provider-section"><span class="dashicons dashicons-money-alt"></span> <?php esc_html_e( 'Crypto', 'phemightforms' ); ?></h3>

			<?php self::card_open( 'phf-logo-coinbase', 'C', __( 'Coinbase Commerce', 'phemightforms' ), __( 'Accept Bitcoin, Ethereum, USDC, and more with a hosted crypto checkout.', 'phemightforms' ), isset( $enabled['coinbase'] ) ); ?>
				<?php self::row( 'toggle', 'coinbase_enabled', __( 'Enable Coinbase Commerce', 'phemightforms' ), $settings['coinbase_enabled'] ); ?>
				<?php self::row( 'password', 'coinbase_key', __( 'API Key', 'phemightforms' ), $settings['coinbase_key'], '', __( 'From Coinbase Commerce settings. Leave blank to keep the current key.', 'phemightforms' ) ); ?>
			</div>

			<?php self::card_open( 'phf-logo-nowpayments', 'N', __( 'NOWPayments', 'phemightforms' ), __( 'Hosted invoices for 300+ cryptocurrencies including BTC, ETH, USDT, and BNB.', 'phemightforms' ), isset( $enabled['nowpayments'] ) ); ?>
				<?php self::row( 'toggle', 'nowpayments_enabled', __( 'Enable NOWPayments', 'phemightforms' ), $settings['nowpayments_enabled'] ); ?>
				<?php self::row( 'password', 'nowpayments_key', __( 'API Key', 'phemightforms' ), $settings['nowpayments_key'], '', __( 'Stored securely. Leave blank to keep the current key.', 'phemightforms' ) ); ?>
			</div>

			<?php self::card_open( 'phf-logo-cryptowallet', '₿', __( 'Crypto Wallet (Direct Transfer)', 'phemightforms' ), __( 'No account needed: show your wallet addresses and let customers send crypto directly.', 'phemightforms' ), isset( $enabled['cryptowallet'] ) ); ?>
				<?php self::row( 'toggle', 'cryptowallet_enabled', __( 'Enable Direct Wallet', 'phemightforms' ), $settings['cryptowallet_enabled'] ); ?>
				<?php self::row( 'textarea', 'cryptowallet_addresses', __( 'Wallet Addresses', 'phemightforms' ), $settings['cryptowallet_addresses'], "BTC: bc1q...\nETH: 0x...\nUSDT (TRC20): T...", __( 'One address per line, shown to the customer after they submit.', 'phemightforms' ) ); ?>
				<?php self::row( 'textarea', 'cryptowallet_note', __( 'Instructions', 'phemightforms' ), $settings['cryptowallet_note'] ); ?>
			</div>

			<h3 class="phf-provider-section"><span class="dashicons dashicons-money"></span> <?php esc_html_e( 'Manual', 'phemightforms' ); ?></h3>

			<?php self::card_open( 'phf-logo-offline', '<span class="dashicons dashicons-money"></span>', __( 'Offline / Manual', 'phemightforms' ), __( 'Collect orders now and arrange payment separately (bank transfer, cash, invoice).', 'phemightforms' ), isset( $enabled['offline'] ) ); ?>
				<?php self::row( 'toggle', 'offline_enabled', __( 'Enable Offline Payments', 'phemightforms' ), $settings['offline_enabled'] ); ?>
				<?php self::row( 'textarea', 'offline_instructions', __( 'Instructions', 'phemightforms' ), $settings['offline_instructions'], '', __( 'Shown to the customer after they submit the form.', 'phemightforms' ) ); ?>
			</div>

			<div class="phf-settings-actions">
				<button type="submit" class="phf-btn phf-btn-primary phf-btn-lg"><?php esc_html_e( 'Save Settings', 'phemightforms' ); ?></button>
			</div>
		</form>
		<?php
	}

	/**
	 * Coupons tab.
	 *
	 * @param array $settings Payment settings.
	 */
	private static function render_coupons( array $settings ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'phemightforms_payments' ); ?>
			<input type="hidden" name="action" value="phemightforms_save_payments">
			<input type="hidden" name="active_tab" value="coupons">

			<div class="phf-card-panel phf-settings-card">
				<div class="phf-panel-head">
					<h3><?php esc_html_e( 'Coupons', 'phemightforms' ); ?></h3>
					<span class="phf-muted"><?php esc_html_e( 'Create discount codes your visitors can enter in a Coupon Code field.', 'phemightforms' ); ?></span>
				</div>
				<div class="phf-coupons-wrap">
					<table class="phf-table phf-coupons-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Code', 'phemightforms' ); ?></th>
								<th><?php esc_html_e( 'Type', 'phemightforms' ); ?></th>
								<th><?php esc_html_e( 'Amount', 'phemightforms' ); ?></th>
								<th></th>
							</tr>
						</thead>
						<tbody id="phf-coupon-rows">
							<?php
							$coupons = (array) $settings['coupons'];
							if ( ! $coupons ) {
								$coupons = [
									[
										'code'   => '',
										'type'   => 'percent',
										'amount' => '',
									],
								];
							}
							foreach ( $coupons as $coupon ) :
								?>
								<tr>
									<td data-label="<?php esc_attr_e( 'Code', 'phemightforms' ); ?>"><input type="text" name="coupon_code[]" value="<?php echo esc_attr( $coupon['code'] ); ?>" placeholder="SAVE10"></td>
									<td data-label="<?php esc_attr_e( 'Type', 'phemightforms' ); ?>">
										<select name="coupon_type[]">
											<option value="percent" <?php selected( $coupon['type'], 'percent' ); ?>><?php esc_html_e( 'Percent off (%)', 'phemightforms' ); ?></option>
											<option value="fixed" <?php selected( $coupon['type'], 'fixed' ); ?>><?php esc_html_e( 'Fixed amount off', 'phemightforms' ); ?></option>
										</select>
									</td>
									<td data-label="<?php esc_attr_e( 'Amount', 'phemightforms' ); ?>"><input type="number" step="0.01" min="0" name="coupon_amount[]" value="<?php echo esc_attr( $coupon['amount'] ); ?>" placeholder="10"></td>
									<td><button type="button" class="phf-btn phf-btn-ghost phf-btn-sm phf-btn-danger phf-coupon-remove"><span class="dashicons dashicons-trash"></span></button></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<button type="button" class="phf-btn phf-btn-ghost" id="phf-coupon-add"><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'Add Coupon', 'phemightforms' ); ?></button>
				</div>
			</div>

			<?php ob_start(); ?>
				( function () {
					var add = document.getElementById( 'phf-coupon-add' );
					var rows = document.getElementById( 'phf-coupon-rows' );
					if ( add && rows ) {
						add.addEventListener( 'click', function () {
							var first = rows.querySelector( 'tr' );
							var clone = first.cloneNode( true );
							clone.querySelectorAll( 'input' ).forEach( function ( el ) { el.value = ''; } );
							clone.querySelector( 'select' ).value = 'percent';
							rows.appendChild( clone );
						} );
						rows.addEventListener( 'click', function ( e ) {
							var btn = e.target.closest( '.phf-coupon-remove' );
							if ( btn && rows.querySelectorAll( 'tr' ).length > 1 ) {
								btn.closest( 'tr' ).remove();
							}
						} );
					}
				} )();
			<?php wp_add_inline_script( 'phemightforms-admin', ob_get_clean() ); ?>

			<div class="phf-settings-actions">
				<button type="submit" class="phf-btn phf-btn-primary phf-btn-lg"><?php esc_html_e( 'Save Coupons', 'phemightforms' ); ?></button>
			</div>
		</form>
		<?php
	}
}
