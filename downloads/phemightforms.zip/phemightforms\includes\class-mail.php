<?php
/**
 * SMTP mail delivery for notifications.
 *
 * @package PhemightForms
 */

namespace PhemightForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Configures PHPMailer when SMTP is enabled in plugin settings.
 */
class Mail {

	/**
	 * Hook mail filters.
	 */
	public function __construct() {
		add_action( 'phpmailer_init', [ $this, 'configure_smtp' ] );
		add_filter( 'wp_mail_from', [ $this, 'mail_from' ] );
		add_filter( 'wp_mail_from_name', [ $this, 'mail_from_name' ] );
	}

	/**
	 * Whether SMTP delivery is enabled.
	 *
	 * @return bool
	 */
	public static function smtp_enabled() {
		$mailer = Plugin::get_option( 'smtp_mailer', '' );

		if ( 'smtp' === $mailer ) {
			return true;
		}

		if ( 'default' === $mailer ) {
			return false;
		}

		return (bool) Plugin::get_option( 'smtp_enabled', 0 );
	}

	/**
	 * Active mail delivery method.
	 *
	 * @return string default|smtp
	 */
	public static function mailer() {
		$mailer = Plugin::get_option( 'smtp_mailer', '' );

		if ( in_array( $mailer, [ 'default', 'smtp' ], true ) ) {
			return $mailer;
		}

		return self::smtp_enabled() ? 'smtp' : 'default';
	}

	/**
	 * Apply SMTP settings to PHPMailer.
	 *
	 * @param \PHPMailer\PHPMailer\PHPMailer $phpmailer Mailer instance.
	 */
	public function configure_smtp( $phpmailer ) {
		if ( ! self::smtp_enabled() ) {
			return;
		}

		$host = Plugin::get_option( 'smtp_host', '' );
		if ( ! $host ) {
			return;
		}

		$phpmailer->isSMTP();
		$phpmailer->Host       = $host;
		$phpmailer->Port       = (int) Plugin::get_option( 'smtp_port', 587 );
		$phpmailer->SMTPAuth   = (bool) Plugin::get_option( 'smtp_auth', 1 );
		$phpmailer->Username  = Plugin::get_option( 'smtp_user', '' );
		$phpmailer->Password   = Plugin::get_option( 'smtp_pass', '' );
		$phpmailer->SMTPSecure = Plugin::get_option( 'smtp_encryption', 'tls' );

		if ( 'none' === $phpmailer->SMTPSecure ) {
			$phpmailer->SMTPSecure  = '';
			$phpmailer->SMTPAutoTLS = false;
		}
	}

	/**
	 * Override the From email address.
	 *
	 * @param string $email Current from email.
	 * @return string
	 */
	public function mail_from( $email ) {
		$custom = Plugin::get_option( 'smtp_from_email', '' );

		if ( ! $custom || ! is_email( $custom ) ) {
			$custom = Plugin::get_option( 'from_email', '' );
		}

		return ( $custom && is_email( $custom ) ) ? $custom : $email;
	}

	/**
	 * Override the From name.
	 *
	 * @param string $name Current from name.
	 * @return string
	 */
	public function mail_from_name( $name ) {
		$custom = Plugin::get_option( 'smtp_from_name', '' );

		if ( ! $custom ) {
			$custom = Plugin::get_option( 'from_name', '' );
		}

		return $custom ? $custom : $name;
	}

	/**
	 * Send a plain-text notification email.
	 *
	 * @param string|array $to      Recipient(s).
	 * @param string       $subject Subject line.
	 * @param string       $body    Message body.
	 * @return bool
	 */
	public static function send( $to, $subject, $body ) {
		$headers = [ 'Content-Type: text/plain; charset=UTF-8' ];
		return wp_mail( $to, $subject, $body, $headers );
	}

	/**
	 * Send a test email from the settings screen.
	 *
	 * @param string $to Test recipient.
	 * @return bool|\WP_Error
	 */
	public static function send_test( $to ) {
		if ( ! is_email( $to ) ) {
			return new \WP_Error( 'invalid_email', __( 'Invalid email address.', 'phemightforms' ) );
		}

		$sent = self::send(
			$to,
			__( 'PhemightForms mail test', 'phemightforms' ),
			self::mailer() === 'smtp'
				? __( 'If you received this email, your SMTP configuration is working correctly.', 'phemightforms' )
				: __( 'If you received this email, your default PHP mail configuration is working correctly.', 'phemightforms' )
		);

		return $sent ? true : new \WP_Error( 'send_failed', __( 'Email could not be sent. Check your SMTP settings.', 'phemightforms' ) );
	}
}
